#! /usr/bin/env python
#coding=utf-8
import re
from html2pdf import html2pdf

# 正则匹配函数
def re_find(p, text):
    m = p.findall(text)
    if len(m) == 1:
        return m[0]
    return ''

def re_findall(p, text):
    return p.findall(text)

# 清理文本函数，去除多余的空格和换行符
def clear_text(text):
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    return ' '.join(lines)

# 读取文件内容
def read_file(file_path):
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except FileNotFoundError:
        print("Error: File %s not found." % file_path)
        return None
    except Exception as e:
        print("Error reading file %s: %s" % (file_path, e))
        return None

# 提取文档部分
def extract_document(content):
    p_doc = re.compile(r'\\begin{document}(.+?)\\end{document}', re.S)
    return re_find(p_doc, content)

# 提取标题
def extract_title(document):
    p_title = re.compile(r'\\title{(.+?)}', re.S)
    return re_find(p_title, document)

# 提取摘要
def extract_abstract(document):
    p_abs = re.compile(r'\\begin{abstract}(.+?)\\end{abstract}', re.S)
    abstract = re_find(p_abs, document)
    return clear_text(abstract)

# 提取章节内容
def extract_sections(document):
    p_sec = re.compile(r'\\section{(.+?)}(.+?)(?=\\subsubsection|\\begin|\\subsection|\\section|\\end{document}|^\s*%)', re.S)
    section_content = re_findall(p_sec, document)
    sections = []
    for title, content in section_content:
        sections.append((title, clear_text(content)))
    return sections

# 提取子章节内容
def extract_subsections(document):
    p_subsec = re.compile(r'\\subsection{([^}]+)}(.+?)(?=\\subsubsection|\\begin|\\subsection|\\section|\\end{document}|^\s*%)', re.S | re.M)
    subsection_content = re_findall(p_subsec, document)
    subsections = []
    for title, content in subsection_content:
        subsections.append((title, clear_text(content)))
    return subsections

# 处理 itemize 环境
def process_itemize(content):
    p_item = re.compile(r'\\item \\texttt{(\\textbackslash .*?}?)} - (.*?)(?=\\item|\\end{itemize}|\\begin{itemize})', re.S)
    return re_findall(p_item, content)

def itemize_to_html(items):
    html_output = ['<ul>']
    for command, description in items:
        cmd = command
        cmd = cmd.replace(r'\textbackslash ', '\\')
        cmd = re.sub(r'\\{', '{', cmd)
        cmd = re.sub(r'\\}', '}', cmd)
        cmd = re.sub(r'\\texttt{(.*?)}', r'\1', cmd)
        desc = re.sub(r'%\s*\\.*', '', description)
        desc = re.sub(r'\n\t+', '<br>', desc.strip())
        desc = desc.replace(r'\ ', ' ')
        html_output.append('  <li><code>%s</code> - %s</li>' % (cmd, desc))
    html_output.append('</ul>')
    return '\n'.join(html_output)

# 处理 tabular 环境
def process_tabular(content):
    p_tabular = re.compile(r"\\begin{tabular}.*\\end{tabular}", re.S)
    tabular = re_findall(p_tabular, content)
    if not tabular:
        return [], []
    p_table_style = re.compile(r"{tabular}{\| (l) \| (l) \|}")
    table_style = re_findall(p_table_style, tabular[0])
    p_table = re.compile(r"\\texttt{(\\textbackslash .+?)\\({\\emph{.+?})\\}} & (-?\d)")
    table_content = re_findall(p_table, tabular[0])
    return table_style, table_content

def tabular_to_html(table_style, table_content):
    style_map = {'l': 'left', 'c': 'center', 'r': 'right'}
    col_align = [style_map.get(s, 'left') for s in table_style[0]] if table_style else ['left', 'left']
    html = [
        '<table style="border: 1px solid black; border-collapse: collapse; margin: 10px;">',
        '  <thead>',
        '    <tr>',
        '      <th style="border: 1px solid black; padding: 5px; text-align: %s;">Command</th>' % col_align[0],
        '      <th style="border: 1px solid black; padding: 5px; text-align: %s;">Level</th>' % col_align[1],
        '    </tr>',
        '  </thead>',
        '  <tbody>'
    ]
    for command, param, level in table_content:
        clean_cmd = command.replace(r'\textbackslash ', '\\')
        fixed_param = param
        if fixed_param.count('{') > fixed_param.count('}'):
            fixed_param += '}'
        html.append(
            '\n    <tr>\n'
            '      <td style="border: 1px solid black; padding: 5px;"><code>%s%s</code></td>\n' % (clean_cmd, fixed_param) +
            '      <td style="border: 1px solid black; padding: 5px; text-align: center;">%s</td>\n' % level +
            '    </tr>'
        )
    html.append('\n  </tbody>\n</table>')
    return '\n'.join(html)

# 处理 emphasis 标记
def process_emph(content):
    return re.sub(r'\\emph{([^}]*)}', r'<em>\1</em>', content)

# 生成 HTML 文本
def generate_html_text(title, abstract, sections, subsections, table_style, table_content, itemize_items):
    html_text = ''
    html_text += '<h1>%s</h1>\n\n' % title
    html_text += '<p>%s</p>\n\n' % abstract
    for sec_title, sec_content in sections:
        html_text += '<h2>%s</h2>\n\n' % sec_title
        html_text += '<p>%s</p>\n\n' % sec_content
    for sub_title, sub_content in subsections:
        html_text += '<h3>%s</h3>\n\n' % sub_title
        html_text += '<p>%s</p>\n\n' % sub_content
    html_text += tabular_to_html(table_style, table_content)
    html_text += itemize_to_html(itemize_items)
    html_text = process_emph(html_text)
    return html_text

# 主函数
def main():
    content = read_file('example.tex')
    if content is None:
        return
    document = extract_document(content)
    title = extract_title(document)
    abstract = extract_abstract(document)
    sections = extract_sections(document)
    subsections = extract_subsections(document)
    table_style, table_content = process_tabular(document)
    itemize_items = process_itemize(document)
    html_text = generate_html_text(title, abstract, sections, subsections, table_style, table_content, itemize_items)
    try:
        with open('output.html', 'w') as f:
            f.write(html_text)
        print("HTML file generated successfully.")
    except Exception as e:
        print("Error writing HTML file: %s" % e)

if __name__ == "__main__":
    main()