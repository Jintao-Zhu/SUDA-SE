new_query = 'SELECT AVG(数学) AS 数学平均分 FROM student'
print("\n执行新查询:")
execute_query(new_query)