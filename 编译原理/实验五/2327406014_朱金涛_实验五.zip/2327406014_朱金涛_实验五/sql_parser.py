import ply.lex as lex
import ply.yacc as yacc
from math import *
from node import node
import csv
import os
#TOKENS
tokens=('SELECT','FROM','WHERE','ORDER','BY','NAME','AND','OR','COMMA',
'LP','RP','AVG','BETWEEN','IN','SUM','MAX','MIN','COUNT','NUMBER','AS','DOT',
'ALL', 'GE', 'STAR')  

#DEFINE OF TOKENS
def t_ALL(t):  
    r'ALL'
    return t

def t_GE(t): 
    r'>='
    return t

def t_SELECT(t):
    r'SELECT'
    return t

def t_ORDER(t):
    r'ORDER'
    return t

def t_BY(t):
    r'BY'
    return t

def t_AVG(t):
    r'AVG'
    return t

def t_BETWEEN(t):
    r'BETWEEN'
    return t

def t_IN(t):
    r'IN'
    return t

def t_SUM(t):
    r'SUM'
    return t

def t_MAX(t):
    r'MAX'
    return t

def t_MIN(t):
    r'MIN'
    return t

def t_COUNT(t):
    r'COUNT'
    return t

def t_NUMBER(t):
    r'\d+'
    return t

def t_AS(t):
    r'AS'
    return t

def t_DOT(t):
    r'\.'
    return t

def t_LP(t):
    r'\('
    return t

def t_RP(t):
    r'\)'
    return t

def t_AND(t):
    r'AND'
    return t

def t_OR(t):
    r'OR'
    return t

def t_COMMA(t):
    r','
    return t   

def t_FROM(t):
    r'FROM'
    return t

def t_WHERE(t):
    r'WHERE'
    return t

def t_STAR(t):
    r'\*'
    return t

def t_NAME(t):
    r'[A-Za-z\u4e00-\u9fa5]+|[a-zA-Z_\u4e00-\u9fa5][a-zA-Z0-9_\u4e00-\u9fa5]*|[A-Z]*\.[A-Z]$'
    return t

# IGNORED
t_ignore = " \t"
def t_error(t):
    print("Illegal character '%s'" % t.value[0])
    t.lexer.skip(1)

# LEX ANALYSIS   
lex.lex()

#PARSING
def p_query(t):
    '''query :  select'''
    t[0]=t[1]
        
#语法规则
def p_select(t):
    '''select : SELECT list FROM table where_clause order_by
              | SELECT list FROM table where_clause
              | SELECT list FROM table order_by
              | SELECT list FROM table'''
    t[0]=node('QUERY')
    t[0].add(node('[SELECT]'))
    t[0].add(t[2])
    t[0].add(node('[FROM]'))
    t[0].add(t[4])
    if len(t) > 5 and t[5] is not None:
        t[0].add(t[5])
    if len(t) > 6 and t[6] is not None:
        t[0].add(t[6])


def p_order_by(t):
    '''order_by : ORDER BY list'''
    t[0]=node('[ORDER BY]')
    t[0].add(t[3])


def p_where_clause(t):
    '''where_clause : WHERE condition'''
    t[0]=node('[WHERE]')
    t[0].add(t[2])


def p_condition(t):
    '''condition : NAME GE ALL LP select RP'''
    t[0]=node('[CONDITION]')
    t[0].add(node(t[1]))
    t[0].add(node(t[2]))
    t[0].add(node(t[3]))
    t[0].add(t[5])

def p_table(t):
    '''table : NAME'''
    t[0]=node('[TABLE]')
    t[0].add(node(t[1]))


def p_list(t):
    ''' list : STAR
             | NAME
             | func_expr
             | func_expr alias
             | list COMMA list
    '''
    t[0] = node('[FIELD]')
    if len(t) == 2:
        if isinstance(t[1], node):  
            t[0].add(t[1])
        else: 
            if t.slice[1].type == 'STAR':
                t[0].add(node('*'))
            else:
                t[0].add(node(t[1]))
    elif len(t) == 4:  
        t[0].add(t[1])
        t[0].add(node(t[2]))
        t[0].add(t[3])
    else: 
        t[0].add(t[1])
        t[0].add(t[2])

def p_func_expr(t):
    '''func_expr : AVG LP NAME RP
                 | SUM LP NAME RP
                 | MAX LP NAME RP
                 | MIN LP NAME RP
                 | COUNT LP NAME RP'''
    func_type = t[1]
    field_name = t[3]
    t[0] = node(f'[{func_type}]')
    t[0].add(node(field_name))

def p_alias(t):
    '''alias : AS NAME'''
    t[0] = node('[ALIAS]')
    t[0].add(node(t[2]))

# 错误处理函数
def p_error(p):
    if p:
        print(f"Syntax error at token '{p.value}' of type '{p.type}'")
    else:
        print("Syntax error at end of input")

parser = yacc.yacc()

def execute_query(query):

    print(f"正在解析的查询语句: {query}")
    parse = parser.parse(query)
    if parse:
        parse.print_node(0)
        
        # 提取表名
        table_name = None
        children = getattr(parse, '_children', [])
        for current in children:
            if current._data == '[FROM]':
                next_index = children.index(current) + 1
                if next_index < len(children) and children[next_index]._data == '[TABLE]':
                    table_name = children[next_index]._children[0]._data
                    break
        
        if not table_name:
            print("未找到表名")
            return
            
        # 提取SELECT部分信息
        select_field = None
        agg_func = None
        alias_name = None
        
        for current in children:
            if current._data == '[SELECT]':
                next_index = children.index(current) + 1
                if next_index < len(children) and children[next_index]._data == '[FIELD]':
                    field_node = children[next_index]._children[0]
                    
                    # 检查是否是聚合函数
                    if field_node._data in ('[AVG]', '[SUM]', '[MIN]', '[MAX]', '[COUNT]'):
                        agg_func = field_node._data[1:-1]  # 去掉方括号
                        select_field = field_node._children[0]._data
                        
                        # 检查别名
                        if len(field_node._children) > 1 and field_node._children[1]._data == '[ALIAS]':
                            alias_name = field_node._children[1]._children[0]._data
                    else:
                        select_field = field_node._data
                    break
        
        # 提取ORDER BY信息
        order_by_field = None
        for current in children:
            if current._data == '[ORDER BY]':
                order_by_field = current._children[0]._children[0]._data
                break
        
        # 读取CSV文件
        csv_file_path = 'D:\\编译原理\\实验8\\2327406014_朱金涛_实验五\\student.csv'
        if not os.path.exists(csv_file_path):
            print(f"找不到文件: {csv_file_path}")
            return
        try:
            with open(csv_file_path, newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                rows = list(reader)
                
                # 处理ORDER BY
                if order_by_field:
                    try:
                        rows.sort(key=lambda x: float(x[order_by_field]), reverse=True)
                    except KeyError:
                        print(f"找不到排序字段 '{order_by_field}'")
                    except ValueError:
                        print(f"无法将 '{order_by_field}' 字段的值转换为数字进行排序")
                
                # 处理聚合函数
                if agg_func == 'AVG':
                    total = 0
                    count = 0
                    for row in rows:
                        try:
                            value = float(row[select_field])
                            total += value
                            count += 1
                        except ValueError:
                            print(f"无法将'{row[select_field]}'转换为数字，跳过该行")
                    
                    if count > 0:
                        avg_value = total / count
                        output_name = alias_name if alias_name else f"AVG({select_field})"
                        print(f"{output_name}: {avg_value:.2f}")
                    else:
                        print("没有有效数据可计算平均值")
                
                # 处理非聚合查询 (原功能)
                elif select_field == '考号':
                    max_chinese_score = -1
                    max_exam_number = None
                    
                    for row in rows:
                        try:
                            chinese_score = int(row['语文'])
                            if chinese_score > max_chinese_score:
                                max_chinese_score = chinese_score
                                max_exam_number = row['考号']
                        except ValueError:
                            print(f"无法将'{row['语文']}'转换为整数，跳过该行")
                    
                    if max_exam_number:
                        print(f"语文得分最高的学生的考试号是: {max_exam_number}")
                    else:
                        print("没有找到有效数据")
                
                # 处理ORDER BY查询
                elif order_by_field:
                    print("按总分排名结果:")
                    for row in rows:
                        print(row)
                else:
                    print(f"暂不支持对字段 '{select_field}' 的查询")
                    
        except FileNotFoundError:
            print(f"找不到文件: d:\\编译原理\\实验8\\student.csv")
    else:
        print("解析失败，请检查查询语句。")

# 测试计算数学平均分功能 
new_query = 'SELECT AVG(数学) AS 数学平均分 FROM student'
print("\n查询数学平均分:")
execute_query(new_query)

# 测试查询语文分数第一的学生的功能
original_query = 'SELECT 考号 FROM student WHERE 语文 >= ALL (SELECT 语文 FROM student)'
print("\n查新语文分数第一的学生:")
execute_query(original_query)

# 测试按总分排名功能
order_by_query = 'SELECT * FROM student ORDER BY 总分'
print("\n按总分排名测试:")
execute_query(order_by_query)