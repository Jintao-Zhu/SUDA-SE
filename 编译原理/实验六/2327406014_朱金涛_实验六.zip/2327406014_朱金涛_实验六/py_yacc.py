from ply.yacc import yacc
from py_lex import *
from node import node, num_node

# YACC for parsing Python-like syntax

def simple_node(t, name):
    t[0] = node(name)
    for i in range(1, len(t)):
        t[0].add(node(t[i]))
    return t[0]

def p_program(t):
    '''program : statements'''
    t[0] = node('[PROGRAM]')
    t[0].add(t[1])

def p_statements(t):
    '''statements : statements statement
                  | statement'''
    t[0] = node('[STATEMENTS]')
    if len(t) == 3:
        t[0].add(t[1])
        t[0].add(t[2])
    else:
        t[0].add(t[1])

def p_statement(t):
    '''statement : assignment
                 | print
                 | if
                 | while
                 | function
                 | runfunction'''
    t[0] = node('[STATEMENT]')
    t[0].add(t[1])

# -------- Assignment & Expressions --------

def p_assignment(t):
    '''assignment : VARIABLE '=' expression'''
    t[0] = node('[ASSIGNMENT]')
    t[0].add(node(t[1]))
    t[0].add(node(t[2]))
    t[0].add(t[3])

def p_expression_binop(t):
    '''expression : expression '+' term
                  | expression '-' term
                  | expression '*' term
                  | expression '/' term'''
    t[0] = node('[EXPR]')
    t[0].add(t[1])
    t[0].add(node(t[2]))
    t[0].add(t[3])

def p_expression_term(t):
    'expression : term'
    t[0] = t[1]

def p_term_number(t):
    'term : NUMBER'
    t[0] = num_node(t[1])

def p_term_variable(t):
    'term : VARIABLE'
    t[0] = node(t[1])

# -------- Print --------

def p_print(t):
    '''print : PRINT '(' print_args ')' '''
    t[0] = node('[PRINT]')
    t[0].add(node('print'))
    t[0].add(node('('))
    t[0].add(t[3])  # print_args node
    t[0].add(node(')'))

def p_print_args_multi(t):
    '''print_args : print_args ',' expression'''
    if t[1].getdata() != '[ARGS]':

        # 说明 t[1] 是 expression，不是 ARGS，创建一个新的 ARGS 节点
        t[0] = node('[ARGS]')
        t[0].add(t[1])
    else:
        # t[1] 是已经构建好的 ARGS 节点，直接复制
        t[0] = t[1]
    t[0].add(t[3])


def p_print_args_single(t):
    '''print_args : expression'''
    t[0] = node('[ARGS]')
    t[0].add(t[1])




# -------- If --------

def p_if(t):
    '''if : IF '(' condition ')' '{' statements '}' '''
    t[0] = node('[IF]')
    t[0].add(t[3])
    t[0].add(t[6])

# -------- While --------

def p_while(t):
    '''while : WHILE '(' condition ')' '{' statements '}' '''
    t[0] = node('[WHILE]')
    t[0].add(t[3])
    t[0].add(t[6])

# -------- Function Definition --------

def p_function(t):
    '''function : DEF VARIABLE '(' VARIABLE ')' '{' statements RETURN VARIABLE '}' '''
    t[0] = node('[FUNCTION]')
    t[0].add(node(t[2]))  # function name
    t[0].add(node(t[4]))  # parameter
    t[0].add(t[7])        # body
    t[0].add(node(t[9]))  # return var

# -------- Function Call --------

def p_runfunction(t):
    '''runfunction : VARIABLE '(' VARIABLE ')' '''
    if t[1] == 'print':
        t[0] = node('[PRINT]')
        t[0].add(node('print'))
        t[0].add(node('('))
        t[0].add(node(t[3]))
        t[0].add(node(')'))
    else:
        t[0] = node('[RUNFUNCTION]')
        t[0].add(node(t[1]))
        t[0].add(node(t[3]))


# -------- Condition --------

def p_condition(t):
    '''condition : VARIABLE '>' VARIABLE
                 | VARIABLE '<' VARIABLE'''
    t[0] = simple_node(t, '[CONDITION]')

# -------- Error Handling --------

def p_error(t):
    print("Syntax error at '%s'" % t.value)
