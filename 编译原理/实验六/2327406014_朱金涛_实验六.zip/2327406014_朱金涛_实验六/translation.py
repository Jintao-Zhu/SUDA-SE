from __future__ import division

f_table = {}  # function table

class Tran:

    def __init__(self):
        self.v_table = {}  # variable table

    def update_v_table(self, name, value):
        self.v_table[name] = value

    def trans(self, node):

        # Assignment
        if node.getdata() == '[ASSIGNMENT]':
            var_node = node.getchild(0)
            value_node = node.getchild(2)
            value = self.trans(value_node)
            var_node.setvalue(value)
            self.update_v_table(var_node.getdata(), value)

        # Operation (旧版 OPERATION 节点保留兼容)
        elif node.getdata() == '[OPERATION]':
            arg0 = self.v_table[node.getchild(2).getdata()]
            arg1 = self.v_table[node.getchild(4).getdata()]
            op = node.getchild(3).getdata()

            if op == '+':
                value = arg0 + arg1
            elif op == '-':
                value = arg0 - arg1
            elif op == '*':
                value = arg0 * arg1
            else:
                value = arg0 / arg1

            node.getchild(0).setvalue(value)
            self.update_v_table(node.getchild(0).getdata(), value)

        # Expression node
        elif node.getdata() == '[EXPR]':
            left = self.trans(node.getchild(0))
            op = node.getchild(1).getdata()
            right = self.trans(node.getchild(2))

            if op == '+':
                value = left + right
            elif op == '-':
                value = left - right
            elif op == '*':
                value = left * right
            elif op == '/':
                value = left / right
            else:
                raise Exception(f'Unsupported operator {op} in [EXPR]')

            node.setvalue(value)

        # Leaf Variable
        elif node.getdata() in self.v_table:
            value = self.v_table[node.getdata()]
            node.setvalue(value)

        # Number node
        elif node.getvalue() is not None:
            return node.getvalue()

        # ✅ Print (支持 print(a) 和 print(a,b,c))
        elif node.getdata() == '[PRINT]':
            args_node = node.getchild(2)  # 获取 [ARGS] 节点或单一表达式
            values = []

            # 如果是 [ARGS] 多参数
            if args_node.getdata() == '[ARGS]':
                for child in args_node.getchildren():
                    val = self.trans(child)
                    values.append(val)
            else:
                # 单一参数
                values.append(self.trans(args_node))

            print(*values)


        # If
        elif node.getdata() == '[IF]':
            children = node.getchildren()
            self.trans(children[0])
            condition = children[0].getvalue()
            if condition:
                for c in children[1:]:
                    self.trans(c)

        # While
        elif node.getdata() == '[WHILE]':
            children = node.getchildren()
            while self.trans(children[0]):
                for c in children[1:]:
                    self.trans(c)

        # Condition
        elif node.getdata() == '[CONDITION]':
            arg0 = self.v_table[node.getchild(0).getdata()]
            arg1 = self.v_table[node.getchild(2).getdata()]
            op = node.getchild(1).getdata()
            if op == '>':
                node.setvalue(arg0 > arg1)
            elif op == '<':
                node.setvalue(arg0 < arg1)

        # Function
        elif node.getdata() == '[FUNCTION]':
            fname = node.getchild(0).getdata()
            vname = node.getchild(1).getdata()
            f_table[fname] = (vname, node.getchild(2))

        # Run Function
        elif node.getdata() == '[RUNFUNCTION]':
            fname = node.getchild(0).getdata()
            vname1 = node.getchild(1).getdata()
            vname0, fnode = f_table[fname]

            t = Tran()
            t.v_table[vname0] = self.v_table[vname1]
            t.trans(fnode)
            print(t.v_table)

        # Default: traverse children
        else:
            for c in node.getchildren():
                self.trans(c)

        return node.getvalue()
