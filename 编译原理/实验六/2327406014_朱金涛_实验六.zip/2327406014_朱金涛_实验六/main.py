from py_lex import *
from py_yacc import *
from util import clear_text
from translation import Tran

text=clear_text(open('Python--解析/0.py').read())

# syntax parse
lexer = lex()
parser = yacc()
root = parser.parse(text)
if root is not None:
    root.print_node(0)
else:
    print('解析失败，请检查输入文件或语法规则。')

# translation
t = Tran()
if root is not None:
    t.trans(root)
    print(t.v_table)