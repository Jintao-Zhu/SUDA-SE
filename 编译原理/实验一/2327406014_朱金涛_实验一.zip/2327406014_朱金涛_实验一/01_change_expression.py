def primary(operator):
    # 定义运算符优先级
    if operator in ('+', '-'):
        return 1
    if operator in ('*', '/'):
        return 2
    return 0

def change(expression):
    operator_stack = []
    output_stack = []
    tokens = expression.split()

    for token in tokens:
        #如果是操作数
        if token.isdigit():
            output_stack.append(token)
        #如果是括号
        elif token == '(':
            operator_stack.append(token)
        elif token == ')':
            while operator_stack and operator_stack[-1] != '(':
                output_stack.append(operator_stack.pop())
            operator_stack.pop()
        else:
            # 如果是运算符
            while operator_stack and primary(operator_stack[-1]) >= primary(token):
                output_stack.append(operator_stack.pop())
            operator_stack.append(token)

    # 处理剩余的运算符
    while operator_stack:
        output_stack.append(operator_stack.pop())

    # 将输出栈中的元素连接成字符串
    postfix_expression = ' '.join(output_stack)
    return postfix_expression

# 测试代码
infix_expression = "3 * ( 5 + 8 ) - 7" 
postfix_expression = change(infix_expression)
print("中缀表达式:", infix_expression)
print("后缀表达式:", postfix_expression)