import re

#提取超链接
def extract_links():
    try:
        # 打开 list.html 文件，并指定编码为 GB2312
        with open('编译原理/list.html', 'r') as file:
            html_content = file.read()
        # 定义匹配超链接的正则表达式模式
        pattern = re.compile(r'<a title="" href="(https://www.sohu.com/a/.+?)" target="_blank">(.+?)</a>')
        # 使用 re.findall 方法查找所有匹配的超链接
        links = re.findall(pattern, html_content)
        return links
    except FileNotFoundError:
        print("未找到 list.html 文件。")
        return []
    except UnicodeDecodeError:
        print("文件解码错误，请检查文件编码是否为 GB2312。")
        return []

#提取标题与正文
def extract_title():
    try:
        with open('编译原理/content.html','r',encoding='utf-8') as file_2:
            html_content_2 = file_2.read()
        pattern_2 = re.compile(r'<title>(.+?)</title>')
        titles = re.findall(pattern_2,html_content_2)
        return titles
    except FileNotFoundError:
        print("未找到 content.html 文件。")
        return []
    except UnicodeDecodeError:
        print("文件解码错误，请检查文件编码是否为 GB2312。")
        return []

def extract_body():
    try:
        with open('编译原理/content.html','r',encoding='utf-8') as file_2:
            html_content_2 = file_2.read()
        pattern_3 = re.compile(r'<p>((?:(?!<a).)+?)</p>')
        bodys = re.findall(pattern_3,html_content_2)
        return bodys
    except FileNotFoundError:
        print("未找到 content.html 文件。")
        return []
    except UnicodeDecodeError:
        print("文件解码错误，请检查文件编码是否为 GB2312。")
        return []

# 调用函数提取超链接
links = extract_links()
if links:
    print("提取到的超链接如下：")
    for link in links:
        print(link)
else:
    print("未提取到超链接。")
print()

#调用函数提取标题
titles = extract_title()
if titles:
    print("提取的标题如下：")
    for title in titles:
        print(title)
else:
    print("未提取到标题。")
print()

#调用函数提取正文
bodys = extract_body()
if bodys:
    print("提取的正文如下：")
    for body in bodys:
        clean_text = body.replace('<p>', '').replace('</p>', '')
        print(clean_text)
else:
    print("未提取到正文。")