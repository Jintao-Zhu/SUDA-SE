import re

#匹配图片文件名
def image_filename(filename):
    pattern = r'^[a-zA-Z0-9_.-]+\.(jpg|jpeg|gif|bmp)$'
    return bool(re.match(pattern, filename, re.IGNORECASE))

#匹配日期格式
def _date(date):
    pattern = r'^\d{1,2}/\d{1,2}/\d{4}$'
    return bool(re.match(pattern, date))

#匹配电话号（区号提取）
def extract_area_code(phone_number):
    pattern = r'\((\d{3,4})\)'
    match = re.search(pattern, phone_number)
    if match:
        return match.group(1)
    return None

#图片文件格式测试示例
print("图片文件格式测试示例:")
filenames = ["image.jpg", "picture.jpeg", "logo.GIF", "icon.BMP", "document.txt"]
for filename in filenames:
    print(f"{filename}: {'有效' if image_filename(filename) else '无效'}")
print()

#日期格式测试示例
print("日期格式测试示例:")
dates = ["2/31/2006", "12/15/2024", "1/1/2000", "2024-12-15"]
for date in dates:
    print(f"{date}: {'有效' if _date(date) else '无效'}")
print()

#区号提取测试示例
print("电话区号提取测试示例:")
phone_numbers = ["(0512) 68078800-6852", "(021) 12345678", "12345678"]
for phone_number in phone_numbers:
    area_code = extract_area_code(phone_number)
    if area_code:
        print(f"{phone_number} 的区号是: {area_code}")
    else:
        print(f"{phone_number} 未找到区号")