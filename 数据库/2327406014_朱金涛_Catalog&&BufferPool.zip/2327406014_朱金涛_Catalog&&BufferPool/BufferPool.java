package simpledb;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * BufferPool manages the reading and writing of pages into memory from
 * disk. Access methods call into it to retrieve pages, and it fetches
 * pages from the appropriate location.
 * <p>
 * The BufferPool is also responsible for locking;  when a transaction fetches
 * a page, BufferPool checks that the transaction has the appropriate
 * locks to read/write the page.
 * 
 * @Threadsafe, all fields are final
 */
public class BufferPool {
    /** Bytes per page, including header. */
    private static final int PAGE_SIZE = 4096;

    private static int pageSize = PAGE_SIZE;

    /** Default number of pages passed to the constructor. This is used by
    other classes. BufferPool should use the numPages argument to the
    constructor instead. */
    public static final int DEFAULT_PAGES = 50;

    // 存储缓存页的Map，键为PageId，值为缓存页项
    private final ConcurrentHashMap<PageId, CachedPage> pageMap;
    // 缓存页的最大数量
    private final int maxPages;
    // LRU队列，用于页面置换
    private final LinkedList<PageId> lruQueue;
    // 锁管理器，用于处理事务锁
    private final LockManager lockManager;

    /**
     * 缓存页项，包含页、最后访问时间和脏标记
     */
    private static class CachedPage {
        private final Page page;
        private long lastAccessTime;
        private boolean isDirty;
        private TransactionId dirtier;

        public CachedPage(Page page) {
            this.page = page;
            this.lastAccessTime = System.currentTimeMillis();
            this.isDirty = false;
            this.dirtier = null;
        }

        public Page getPage() {
            this.lastAccessTime = System.currentTimeMillis();
            return page;
        }

        public long getLastAccessTime() {
            return lastAccessTime;
        }

        public boolean isDirty() {
            return isDirty;
        }

        public void markDirty(boolean dirty, TransactionId tid) {
            isDirty = dirty;
            dirtier = dirty ? tid : null;
        }

        public TransactionId getDirtier() {
            return dirtier;
        }
    }

    /**
     * 锁管理器，处理页面的读写锁
     */
    private static class LockManager {
        // 记录每个页面的锁状态
        private final ConcurrentHashMap<PageId, LockInfo> lockMap;

        public LockManager() {
            this.lockMap = new ConcurrentHashMap<>();
        }

        /**
         * 请求锁，可能会阻塞直到获得锁
         */
        public synchronized void acquireLock(TransactionId tid, PageId pid, Permissions perm) 
                throws TransactionAbortedException {
            long startTime = System.currentTimeMillis();
            long timeout = 5000; // 设置超时时间为5秒
            
            while (true) {
                LockInfo lockInfo = lockMap.computeIfAbsent(pid, k -> new LockInfo());
                
                // 检查是否已有锁
                if (lockInfo.holdsLock(tid, perm)) {
                    // 更新锁的时间戳，用于判断锁的优先级
                    lockInfo.updateLockTime(tid);
                    return;
                }
                
                // 尝试获取锁
                if (lockInfo.tryAcquireLock(tid, perm)) {
                    return;
                }
                
                // 检查是否超时
                if (System.currentTimeMillis() - startTime > timeout) {
                    throw new TransactionAbortedException();
                }
                
                try {
                    // 等待锁释放
                    wait(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new TransactionAbortedException();
                }
            }
        }

        /**
         * 释放锁
         */
        public synchronized void releaseLock(TransactionId tid, PageId pid) {
            LockInfo lockInfo = lockMap.get(pid);
            if (lockInfo != null) {
                lockInfo.releaseLock(tid);
                if (lockInfo.isEmpty()) {
                    lockMap.remove(pid);
                }
                // 通知等待的线程
                notifyAll();
            }
        }

        /**
         * 释放事务的所有锁
         */
        public synchronized void releaseAllLocks(TransactionId tid) {
            List<PageId> pagesToRemove = new ArrayList<>();
            
            for (Map.Entry<PageId, LockInfo> entry : lockMap.entrySet()) {
                PageId pid = entry.getKey();
                LockInfo lockInfo = entry.getValue();
                
                lockInfo.releaseLocksForTransaction(tid);
                if (lockInfo.isEmpty()) {
                    pagesToRemove.add(pid);
                }
            }
            
            // 移除空的锁信息
            for (PageId pid : pagesToRemove) {
                lockMap.remove(pid);
            }
            
            // 通知所有等待的线程
            notifyAll();
        }

        /**
         * 检查事务是否持有页面的锁
         */
        public synchronized boolean holdsLock(TransactionId tid, PageId pid) {
            LockInfo lockInfo = lockMap.get(pid);
            return lockInfo != null && lockInfo.holdsAnyLock(tid);
        }
    }

    /**
     * 锁信息类，记录页面的锁状态
     */
    private static class LockInfo {
        // 记录每个事务持有的锁类型
        private final Map<TransactionId, Permissions> transactionLocks;
        // 记录每个事务获取锁的时间
        private final Map<TransactionId, Long> lockTimes;

        public LockInfo() {
            this.transactionLocks = new HashMap<>();
            this.lockTimes = new HashMap<>();
        }

        /**
         * 尝试获取锁
         */
        public boolean tryAcquireLock(TransactionId tid, Permissions perm) {
            // 如果是同一个事务请求升级锁
            if (transactionLocks.containsKey(tid)) {
                Permissions currentPerm = transactionLocks.get(tid);
                // 从读锁升级到写锁
                if (currentPerm == Permissions.READ_ONLY && perm == Permissions.READ_WRITE) {
                    // 检查是否有其他事务持有锁
                    if (transactionLocks.size() == 1) {
                        transactionLocks.put(tid, perm);
                        lockTimes.put(tid, System.currentTimeMillis());
                        return true;
                    }
                    return false;
                }
                // 其他情况（如重复请求相同的锁）直接成功
                return true;
            }
            
            // 新事务请求锁
            if (perm == Permissions.READ_ONLY) {
                // 读锁可以被多个事务同时持有
                transactionLocks.put(tid, perm);
                lockTimes.put(tid, System.currentTimeMillis());
                return true;
            } else {
                // 写锁需要独占
                if (transactionLocks.isEmpty()) {
                    transactionLocks.put(tid, perm);
                    lockTimes.put(tid, System.currentTimeMillis());
                    return true;
                }
                return false;
            }
        }

        /**
         * 释放锁
         */
        public void releaseLock(TransactionId tid) {
            transactionLocks.remove(tid);
            lockTimes.remove(tid);
        }

        /**
         * 释放事务的所有锁
         */
        public void releaseLocksForTransaction(TransactionId tid) {
            transactionLocks.remove(tid);
            lockTimes.remove(tid);
        }

        /**
         * 检查是否持有特定类型的锁
         */
        public boolean holdsLock(TransactionId tid, Permissions perm) {
            Permissions currentPerm = transactionLocks.get(tid);
            if (currentPerm == null) {
                return false;
            }
            if (perm == Permissions.READ_ONLY) {
                return true; // 只要有锁就满足读权限
            }
            return currentPerm == Permissions.READ_WRITE;
        }

        /**
         * 检查是否持有任何锁
         */
        public boolean holdsAnyLock(TransactionId tid) {
            return transactionLocks.containsKey(tid);
        }

        /**
         * 更新锁的时间戳
         */
        public void updateLockTime(TransactionId tid) {
            if (transactionLocks.containsKey(tid)) {
                lockTimes.put(tid, System.currentTimeMillis());
            }
        }

        /**
         * 检查锁是否为空
         */
        public boolean isEmpty() {
            return transactionLocks.isEmpty();
        }
    }

    /**
     * Creates a BufferPool that caches up to numPages pages.
     *
     * @param numPages maximum number of pages in this buffer pool.
     */
    public BufferPool(int numPages) {
        this.maxPages = numPages;
        this.pageMap = new ConcurrentHashMap<>();
        this.lruQueue = new LinkedList<>();
        this.lockManager = new LockManager();
    }
    
    public static int getPageSize() {
      return pageSize;
    }

    /**
     * Helper: this should be used for testing only!!!
     */
    public static void setPageSize(int pageSize) {
        BufferPool.pageSize = pageSize;
    }
    
    /**
     * Helper: this should be used for testing only!!!
     */
    public static void resetPageSize(int pageSize) {
        BufferPool.pageSize = PAGE_SIZE;
    }

    /**
     * Retrieve the specified page with the associated permissions.
     * Will acquire a lock and may block if that lock is held by another
     * transaction.
     * <p>
     * The retrieved page should be looked up in the buffer pool.  If it
     * is present, it should be returned.  If it is not present, it should
     * be added to the buffer pool and returned.  If there is insufficient
     * space in the buffer pool, a page should be evicted and the new page
     * should be added in its place.
     *
     * @param tid the ID of the transaction requesting the page
     * @param pid the ID of the requested page
     * @param perm the requested permissions on the page
     */
    public Page getPage(TransactionId tid, PageId pid, Permissions perm)
    	    throws TransactionAbortedException, DbException {
    	    try {
    	        // 先获取锁
    	        lockManager.acquireLock(tid, pid, perm);
    	        
    	        // 检查页面是否已在缓存中
    	        synchronized (this) {
    	            if (pageMap.containsKey(pid)) {
    	                // 页面在缓存中，更新LRU队列
    	                lruQueue.remove(pid);
    	                lruQueue.addLast(pid);
    	                return pageMap.get(pid).getPage();
    	            }
    	            
    	            // 页面不在缓存中，需要从磁盘加载
    	            if (pageMap.size() >= maxPages) {
    	                // 缓存已满，需要置换页面
    	                evictPage();
    	            }
    	            
    	            // 从磁盘加载页面
    	            DbFile file = Database.getCatalog().getDatabaseFile(pid.getTableId());
    	            Page page = file.readPage(pid);
    	            
    	            // 添加到缓存
    	            pageMap.put(pid, new CachedPage(page));
    	            lruQueue.addLast(pid);
    	            
    	            return page;
    	        }
    	    } catch (TransactionAbortedException e) {
    	        // 释放已获取的锁
    	        lockManager.releaseLock(tid, pid);
    	        throw e;
    	    }
    	}

    /**
     * Releases the lock on a page.
     * Calling this is very risky, and may result in wrong behavior. Think hard
     * about who needs to call this and why, and why they can run the risk of
     * calling it.
     *
     * @param tid the ID of the transaction requesting the unlock
     * @param pid the ID of the page to unlock
     */
    public void releasePage(TransactionId tid, PageId pid) {
        lockManager.releaseLock(tid, pid);
    }

    /**
     * Release all locks associated with a given transaction.
     *
     * @param tid the ID of the transaction requesting the unlock
     */
    public void transactionComplete(TransactionId tid) throws IOException {
        transactionComplete(tid, true);
    }

    /** Return true if the specified transaction has a lock on the specified page */
    public boolean holdsLock(TransactionId tid, PageId p) {
        return lockManager.holdsLock(tid, p);
    }

    /**
     * Commit or abort a given transaction; release all locks associated to
     * the transaction.
     *
     * @param tid the ID of the transaction requesting the unlock
     * @param commit a flag indicating whether we should commit or abort
     */
    public void transactionComplete(TransactionId tid, boolean commit)
        throws IOException {
        try {
            if (commit) {
                // 提交事务：将所有脏页写回磁盘
                flushPages(tid);
            } else {
                // 回滚事务：丢弃所有由该事务修改的页
                discardPages(tid);
            }
        } finally {
            // 释放所有锁
            lockManager.releaseAllLocks(tid);
        }
    }

    /**
     * 丢弃由指定事务修改的所有页
     */
    private synchronized void discardPages(TransactionId tid) {
        List<PageId> pagesToRemove = new ArrayList<>();
        
        for (Map.Entry<PageId, CachedPage> entry : pageMap.entrySet()) {
            PageId pid = entry.getKey();
            CachedPage cachedPage = entry.getValue();
            
            if (cachedPage.getDirtier() != null && cachedPage.getDirtier().equals(tid)) {
                // 从磁盘重新加载原始页
               
                    DbFile file = Database.getCatalog().getDatabaseFile(pid.getTableId());
                    Page originalPage = file.readPage(pid);
                    cachedPage = new CachedPage(originalPage);
                    pageMap.put(pid, cachedPage);
               
            }
        }
    }

    /**
     * Add a tuple to the specified table on behalf of transaction tid.  Will
     * acquire a write lock on the page the tuple is added to and any other 
     * pages that are updated (Lock acquisition is not needed for lab2). 
     * May block if the lock(s) cannot be acquired.
     * 
     * Marks any pages that were dirtied by the operation as dirty by calling
     * their markDirty bit, and adds versions of any pages that have 
     * been dirtied to the cache (replacing any existing versions of those pages) so
     * that future requests see up-to-date pages. 
     *
     * @param tid the transaction adding the tuple
     * @param tableId the table to add the tuple to
     * @param t the tuple to add
     */
    public void insertTuple(TransactionId tid, int tableId, Tuple t)
        throws DbException, IOException, TransactionAbortedException {
        // 获取表对应的文件
        DbFile file = Database.getCatalog().getDatabaseFile(tableId);
        
        // 插入元组，获取脏页列表
        ArrayList<Page> dirtiedPages = file.insertTuple(tid, t);
        
        // 标记页为脏页
        for (Page page : dirtiedPages) {
            page.markDirty(true, tid);
            
            // 更新缓存
            PageId pid = page.getId();
            synchronized (this) {
                if (pageMap.containsKey(pid)) {
                    // 页面已在缓存中，更新其脏状态
                    CachedPage cachedPage = pageMap.get(pid);
                    cachedPage.markDirty(true, tid);
                    // 更新LRU队列
                    lruQueue.remove(pid);
                    lruQueue.addLast(pid);
                } else {
                    // 页面不在缓存中，添加到缓存
                    if (pageMap.size() >= maxPages) {
                        evictPage();
                    }
                    pageMap.put(pid, new CachedPage(page));
                    lruQueue.addLast(pid);
                }
            }
        }
    }

    /**
     * Remove the specified tuple from the buffer pool.
     * Will acquire a write lock on the page the tuple is removed from and any
     * other pages that are updated. May block if the lock(s) cannot be acquired.
     *
     * Marks any pages that were dirtied by the operation as dirty by calling
     * their markDirty bit, and adds versions of any pages that have 
     * been dirtied to the cache (replacing any existing versions of those pages) so
     * that future requests see up-to-date pages. 
     *
     * @param tid the transaction deleting the tuple.
     * @param t the tuple to delete
     */
    public void deleteTuple(TransactionId tid, Tuple t)
        throws DbException, IOException, TransactionAbortedException {
        // 获取元组所在的表
        int tableId = t.getRecordId().getPageId().getTableId();
        DbFile file = Database.getCatalog().getDatabaseFile(tableId);
        
        // 删除元组，获取脏页列表
        ArrayList<Page> dirtiedPages = file.deleteTuple(tid, t);
        
        // 标记页为脏页
        for (Page page : dirtiedPages) {
            page.markDirty(true, tid);
            
            // 更新缓存
            PageId pid = page.getId();
            synchronized (this) {
                if (pageMap.containsKey(pid)) {
                    // 页面已在缓存中，更新其脏状态
                    CachedPage cachedPage = pageMap.get(pid);
                    cachedPage.markDirty(true, tid);
                    // 更新LRU队列
                    lruQueue.remove(pid);
                    lruQueue.addLast(pid);
                } else {
                    // 页面不在缓存中，添加到缓存
                    if (pageMap.size() >= maxPages) {
                        evictPage();
                    }
                    pageMap.put(pid, new CachedPage(page));
                    lruQueue.addLast(pid);
                }
            }
        }
    }

    /**
     * Flush all dirty pages to disk.
     * Be careful using this routine -- it writes dirty data to disk so will
     *     break simpledb if running in NO STEAL mode.
     */
    public synchronized void flushAllPages() throws IOException {
        for (PageId pid : pageMap.keySet()) {
            flushPage(pid);
        }
    }

    /** Remove the specific page id from the buffer pool.
        Needed by the recovery manager to ensure that the
        buffer pool doesn't keep a rolled back page in its
        cache.
    */
    public synchronized void discardPage(PageId pid) {
        pageMap.remove(pid);
        lruQueue.remove(pid);
    }

    /**
     * Flushes (i.e., writes) a certain page to disk by asking 
     * the correct HeapFile to write the page
     * @param pid an ID indicating the page to flush
     */
    private synchronized void flushPage(PageId pid) throws IOException {
        CachedPage cachedPage = pageMap.get(pid);
        if (cachedPage != null && cachedPage.isDirty()) {
            // 获取对应的文件
            DbFile file = Database.getCatalog().getDatabaseFile(pid.getTableId());
            // 将页写回磁盘
            file.writePage(cachedPage.getPage());
            // 标记为不再脏
            cachedPage.markDirty(false, null);
        }
    }

    /** Write all pages of the specified transaction to disk.
     */
    public synchronized void flushPages(TransactionId tid) throws IOException {
        for (Map.Entry<PageId, CachedPage> entry : pageMap.entrySet()) {
            PageId pid = entry.getKey();
            CachedPage cachedPage = entry.getValue();
            
            if (cachedPage.getDirtier() != null && cachedPage.getDirtier().equals(tid)) {
                flushPage(pid);
            }
        }
    }

    /**
     * Discards a page from the buffer pool.
     * Flushes the page to disk to ensure dirty pages are updated on disk.
     */
    private synchronized void evictPage() throws DbException {
        // 找到最久未使用的页
        if (lruQueue.isEmpty()) {
            throw new DbException("Buffer pool is empty, cannot evict page");
        }
        
        // 尝试找到一个非脏页
        PageId candidate = null;
        for (PageId pid : lruQueue) {
            CachedPage cachedPage = pageMap.get(pid);
            if (!cachedPage.isDirty()) {
                candidate = pid;
                break;
            }
        }
        
        // 如果没有找到非脏页，且允许STEAL，则选择最久未使用的页
        if (candidate == null) {
            // 这里假设允许STEAL策略，否则应抛出异常
            candidate = lruQueue.getFirst();
        }
        
        if (candidate != null) {
            try {
                // 先将页写回磁盘（如果是脏页）
                flushPage(candidate);
                
                // 从缓存中移除
                pageMap.remove(candidate);
                lruQueue.remove(candidate);
            } catch (IOException e) {
                throw new DbException("Error flushing page during eviction: " + e.getMessage());
            }
        } else {
            throw new DbException("No pages available to evict");
        }
    }
}    