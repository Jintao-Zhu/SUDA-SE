#include <bits/stdc++.h>
#include "life.h"

using namespace std;
void instructions()
{
    cout << "Welcome to Conway��s game of Life." << endl;
    cout << "This game uses a grid of size "
         << maxrow << " by " << maxcol << " in which each" << endl;
    cout << "cell can either be occupied by an organism or not." << endl;
    cout << "The occupied cells change from generation to generation" << endl;
    cout << "according to how many neighboring cells are alive." << endl;
}

bool users_say()
{
    bool response = true;
    string c = "a";
    while (c != "y" && c != "Y" && c != "n" && c != "N")
    {
        if (response)
        {
            cout << "(y,n)? " << endl;
        }
        else
        {
            cout << "Please respond with y or n: " << endl;
        }
        cin >> c;
        response = false;
    }
    if (c == "y" || c == "Y")
    {
        return true;
    }
    else
    {
        return false;
    }
}
