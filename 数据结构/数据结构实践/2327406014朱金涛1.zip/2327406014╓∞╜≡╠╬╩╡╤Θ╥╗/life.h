#include <bits/stdc++.h>
using namespace std;
#ifndef LIFE_H
#define LIFE_H
const int maxrow = 20, maxcol = 60;
struct life
{
public:
    void update()
    {
        int row, col;
        int new_lst[maxrow + 2][maxcol + 2];
        for (row = 1; row <= maxrow; row++)
        {
            for (col = 1; col <= maxcol; col++)
            {
                int num = number_count(row, col);
                if (num == 2)
                {
                    new_lst[row][col] = lst[row][col];
                }
                else if (num == 3)
                {
                    new_lst[row][col] = 1;
                }
                else
                {
                    new_lst[row][col] = 0;
                }
            }
        }

        for (int i = 1; i <= maxrow; i++)
        {
            for (int j = 1; j <= maxcol; j++)
            {
                lst[i][j] = new_lst[i][j];
            }
        }
    }
    void initialize()
    {
        int row, col;
        for (row = 0; row < maxrow + 2; row++)
        {
            for (col = 0; col < maxcol + 2; col++)
            {
                lst[row][col] = 0;
            }
        }
        cout << "Please input the living cells." << endl;
        cout << "End with pair (-1,-1)." << endl;
        cin >> row >> col;
        while (row != -1 && col != -1)
        {
            if (row >= 1 && row <= maxrow)
            {
                if (col >= 1 && col <= maxcol)
                {
                    lst[row][col] = 1;
                }
                else
                {
                    cout << "The column " << col << " is out of range." << endl;
                }
            }
            else
            {
                cout << "The row " << row << " is out of range." << endl;
            }
            cin >> row >> col;
        }
    }
    void print()
    {
        cout << "Now the layout of life looks like this." << endl;
        for (int i = 1; i <= maxrow; i++)
        {
            if (i > 1)
            {
                cout << endl;
            }
            for (int j = 1; j <= maxcol; j++)
            {
                if (lst[i][j] == 1)
                {
                    cout << "*";
                }
                else
                {
                    cout << " ";
                }
            }
        }
        cout << endl;
    }
    int number_count(int row, int col)
    {
        int count = 0;
        for (int i = row - 1; i <= row + 1; i++)
        {
            for (int j = col - 1; j <= col + 1; j++)
            {
                count += lst[i][j];
            }
        }
        count -= lst[row][col];
        return count;
    }

private:
    int lst[maxrow + 2][maxcol + 2];
};
#endif