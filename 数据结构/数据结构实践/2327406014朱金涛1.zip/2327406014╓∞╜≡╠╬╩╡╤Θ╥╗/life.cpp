#include <bits/stdc++.h>
#include "life.h"
#include "utility.h"
using namespace std;
int main()
{
    instructions();
    life layout;
    layout.initialize();
    cout << "Now the layout likes this:" << endl;
    layout.print();
    while (users_say())
    {
        layout.update();
        cout << "Now the layout likes this:" << endl;
        layout.print();
    }
    return 0;
}