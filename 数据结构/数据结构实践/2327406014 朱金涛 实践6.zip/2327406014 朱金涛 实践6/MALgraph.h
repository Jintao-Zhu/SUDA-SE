#ifndef MVERTEX
#include <bits/stdc++.h>
#define MaxSize 1000
using namespace std;

struct EdgeNode
{
    int adjvex;
    EdgeNode *next;
};

template <typename T>
struct VertexNode
{
    T vertex;
    EdgeNode *firstEdge;
};

template <typename T>
class ALgraph
{
public:
    ALgraph(T a[], string line1, string line2)
    {
        int i, j, k;
        EdgeNode *new_node = nullptr;
        EdgeNode *temp = nullptr;
        int n, e;
        istringstream iss1(line1);
        istringstream iss2(line2);
        iss1 >> n >> e;

        vertexNum = n;
        edgeNum = e;

        for (i = 0; i < n; i++)
        {
            adjlist[i].vertex = a[i];
            adjlist[i].firstEdge = nullptr;
        }

        for (k = 0; k < edgeNum; k++)
        {
            iss2 >> i >> j;

            if (i < 0 || i >= vertexNum || j < 0 || j >= vertexNum)
            {
                continue;
            }

            new_node = new EdgeNode;
            new_node->adjvex = j;
            new_node->next = nullptr;

            if (adjlist[i].firstEdge == nullptr)
            {
                adjlist[i].firstEdge = new_node;
            }
            else
            {
                temp = adjlist[i].firstEdge;
                EdgeNode *prev = nullptr;

                while (temp != nullptr && temp->adjvex < j)
                {
                    prev = temp;
                    temp = temp->next;
                }

                if (prev == nullptr)
                {

                    new_node->next = adjlist[i].firstEdge;
                    adjlist[i].firstEdge = new_node;
                }
                else
                {

                    new_node->next = temp;
                    prev->next = new_node;
                }
            }
        }
    }
    ~ALgraph()
    {
        EdgeNode *p = nullptr, *q = nullptr;
        for (int i = 0; i < vertexNum; i++)
        {
            p = q = adjlist[i].firstEdge;
            while (p != nullptr)
            {
                p = p->next;
                delete q;
                q = p;
            }
        }
    }
    void DFTraverse(int v)
    {
        int j;
        cout << adjlist[v].vertex;
        visited[v] = 1;
        EdgeNode *p = adjlist[v].firstEdge;
        while (p != nullptr)
        {
            j = p->adjvex;
            if (visited[j] == 0)
            {
                DFTraverse(j);
            }
            p = p->next;
        }
    }
    void BFTraverse(int v)
    {
        int h, q, w[MaxSize];
        int front = -1, rear = -1;
        EdgeNode *p = nullptr;
        cout << adjlist[v].vertex;
        visited[v] = 1;
        w[++rear] = v;
        while (front != rear)
        {
            h = w[++front];
            p = adjlist[h].firstEdge;
            while (p != nullptr)
            {
                q = p->adjvex;
                if (visited[q] == 0)
                {
                    cout << adjlist[q].vertex;
                    visited[q] = 1;
                    w[++rear] = q;
                }
                p = p->next;
            }
        }
    }

private:
    VertexNode<T> adjlist[MaxSize];
    int vertexNum, edgeNum;
    int visited[MaxSize]{0};
};

#endif
