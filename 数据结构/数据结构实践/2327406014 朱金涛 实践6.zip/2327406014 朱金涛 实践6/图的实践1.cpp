#include <bits/stdc++.h>
#include "MALgraph.h"
#include "MGraph.h"
#define MaxNum 100
using namespace std;

int main()
{
    int a[MaxNum]{0};
    ifstream infile("string.in");
    string line1;
    string line2;
    string line3;
    getline(infile, line1);
    getline(infile, line2);
    getline(infile, line3);
    int i = 0;
    istringstream iss2(line2);
    int num;
    while (iss2 >> num)
    {
        a[i] = num;
        i++;
    }
    // MGraph<int> *g = new MGraph<int>(a, line1, line3);
    ALgraph<int> *g = new ALgraph<int>(a, line1, line3);
    g->DFTraverse(0);
}