#include <bits/stdc++.h>
#include "MGraph.h"
#define MaxNum 100
using namespace std;

template <typename T>
void MGraph<T>::cout_path(int start, int end)
{

    if (path[start][end] == -1)
    {
        return;
    }
    cout_path(start, path[start][end]);
    cout << vertex[path[start][end]] << "->";
    cout_path(path[start][end], end);
}

template <typename T>
void MGraph<T>::Floyd()
{
    int i, j, k;
    for (i = 0; i < vertexNum; i++)
        for (j = 0; j < vertexNum; j++)
        {
            dist[i][j] = edge[i][j];
            path[i][j] = -1;
        }

    for (k = 0; k < vertexNum; k++)
        for (i = 0; i < vertexNum; i++)
            for (j = 0; j < vertexNum; j++)
                if (dist[i][k] + dist[k][j] < dist[i][j])
                {
                    dist[i][j] = dist[i][k] + dist[k][j];
                    path[i][j] = k;
                }
}

int main()
{
    string a[MaxNum];
    ifstream infile("string.in");
    string line1;
    string line2;
    string line3;
    getline(infile, line1);
    getline(infile, line2);
    getline(infile, line3);
    int i = 0;
    istringstream iss2(line2);
    string num;
    while (iss2 >> num)
    {
        a[i] = num;
        i++;
    }
    MGraph<string> *graph = new MGraph<string>(a, line1, line3);
    graph->Floyd();
    string an, bn;
    cin >> an >> bn;
    int x, y;
    for (int i = 0; i < graph->vertexNum; i++)
    {
        if (a[i] == an)
        {
            x = i;
        }
        if (a[i] == bn)
        {
            y = i;
        }
    }
    cout << graph->dist[x][y] - 1 << endl;
    cout << graph->vertex[x] << "->";
    if (graph->dist[x][y] != 1)
    {
        graph->cout_path(x, y);
    }
    cout << graph->vertex[y] << endl;
}