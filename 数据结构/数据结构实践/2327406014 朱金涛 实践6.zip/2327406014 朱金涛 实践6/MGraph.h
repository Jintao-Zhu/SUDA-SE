#ifndef MGRAPH
#include <bits/stdc++.h>
#define MaxSize 1000
using namespace std;

template <typename T>
struct MGraph
{
public:
    MGraph(T a[], string line1, string line2)
    {
        istringstream iss1(line1);
        istringstream iss2(line2);
        int i, j, k;
        int n, e;
        iss1 >> n >> e;
        vertexNum = n;
        edgeNum = e;
        for (i = 0; i < vertexNum; i++)
        {
            vertex[i] = a[i];
        }
        for (i = 0; i < vertexNum; i++)
        {
            for (j = 0; j < vertexNum; j++)
            {
                if (i == j)
                {
                    edge[i][j] = 0;
                }
                else
                {
                    edge[i][j] = 999;
                }
            }
        }
        for (k = 0; k < edgeNum; k++)
        {
            iss2 >> i >> j;
            edge[i][j] = 1;
            edge[j][i] = 1;
        }
    }
    ~MGraph();
    void DFSTraverse(int v)
    {
        cout << vertex[v];
        visted[v] = 1;
        for (int j = 0; j < vertexNum; j++)
        {
            if (edge[v][j] == 1 && visted[j] == 0)
            {
                DFSTraverse(j);
            }
        }
    }
    void BFSTraverse(int v)
    {
        int h, q, w[MaxSize];
        int front = -1, rear = -1;
        cout << vertex[v];
        visted[v] = 1;
        w[++rear] = v;
        while (front != rear)
        {
            h = w[++front];
            for (q = 0; q < vertexNum; q++)
            {
                if (edge[h][q] == 1 && visted[q] == 0)
                {
                    cout << vertex[q];
                    visted[q] = 1;
                    w[++rear] = q;
                }
            }
        }
    }
    void Floyd();
    void cout_path(int start, int end);
    T vertex[MaxSize];
    int visted[MaxSize]{0};
    int edge[MaxSize][MaxSize];
    int vertexNum, edgeNum;
    int path[MaxSize][MaxSize];
    int dist[MaxSize][MaxSize];
};

#endif
