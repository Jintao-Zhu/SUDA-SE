#include <bits/stdc++.h>
using namespace std;
void RecursivePrint(int n)
{
    if (n > 0)
    {
        RecursivePrint(n - 1);
        cout << n << " ";
    }
}

void print2(int n)
{
    for (int i = 1; i <= n; i++)
    {
        cout << i << " ";
    }
}

int main()
{
    int n;
    cin >> n;
    print2(n);
    cout << endl;
    RecursivePrint(n);
    return 0;
}