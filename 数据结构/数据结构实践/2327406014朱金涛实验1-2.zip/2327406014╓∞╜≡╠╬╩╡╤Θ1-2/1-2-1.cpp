#include <bits/stdc++.h>
using namespace std;

void func1(int n, vector<int> lst)
{
    clock_t start_time = clock();
    int max_sum = 0;
    int this_sum = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i; j < n; j++)
        {
            this_sum = 0;
            for (int k = i; k <= j; k++)
            {
                this_sum += lst[k];
            }
            if (this_sum > max_sum)
            {
                max_sum = this_sum;
            }
        }
    }
    clock_t finish_time = clock();
    double time = static_cast<double>(finish_time - start_time) / CLOCKS_PER_SEC;
    cout << "The first time difference is " << time << endl;
    cout << max_sum << endl;
}

void func2(int n, vector<int> lst)
{
    clock_t start_time = clock();
    int max_sum = 0;
    int i, j;
    for (int m = 0; m < 1000; m++)
    {
        for (i = 0; i < n; i++)
        {
            int this_sum = 0;
            for (j = i; j < n; j++)
            {
                this_sum += lst[j];
                if (this_sum > max_sum)
                {
                    max_sum = this_sum;
                }
            }
        }
    }
    clock_t finish_time = clock();
    double time = static_cast<double>(finish_time - start_time) / CLOCKS_PER_SEC;
    cout << "The second time difference is " << time << endl;
    cout << max_sum << endl;
}

void func3(int n, vector<int> lst)
{
    clock_t start_time = clock();
    int max_sum = 0;

    int i, j;
    for (int m = 1; m <= 10000; m++)
    {
        int this_sum = 0;
        for (j = 0; j < n; j++)
        {
            this_sum += lst[j];

            if (this_sum > max_sum)
            {
                max_sum = this_sum;
            }
            else if (this_sum < 0)
            {
                this_sum = 0;
            }
        }
    }
    clock_t finish_time = clock();
    double time = static_cast<double>(finish_time - start_time) / CLOCKS_PER_SEC;
    cout << "The third time difference is " << time << endl;
    cout << max_sum << endl;
}

int main()
{
    int n;
    cin >> n;
    srand((int)time(0));
    vector<int> lst;
    for (int i = 0; i < n; i++)
    {
        int ran_num = (rand() % (100 + 100)) - 100;
        lst.push_back(ran_num);
    }
    func1(n, lst);
    func2(n, lst);
    func3(n, lst);
    return 0;
}