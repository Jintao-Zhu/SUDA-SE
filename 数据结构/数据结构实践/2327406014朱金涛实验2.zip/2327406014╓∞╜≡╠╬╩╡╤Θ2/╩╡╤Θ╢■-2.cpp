#include <iostream>
using namespace std;

class link
{
public:
    virtual ~link() {}
    virtual void init() = 0;
    virtual void destroy() = 0;
    virtual void create(int n, int lst[]) = 0;
    virtual void insert(int k, int value) = 0;
    virtual void remove(int k) = 0;
    virtual int get(int k) = 0;

    int length = 0;
};

class single_link : public link
{
public:
    struct node
    {
        int value;
        node *next;
        node() : next(NULL) {}
    };
    node *head;

    single_link() : head(NULL) {}
    void init() override
    {
        head = NULL;
        length = 0;
    }
    void destroy() override
    {
        node *temp = head;
        while (temp)
        {
            node *next = temp->next;
            delete temp;
            temp = next;
        }
        head = NULL;
        length = 0;
    }

    void create(int n, int lst[]) override
    {
        if (n == 0)
        {
            head = NULL;
            length = 0;
            return;
        }
        node *first = new node;
        first->value = lst[0];
        head = first;
        length++;
        for (int i = 1; i < n; i++)
        {
            node *temp = new node;
            temp->value = lst[i];
            first->next = temp;
            first = temp;
            length++;
        }
    }

    void insert(int k, int v) override
    {
        if (k < 1 || k > length + 1)
        {
            throw std::runtime_error("Invalid position for insertion.");
        }
        node *new_node = new node;
        new_node->value = v;
        if (k == 1)
        {
            new_node->next = head;
            head = new_node;
        }
        else
        {
            node *temp_node = head;
            for (int i = 1; i < k - 1; i++)
            {
                temp_node = temp_node->next;
            }
            new_node->next = temp_node->next;
            temp_node->next = new_node;
        }
        length++;
    }

    void remove(int k) override
    {
        if (k < 1 || k > length)
        {
            throw std::runtime_error("Invalid position for removal.");
        }
        node *temp_node = head;
        if (k == 1)
        {
            head = head->next;
            delete temp_node;
        }
        else
        {
            for (int i = 1; i < k - 1; i++)
            {
                temp_node = temp_node->next;
            }
            node *to_delete = temp_node->next;
            temp_node->next = temp_node->next->next;
            delete to_delete;
        }
        length--;
    }

    int get(int k) override
    {
        if (k < 1 || k > length)
        {
            throw std::runtime_error("Invalid position for retrieval.");
        }
        node *temp_node = head;
        for (int i = 1; i < k; i++)
        {
            temp_node = temp_node->next;
        }
        return temp_node->value;
    }

    node *search(int x)
    {
        node *temp_node = head;
        while (temp_node)
        {
            if (temp_node->value == x)
            {
                return temp_node;
            }
            temp_node = temp_node->next;
        }
        return NULL;
    }

    ~single_link()
    {
        destroy();
    }
};

class double_link : public link
{
public:
    struct node
    {
        int value;
        node *pre;
        node *next;
        node() : pre(NULL), next(NULL) {}
    };
    node *head;

    double_link() : head(NULL) {}
    void init() override
    {
        head = NULL;
        length = 0;
    }
    void destroy() override
    {
        node *temp_node = head;
        while (temp_node)
        {
            node *next = temp_node->next;
            delete temp_node;
            temp_node = next;
        }
        head = NULL;
        length = 0;
    }

    void create(int n, int lst[]) override
    {
        if (n == 0)
        {
            head = NULL;
            length = 0;
            return;
        }
        node *first = new node;
        first->value = lst[0];
        head = first;
        length++;
        for (int i = 1; i < n; i++)
        {
            node *temp = new node;
            temp->value = lst[i];
            temp->pre = first;
            first->next = temp;
            first = temp;
            length++;
        }
    }

    void insert(int k, int v) override
    {
        if (k < 1 || k > length + 1)
        {
            throw std::runtime_error("Invalid position for insertion.");
        }
        node *new_node = new node;
        new_node->value = v;
        if (k == 1)
        {
            if (head)
            {
                new_node->next = head;
                head->pre = new_node;
            }
            head = new_node;
        }
        else
        {
            node *temp_node = head;
            for (int i = 1; i < k - 1; i++)
            {
                temp_node = temp_node->next;
            }
            new_node->next = temp_node->next;
            if (temp_node->next)
            {
                temp_node->next->pre = new_node;
            }
            temp_node->next = new_node;
            new_node->pre = temp_node;
        }
        length++;
    }

    void remove(int k) override
    {
        if (k < 1 || k > length)
        {
            throw std::runtime_error("Invalid position for removal.");
        }
        node *temp_node = head;
        if (k == 1)
        {
            head = head->next;
            if (head)
            {
                head->pre = NULL;
            }
            delete temp_node;
        }
        else
        {
            for (int i = 1; i < k; i++)
            {
                temp_node = temp_node->next;
            }
            temp_node->pre->next = temp_node->next;
            if (temp_node->next)
            {
                temp_node->next->pre = temp_node->pre;
            }
            delete temp_node;
        }
        length--;
    }

    int get(int k) override
    {
        if (k < 1 || k > length)
        {
            throw std::runtime_error("Invalid position for retrieval.");
        }
        node *temp_node = head;
        for (int i = 1; i < k; i++)
        {
            temp_node = temp_node->next;
        }
        return temp_node->value;
    }

    node *search(int x)
    {
        node *temp_node = head;
        while (temp_node)
        {
            if (temp_node->value == x)
            {
                return temp_node;
            }
            temp_node = temp_node->next;
        }
        return NULL;
    }

    ~double_link()
    {
        destroy();
    }
};

class circle_link : public link
{
public:
    struct node
    {
        int value;
        node *next;
        node() : next(NULL) {}
    };
    node *head;

    circle_link() : head(NULL) {}
    void init() override
    {
        head = NULL;
        length = 0;
    }
    void destroy() override
    {
        if (!head)
            return;
        node *temp = head->next;
        node *to_delete = new node;
        do
        {
            to_delete = temp;
            temp = temp->next;
            delete to_delete;
        } while (temp != head);
        head = NULL;
        length = 0;
    }

    void create(int n, int lst[]) override
    {
        if (n == 0)
        {
            head = NULL;
            length = 0;
            return;
        }
        node *first = new node;
        first->value = lst[0];
        head = first;
        length++;
        node *temp = head;
        for (int i = 1; i < n; i++)
        {
            node *new_node = new node;
            new_node->value = lst[i];
            temp->next = new_node;
            temp = new_node;
            length++;
        }
        temp->next = head;
    }

    void insert(int k, int v) override
    {
        if (k < 1 || k > length + 1)
        {
            throw std::runtime_error("Invalid position for insertion.");
        }
        node *new_node = new node;
        new_node->value = v;
        if (k == 1)
        {
            if (head)
            {
                new_node->next = head;
                node *temp = head;
                while (temp->next != head)
                {
                    temp = temp->next;
                }
                temp->next = new_node;
            }
            else
            {
                head = new_node;
                new_node->next = head;
            }
            head = new_node;
        }
        else if (k == length + 1)
        {
            node *temp = head;
            while (temp->next != head)
            {
                temp = temp->next;
            }
            temp->next = new_node;
            new_node->next = head;
        }
        else
        {
            node *temp_node = head;
            for (int i = 1; i < k - 1; i++)
            {
                temp_node = temp_node->next;
            }
            new_node->next = temp_node->next;
            temp_node->next = new_node;
        }
        length++;
    }

    void remove(int k) override
    {
        if (k < 1 || k > length)
        {
            throw std::runtime_error("Invalid position for removal.");
        }
        if (k == 1)
        {
            if (head == head->next)
            {
                delete head;
                head = NULL;
            }
            else
            {
                node *temp = head;
                while (temp->next != head)
                {
                    temp = temp->next;
                }
                temp->next = head->next;
                delete head;
                head = temp->next;
            }
        }
        else
        {
            node *temp_node = head;
            for (int i = 1; i < k - 1; i++)
            {
                temp_node = temp_node->next;
            }
            node *to_delete = temp_node->next;
            temp_node->next = temp_node->next->next;
            delete to_delete;
        }
        length--;
    }

    int get(int k) override
    {
        if (k < 1 || k > length)
        {
            throw std::runtime_error("Invalid position for retrieval.");
        }
        node *temp_node = head;
        for (int i = 1; i < k; i++)
        {
            temp_node = temp_node->next;
        }
        return temp_node->value;
    }

    node *search(int x)
    {
        node *temp_node = head;
        if (head)
        {
            do
            {
                if (temp_node->value == x)
                {
                    return temp_node;
                }
                temp_node = temp_node->next;
            } while (temp_node != head);
        }
        return NULL;
    }

    ~circle_link()
    {
        destroy();
    }
};

int main()
{
    // ���Ե�����
    single_link singleList;
    singleList.init();
    int singleData[] = {1, 2, 3, 4, 5};
    singleList.create(5, singleData);
    cout << "Single linked list after creation: ";
    for (int i = 1; i <= singleList.length; i++)
    {
        cout << singleList.get(i) << " ";
    }
    cout << endl;
    singleList.insert(1, 10);
    cout << "Single linked list after insertion: ";
    for (int i = 1; i <= singleList.length; i++)
    {
        cout << singleList.get(i) << " ";
    }
    cout << endl;
    singleList.remove(4);
    cout << "Single linked list after removal: ";
    for (int i = 1; i <= singleList.length; i++)
    {
        cout << singleList.get(i) << " ";
    }
    cout << endl;
    int searchValueSingle = 3;
    single_link::node *foundNodeSingle = singleList.search(searchValueSingle);
    if (foundNodeSingle)
    {
        cout << "Value " << searchValueSingle << " found in single linked list." << endl;
    }
    else
    {
        cout << "Value " << searchValueSingle << " not found in single linked list." << endl;
    }

    // ����˫����
    double_link doubleList;
    doubleList.init();
    int doubleData[] = {6, 7, 8, 9, 10};
    doubleList.create(5, doubleData);
    cout << "Double linked list after creation: ";
    for (int i = 1; i <= doubleList.length; i++)
    {
        cout << doubleList.get(i) << " ";
    }
    cout << endl;
    doubleList.insert(3, 15);
    cout << "Double linked list after insertion: ";
    for (int i = 1; i <= doubleList.length; i++)
    {
        cout << doubleList.get(i) << " ";
    }
    cout << endl;
    doubleList.remove(4);
    cout << "Double linked list after removal: ";
    for (int i = 1; i <= doubleList.length; i++)
    {
        cout << doubleList.get(i) << " ";
    }
    cout << endl;
    int searchValueDouble = 8;
    double_link::node *foundNodeDouble = doubleList.search(searchValueDouble);
    if (foundNodeDouble)
    {
        cout << "Value " << searchValueDouble << " found in double linked list." << endl;
    }
    else
    {
        cout << "Value " << searchValueDouble << " not found in double linked list." << endl;
    }

    // ����ѭ������
    circle_link circleList;
    circleList.init();
    int circleData[] = {11, 12, 13, 14, 15};
    circleList.create(5, circleData);
    cout << "Circular linked list after creation: ";
    circle_link::node *temp = circleList.head->next;
    for (int i = 0; i < circleList.length; i++)
    {
        cout << temp->value << " ";
        temp = temp->next;
    }
    cout << endl;
    circleList.insert(1, 20);
    cout << "Circular linked list after insertion: ";
    temp = circleList.head->next;
    for (int i = 0; i < circleList.length; i++)
    {
        cout << temp->value << " ";
        temp = temp->next;
    }
    cout << endl;
    circleList.remove(4);
    cout << "Circular linked list after removal: ";
    temp = circleList.head->next;
    for (int i = 0; i < circleList.length; i++)
    {
        cout << temp->value << " ";
        temp = temp->next;
    }
    cout << endl;
    int searchValueCircle = 13;
    circle_link::node *foundNodeCircle = circleList.search(searchValueCircle);
    if (foundNodeCircle)
    {
        cout << "Value " << searchValueCircle << " found in circular linked list." << endl;
    }
    else
    {
        cout << "Value " << searchValueCircle << " not found in circular linked list." << endl;
    }

    return 0;
}