#include <bits/stdc++.h>
using namespace std;
#define MaxSize 100

class SeqList
{
public:
    SeqList(int lst[], int size);
    virtual void insert_l(int l, int n);
    virtual void Print();
    void replace(int l, int n);

protected:
    int data[MaxSize] = {0};
    int last = -1;
};

class or_seqlist : public SeqList
{
public:
    or_seqlist(int lst[], int size) : SeqList(lst, size) {}

    void insert_v(int e);

    void insert_l(int l, int n);
    void replace(int l, int n);
};

SeqList::SeqList(int lst[], int size)
{
    for (int i = 0; i < size && i < MaxSize; i++)
    {
        data[++last] = lst[i];
    }
}

void SeqList::replace(int l, int n)
{
    if (l <= last && l >= 0)
    {
        data[l] = n;
    }
    else
    {
        cout << "Index out of bounds" << endl;
    }
}

void SeqList::insert_l(int l, int n)
{
    if (l < 0 || l > last + 1 || last + 1 >= MaxSize)
    {
        cout << "Error: Index out of bounds or list is full" << endl;
        return;
    }

    for (int i = last + 1; i > l; i--)
    {
        data[i] = data[i - 1];
    }
    data[l] = n;
    last++;
}
void or_seqlist::insert_v(int e)
{
    if (last + 1 >= MaxSize)
    {
        cout << "Error: List is full" << endl;
        return;
    }
    int i = 0;
    while (i <= last && data[i] < e)
    {
        i++;
    }

    for (int j = last + 1; j > i; j--)
    {
        data[j] = data[j - 1];
    }
    data[i] = e;
    last++;
}

void or_seqlist::insert_l(int l, int n)
{
    if (l < 0 || l > last + 1 || last + 1 >= MaxSize)
    {
        cout << "Error: Index out of bounds or list is full" << endl;
        return;
    }

    for (int i = last + 1; i > l; i--)
    {
        data[i] = data[i - 1];
    }
    data[l] = n;
    last++;
}

void or_seqlist::replace(int l, int n)
{
    if (data[l - 1] > n || data[l + 1] < n)
    {
        cout << "error" << endl;
        return;
    }
    SeqList::replace(l, n);
}

void SeqList::Print()
{
    if (last < 0)
    {
        cout << "List is empty" << endl;
        return;
    }
    for (int k = 0; k <= last; k++)
    {
        if (k > 0)
        {
            cout << " ";
        }
        cout << data[k];
    }
    cout << endl;
}

class UnorderedList : public SeqList
{
public:
    UnorderedList(int lst[], int size) : SeqList(lst, size) {}

    void insert_l(int l, int n)
    {
        if (l < 0 || l > last + 1 || last + 1 >= MaxSize)
        {
            cout << "Error: Index out of bounds or list is full" << endl;
            return;
        }

        for (int i = last + 1; i > l; i--)
        {
            data[i] = data[i - 1];
        }
        data[l] = n;
        last++;
    }
};

int main()
{
    int orderedListData[] = {1, 2, 3, 5, 6, 7, 8, 9};
    int unorderedListData[] = {9, 7, 8, 6, 5, 3, 2, 1};

    or_seqlist orderedList(orderedListData, 8);
    UnorderedList unorderedList(unorderedListData, 8);

    string command;
    int value, index;

    cout << "�����ʽ: \n"
         << "1. ���루�������: insert_v <value>\n"
         << "2. ��λ�ò��루�������: insert_l <index> <value>\n"
         << "3. ��λ�ò��루��˳�����: insert_l <index> <value>\n"
         << "4. �滻: replace <index> <value> <1/2>\n"
         << "5. ��ӡ���������: print_ordered\n"
         << "6. ��ӡ����˳�����: print_unordered\n"
         << "���� 'Q' �� 'q' �˳�����\n";

    while (true)
    {
        cout << "> ";
        getline(cin, command);

        if (command == "Q" || command == "q")
        {
            break;
        }

        if (command.substr(0, 8) == "insert_v")
        {
            value = stoi(command.substr(9));
            orderedList.insert_v(value);
        }
        else if (command.substr(0, 8) == "insert_l")
        {
            size_t space_pos = command.find(' ', 9);
            index = stoi(command.substr(9, space_pos - 9));
            value = stoi(command.substr(space_pos + 1));

            if (command.find("ordered") != string::npos)
            {
                orderedList.insert_l(index, value);
            }
            else
            {
                unorderedList.insert_l(index, value);
            }
        }
        else if (command.substr(0, 7) == "replace")
        {
            size_t space_pos = command.find(' ', 8);
            index = stoi(command.substr(8, space_pos - 8));
            value = stoi(command.substr(space_pos + 1));
            int test = stoi(command.substr(space_pos + 3));
            if (test == 1)
            {
                orderedList.replace(index, value);
            }
            else
            {
                unorderedList.replace(index, value);
            }
        }
        else if (command == "print_ordered")
        {
            orderedList.Print();
        }
        else if (command == "print_unordered")
        {
            unorderedList.Print();
        }
        else
        {
            cout << "��Ч��������ԡ�" << endl;
        }
    }

    return 0;
}