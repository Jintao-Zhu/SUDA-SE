#include <bits/stdc++.h>
using namespace std;

class node
{
public:
    int value;
    node *next;
    node(int v) : value(v), next(nullptr) {};
};

class singleLink
{
public:
    node *head;
    singleLink()
    {
        head = new node(0);
    };

    void append(int v);
    void print();
    void remove(int v);
    bool find(int v);
    ~singleLink();

    // 深拷贝构造函数
    singleLink(const singleLink &other)
    {
        head = new node(0);
        node *temp = head;
        node *other_temp = other.head->next;
        while (other_temp)
        {
            temp->next = new node(other_temp->value);
            temp = temp->next;
            other_temp = other_temp->next;
        }
    }
};

void singleLink::remove(int v)
{
    node *temp = head->next;
    node *ttemp = head;
    while (temp)
    {
        if (temp->value == v)
        {
            ttemp->next = temp->next;
            delete temp;
            return;
        }
        else
        {
            temp = temp->next;
            ttemp = ttemp->next;
        }
    }
    return;
}
void singleLink::append(int v)
{
    node *new_node = new node(v);
    node *temp = head;

    while (temp->next != nullptr && temp->next->value <= v)
    {
        temp = temp->next;
    }

    new_node->next = temp->next;
    temp->next = new_node;
}

void singleLink::print()
{
    node *temp = head->next;
    while (temp)
    {
        cout << temp->value << " ";
        temp = temp->next;
    }
    cout << endl;
}

bool singleLink::find(int v)
{
    node *temp = head->next;
    while (temp)
    {
        if (temp->value == v)
        {
            return true;
        }
        else
        {
            temp = temp->next;
        }
    }
    return false;
}

singleLink::~singleLink()
{
    node *current = head;
    while (current != nullptr)
    {
        node *next = current->next;
        delete current;
        current = next;
    }
}

void read(vector<vector<singleLink>> &decks)
{
    int n;
    ifstream infile("input.txt");

    if (!infile.is_open())
    {
        cerr << "Error opening input.txt" << endl;
        return;
    }

    infile >> n;

    if (infile.fail() || n <= 0)
    {
        cerr << "Invalid number of decks: " << n << endl;
        return;
    }

    decks.resize(n, vector<singleLink>(4)); // 将decks的大小设置为n*4

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < 4; ++j)
        {
            int count;
            infile >> count;

            if (infile.fail() || count < 0)
            {
                cerr << "Invalid card count for deck " << i << ", color " << j << endl;
                return;
            }

            for (int k = 0; k < count; ++k)
            {
                int card;
                infile >> card;
                if (infile.fail())
                {
                    cerr << "Error reading card for deck " << i << ", color " << j << " at position " << k << endl;
                    return;
                }
                decks[i][j].append(card);
            }
        }
    }

    infile.close();
}

// int count_complete_decks(vector<vector<singleLink>> &decks)
// {
//     int complete_sets = 0;
//     int count = 1;

//     while (true)
//     {
//         bool all_found = true;
//         for (int j = 0; j < 4; j++)
//         {
//             bool found = false;
//             for (int i = 0; i < decks.size(); i++)
//             {
//                 if (decks[i][j].find(count))
//                 {
//                     decks[i][j].remove(count);
//                     found = true;
                    
//                     break;
//                 }
//             }
//             if (!found)
//             {
//                 all_found = false;
//                 break;
//             }
//         }

//         if (all_found)
//         {
//             complete_sets++;
//         }
//         else
//         {
//             return complete_sets;
//         }
//     }
// }

int count_complete_decks(vector<vector<singleLink>> &decks)
{
    int complete_sets = 0;

    while (true)
    {
        bool all_found = true;
        vector<vector<int>> to_remove(decks.size(), vector<int>(4, 0));

        for (int count = 1; count <= 13; count++)
        {
            for (int j = 0; j < 4; j++)
            {
                bool found = false;
                for (int i = 0; i < decks.size(); i++)
                {
                    if (decks[i][j].find(count))
                    {
                        to_remove[i][j]++;
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    all_found = false;
                    break;
                }
            }
            if (!all_found)
            {
                break;
            }
        }

        if (all_found)
        {
            complete_sets++;
            // 删除找到的牌点数
            for (int i = 0; i < decks.size(); i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    for (int k = 0; k < to_remove[i][j]; k++)
                    {
                        decks[i][j].remove(k + 1);
                    }
                }
            }
        }
        else
        {
            return complete_sets;
        }
    }
}
void display(vector<vector<singleLink>> &decks)
{

    for (int i = 0; i < decks.size(); i++)
    {
        for (int j = 0; j < 4; j++)
        {
            decks[i][j].print();
        }
    }
}

int main()
{
    vector<vector<singleLink>> lst;
    read(lst);
    int num = count_complete_decks(lst);
    cout << num << endl;
    display(lst);
}

