#include <bits/stdc++.h>
using namespace std;

class node
{
public:
    string value;
    node *next;
    node(string v) : value(v), next(nullptr) {}
};

class linkstack
{
public:
    linkstack() : top(nullptr) {}
    ~linkstack() { clear(); }

    void add(string v)
    {
        node *new_node = new node(v);
        new_node->next = top;
        top = new_node;
    }

    string pop()
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack is empty");
        }
        node *to_delete = top;
        string x = to_delete->value;
        top = top->next;
        delete to_delete;
        return x;
    }

    string gettop()
    {
        return (top == nullptr) ? "error" : top->value;
    }

    void clear()
    {
        while (top != nullptr)
        {
            pop();
        }
    }

private:
    node *top;
};

vector<string> split(string s, char a)
{
    vector<string> lst;
    string temp = "";
    for (char c : s)
    {
        if (c != a)
        {
            temp += c;
        }
        else
        {
            if (!temp.empty())
            {
                lst.push_back(temp);
                temp = "";
            }
        }
    }
    if (!temp.empty())
    {
        lst.push_back(temp);
    }
    return lst;
}

bool isoperator(string s)
{
    return (s == "+" || s == "-" || s == "*" || s == "/");
}

double calculate(double num1, string token, double num2)
{
    if (token == "+")
    {
        return num1 + num2;
    }
    else if (token == "-")
    {
        return num1 - num2;
    }
    else if (token == "*")
    {
        return num1 * num2;
    }
    else
    {
        if (num2 == 0)
        {
            throw runtime_error("Division by zero");
        }
        return num1 / num2;
    }
}

double func(vector<string> lst)
{
    linkstack stack;
    stack.add("#");

    for (int i = lst.size() - 1; i >= 0; i--)
    {
        string token = lst[i];
        if (!isoperator(token))
        {
            stack.add(token);
        }
        else
        {
            try
            {
                double num1 = stod(stack.pop());
                double num2 = stod(stack.pop());
                double result = calculate(num1, token, num2);
                stack.add(to_string(result));
            }
            catch (const exception &e)
            {
                throw runtime_error("Invalid expression");
            }
        }
    }
    double answer = stod(stack.pop());
    return answer;
}

int main()
{

    cout << "Please enter your expression." << endl;

    string ss;
    getline(cin, ss);
    vector<string> lst = split(ss, ' ');
    try
    {
        double answer = func(lst);
        cout << "The answer is:" << endl;
        cout << answer << endl;
    }
    catch (const exception &e)
    {
        cout << e.what() << endl;
    }
}
