#include <bits/stdc++.h>
using namespace std;

class node
{
public:
    string value;
    node *next;
    node(string v) : value(v), next(nullptr) {}
};

class linkstack
{
public:
    linkstack() : top(nullptr) {}
    ~linkstack() { clear(); }

    void add(string v)
    {
        node *new_node = new node(v);
        new_node->next = top;
        top = new_node;
    }

    string pop()
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack is empty");
        }
        node *to_delete = top;
        string x = to_delete->value;
        top = top->next;
        delete to_delete;
        return x;
    }

    string gettop()
    {
        return (top == nullptr) ? "" : top->value; // Return empty string if stack is empty
    }

    void clear()
    {
        while (top != nullptr)
        {
            pop();
        }
    }

private:
    node *top;
};

vector<string> split(string s, char a)
{
    vector<string> lst;
    string temp = "";
    for (char c : s)
    {
        if (c != a)
        {
            temp += c;
        }
        else
        {
            if (!temp.empty())
            {
                lst.push_back(temp);
                temp = "";
            }
        }
    }
    if (!temp.empty())
    {
        lst.push_back(temp);
    }
    return lst;
}

bool isop(string s)
{
    return (s == "+" || s == "-" || s == "*" || s == "/" || s == "(" || s == ")");
}

double calculate(double num1, string token, double num2)
{
    if (token == "+")
        return num1 + num2;
    if (token == "-")
        return num1 - num2;
    if (token == "*")
        return num1 * num2;
    if (token == "/")
    {
        if (num2 == 0)
            throw runtime_error("Division by zero");
        return num1 / num2;
    }
    throw runtime_error("Invalid operator");
}

double func(vector<string> lst)
{
    map<string, int> dic{{"#", 0}, {"+", 1}, {"-", 1}, {"*", 2}, {"/", 2}};
    linkstack op;
    linkstack nums;
    op.add("#");
    nums.add("#");
    for (const string &token : lst)
    {
        if (isop(token))
        {
            if (token == "(")
            {
                op.add("#");
            }
            else if (token == ")")
            {
                while (op.gettop() != "#")
                {
                    string opera = op.pop();
                    double num2 = stod(nums.pop());
                    double num1 = stod(nums.pop());
                    double answer = calculate(num1, opera, num2);
                    nums.add(to_string(answer));
                }
                op.pop();
            }
            else
            {
                while (op.gettop() != "#" && dic[token] <= dic[op.gettop()])
                {
                    string opera = op.pop();
                    double num2 = stod(nums.pop());
                    double num1 = stod(nums.pop());
                    double answer = calculate(num1, opera, num2);
                    nums.add(to_string(answer));
                }
                op.add(token);
            }
        }
        else
        {
            nums.add(token);
        }
    }

    while (op.gettop() != "#")
    {
        string opera = op.pop();
        double num2 = stod(nums.pop());
        double num1 = stod(nums.pop());
        double answer = calculate(num1, opera, num2);
        nums.add(to_string(answer));
    }

    return stod(nums.pop());
}

int main()
{
    cout << "Please enter your expression." << endl;
    string s;
    getline(cin, s);
    vector<string> lst = split(s, ' ');
    double answer = func(lst);
    cout << "The answer is:" << endl;
    cout << answer << endl;
}
