#include <bits/stdc++.h>
using namespace std;

class large_number
{
public:
    large_number()
    {
        s = "";
        length = 0;
    }

    large_number(string ss) : s(ss)
    {
        if (s[0] == '-')
        {
            sign = -1;
            s = s.substr(1);
        }
        length = s.length();
        digits.resize(length, 0);
        for (int i = 0; i < length; i++)
        {
            digits[length - i - 1] = s[i] - '0';
        }
    }

    void print();

    string s;
    int length;
    vector<int> digits;
    int sign = 1;
};

void large_number::print()
{
    if (length == 0 || (length == 1 && digits[0] == 0))
    {
        cout << "0" << endl;
        return;
    }
    if (sign == -1)
    {
        cout << '-';
    }
    for (int i = length - 1; i >= 0; i--)
    {
        cout << digits[i];
    }
    cout << endl;
}

large_number BigIntAdd(large_number a, large_number b)
{

    if (a.sign != b.sign)
    {

        cout << "Subtraction not implemented yet" << endl;
        exit(1);
        return large_number();
    }

    large_number c;
    c.sign = a.sign;
    c.length = max(a.length, b.length) + 1;
    c.digits.resize(c.length, 0);

    int carry = 0;
    for (int i = 0; i < c.length; i++)
    {
        int x = (i < a.length) ? a.digits[i] : 0;
        int y = (i < b.length) ? b.digits[i] : 0;

        c.digits[i] = x + y + carry;
        carry = c.digits[i] / 10;
        c.digits[i] = c.digits[i] % 10;
    }

    if (c.digits[c.length - 1] == 0)
    {
        c.length--;
    }

    return c;
}

large_number BigIntMultiply(large_number a, large_number b)
{

    large_number c;
    if (a.length == 0 || b.length == 0)
    {
        c.length = 0;
    }
    else
    {
        if (a.sign == b.sign)
        {
            c.sign = 1;
        }
        else
        {
            c.sign = -1;
        }

        c.length = a.length + b.length;
        c.digits.resize(c.length, 0);
        for (int i = 0; i < a.length; i++)
        {
            for (int j = 0; j < b.length; j++)
            {
                c.digits[i + j] += a.digits[i] * b.digits[j];
            }
        }
        int carry = 0;
        for (int i = 0; i < c.length - 1; i++)
        {
            int temp = c.digits[i] + carry;
            c.digits[i] = temp % 10;
            carry = temp / 10;
        }

        if (carry > 0)
        {
            c.digits[c.length - 1] = carry;
        }
        else
        {
            c.length--;
        }
    }
    return c;
}

int main()
{
    cout << "Please input the large numbers." << endl;
    string a, b;
    cin >> a >> b;

    large_number aa(a);
    large_number bb(b);
    large_number cc = BigIntAdd(aa, bb);
    cout << "The add result is:" << endl;
    cc.print();
    large_number dd = BigIntMultiply(aa, bb);
    cout << "The multipy result is:" << endl;
    dd.print();
    return 0;
}