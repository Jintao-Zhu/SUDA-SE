#include <bits/stdc++.h>
using namespace std;
const int Maxsize = 100;

class node
{
public:
    int value;
    node *next;
    node(int v) : value(v), next(nullptr) {}
};

class linkstack
{
public:
    linkstack() : top(nullptr) {}
    ~linkstack() { clear(); }

    void add(int v)
    {
        node *new_node = new node(v);
        new_node->next = top;
        top = new_node;
    }

    int pop()
    {
        if (top == nullptr)
        {
            throw runtime_error("Stack is empty");
        }
        node *to_delete = top;
        int x = to_delete->value;
        top = top->next;
        delete to_delete;
        return x;
    }

    int gettop()
    {
        return (top == nullptr) ? -1 : top->value;
    }
    bool find(int v)
    {
        node *temp = top;
        while (temp)
        {
            if (temp->value == v)
            {
                return true;
            }
            else
            {
                temp = temp->next;
            }
        }
        return false;
    }

    void clear()
    {
        while (top != nullptr)
        {
            pop();
        }
    }

private:
    node *top;
};

class seq
{
public:
    int lst[Maxsize]{0};
    int front, tail;
    int size;
    seq() : front(-1), tail(-1), size(0) {}

    seq(vector<int> lst)
    {
        for (int nnum : lst)
        {
            this->in(nnum);
        }
    }
    int ou()
    {
        if (front == tail)
        {
            throw "error";
        }
        front = (front + 1) % Maxsize;
        size--;
        return lst[front];
    }
    void in(int v)
    {
        tail = (tail + 1) % Maxsize;
        if (tail == front)
        {
            return;
        }
        size++;
        lst[tail] = v;
    }

    bool empty()
    {
        if (front == tail)
        {
            return true;
        }
        return false;
    }

    ~seq()
    {

        front = -1;
        tail = -1;
        size = 0;
    }
};

void func(seq a, seq b)
{
    linkstack fild;

    while (!a.empty() && !b.empty())
    {

        int num = a.ou();
        if (fild.find(num))
        {

            linkstack fc;
            fc.add(num);
            while (fild.gettop() != num)
            {
                fc.add(fild.pop());
            }
            fc.add(fild.pop());
            while (fc.gettop() != -1)
            {
                a.in(fc.pop());
            }
        }
        else
        {
            fild.add(num);
        }

        int num1 = b.ou();

        if (fild.find(num1))
        {
            linkstack fc;
            fc.add(num1);
            while (fild.gettop() != num1)
            {
                fc.add(fild.pop());
            }
            fc.add(fild.pop());
            while (fc.gettop() != -1)
            {
                b.in(fc.pop());
            }
        }
        else
        {
            fild.add(num1);
        }
    }

    if (a.empty())
    {
        cout << "a win!" << endl;
    }
    else
    {
        cout << "b win!" << endl;
    }
}
vector<int> split(string s, char a)
{
    vector<int> lst;
    string temp = "";
    for (char c : s)
    {
        if (c != a)
        {
            temp += c;
        }
        else
        {
            if (!temp.empty())
            {
                lst.push_back(stoi(temp));
                temp = "";
            }
        }
    }
    if (!temp.empty())
    {
        lst.push_back(stoi(temp));
    }
    return lst;
}

int main()
{
    string s;
    cout << "Please input a's cards." << endl;
    getline(cin, s);
    vector<int> lst1 = split(s, ' ');
    seq a = seq(lst1);
    string ss;
    cout << "Please input b's cards." << endl;
    getline(cin, ss);
    vector<int> lst2 = split(ss, ' ');
    seq b = seq(lst2);
    func(a, b);
    return 0;
}
