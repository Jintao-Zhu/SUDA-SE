#include <bits/stdc++.h>
#include "MySort.h"
using namespace std;
const int MaxSize = 10000;

int main()
{
    int a[MaxSize] = {0};
    std::ifstream infile("test_2000_reverse.txt");
    string s;
    getline(infile, s);
    std::istringstream stream(s);
    int num;
    int i = 0;
    while (stream >> num)
    {
        a[i] = num;
        i++;
    }

    MySort *test2 = new MySort(a, i + 1);
    MySort *test3 = new MySort(a, i + 1);
    MySort *test4 = new MySort(a, i + 1);
    MySort *test5 = new MySort(a, i + 1);
    MySort *test6 = new MySort(a, i + 1);
    MySort *test7 = new MySort(a, i + 1);
    cout << "2000 reverse result:" << endl;
    clock_t start = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->InsertSort();
    }
    clock_t end = clock();
    cout << "The InsertSort run time is: " << (double)(end - start) / CLOCKS_PER_SEC << "s" << endl;
    clock_t start2 = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->ShellSort();
    }
    clock_t end2 = clock();
    cout << "The ShellSort run time is: " << (double)(end2 - start2) / CLOCKS_PER_SEC << "s" << endl;
    clock_t start3 = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->BubbleSort();
    }
    clock_t end3 = clock();
    cout << "The BubbleSort run time is: " << (double)(end3 - start3) / CLOCKS_PER_SEC << "s" << endl;
    clock_t start4 = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->QuickSort(0, test1->length - 1);
    }
    clock_t end4 = clock();
    cout << "The QuickSort run time is: " << (double)(end4 - start4) / CLOCKS_PER_SEC << "s" << endl;
    clock_t start5 = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->SelectSort();
    }
    clock_t end5 = clock();
    cout << "The SelectSort run time is: " << (double)(end5 - start5) / CLOCKS_PER_SEC << "s" << endl;
    clock_t start6 = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->HeapSort();
    }
    clock_t end6 = clock();
    cout << "The HeapSort run time is: " << (double)(end6 - start6) / CLOCKS_PER_SEC << "s" << endl;
    clock_t start7 = clock();
    for (int j = 0; j < 1000; j++)
    {
        MySort *test1 = new MySort(a, i + 1);
        test1->MergeSort1(0, test1->length - 1);
    }
    clock_t end7 = clock();
    cout << "The MergeSort run time is: " << (double)(end7 - start7) / CLOCKS_PER_SEC << "s" << endl;

    return 0;
}
