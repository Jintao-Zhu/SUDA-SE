#include <bits/stdc++.h>
using namespace std;

class MySort
{
public:
    void sift(int k, int last)
    {
        int i = k;
        int j = 2 * i + 1;
        while (j <= last)
        {
            if (j < last && data[j] < data[j + 1])
            {
                j++;
            }
            if (data[i] > data[j])
            {
                break;
            }
            else
            {
                swap(data[i], data[j]);
                i = j;
                j = 2 * i + 1;
            }
        }
    }
    void Merge(int first1, int last1, int last2)
    {
        int temp[length] = {0};
        int i = first1, j = last1 + 1, k = first1;
        while (i <= last1 && j <= last2)
        {
            if (data[i] <= data[j])
            {
                temp[k++] = data[i++];
            }
            else
            {
                temp[k++] = data[j++];
            }
        }
        while (i <= last1)
        {
            temp[k++] = data[i++];
        }
        while (j <= last2)
        {
            temp[k++] = data[j++];
        }
        for (i = first1; i <= last2; i++)
        {
            data[i] = temp[i];
        }
    }
    int *data;
    int length;

    MySort(int r[], int n)
    {
        length = n;
        data = new int[length];
        for (int i = 0; i < n; i++)
        {
            data[i] = r[i];
        }
    }
    ~MySort()
    {
        delete[] data;
        length = 0;
    }
    void InsertSort()
    {
        int i, j, temp;
        for (i = 1; i < length; i++)
        {
            temp = data[i];
            j = i - 1;
            while (j >= 0 && temp < data[j])
            {
                data[j + 1] = data[j];
                j--;
            }
            data[j + 1] = temp;
        }
    }
    void ShellSort()
    {
        int i, j, temp, d;
        for (d = length / 2; d >= 1; d /= 2)
        {
            for (i = d; i < length; i++)
            {
                temp = data[i];
                for (j = i - d; j >= 0 && temp < data[j]; j -= d)
                {
                    data[j + d] = data[j];
                }
                data[j + d] = temp;
            }
        }
    }
    void BubbleSort()
    {
        int j, exchange, temp, bound;
        exchange = length - 1;
        while (exchange != 0)
        {
            bound = exchange;
            exchange = 0;
            for (j = 0; j < bound; j++)
            {
                if (data[j] > data[j + 1])
                {
                    temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                    exchange = j;
                }
            }
        }
    }
    void QuickSort(int start, int end)
    {
        int low = start;
        int high = end;
        if (low < high)
        {
            while (low < high)
            {
                while (data[low] <= data[start] && low < end)
                {
                    low++;
                }
                while (data[high] >= data[start] && high > start)
                {
                    high--;
                }
                if (low < high)
                {
                    swap(data[low], data[high]);
                }
                else
                {
                    break;
                }
            }
            swap(data[start], data[high]);
            QuickSort(start, high - 1);
            QuickSort(high + 1, end);
        }
    }
    void SelectSort()
    {
        int i, index, j, temp;
        for (i = 0; i < length - 1; i++)
        {
            index = i;
            for (j = i + 1; j < length; j++)
            {
                if (data[j] < data[index])
                {
                    index = j;
                }
            }
            if (index != i)
            {
                temp = data[index];
                data[index] = data[i];
                data[i] = temp;
            }
        }
    }
    void HeapSort()
    {
        int i, temp;
        for (i = ceil(length / 2) - 1; i >= 0; i--)
        {
            sift(i, length - 1);
        }
        for (i = 1; i < length; i++)
        {
            temp = data[0];
            data[0] = data[length - i];
            data[length - i] = temp;
            sift(0, length - i - 1);
        }
    }
    void MergeSort1(int first, int last)
    {
        if (first >= last)
        {
            return;
        }
        else
        {
            int mid = (first + last) / 2;
            MergeSort1(first, mid);
            MergeSort1(mid + 1, last);
            Merge(first, mid, last);
        }
    }
    void Print()
    {
        for (int i = 0; i < length; i++)
        {
            cout << data[i] << " ";
        }
        cout << endl;
    }
};