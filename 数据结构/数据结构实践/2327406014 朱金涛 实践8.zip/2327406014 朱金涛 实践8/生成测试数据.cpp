#include <bits/stdc++.h>
using namespace std;

int main()
{
    random_device rd;
    mt19937 gen(rd());

    // ����1��20�������
    {
        uniform_int_distribution<int> dis(1, 20);
        ofstream outfile("test_20_random.txt");
        ofstream outfile1("test_20_sorted.txt");
        ofstream outfile2("test_20_reverse.txt");

        if (!outfile || !outfile1 || !outfile2)
        {
            cerr << "�޷����ļ�!" << endl;
            return 1;
        }

        for (int i = 0; i < 20; i++)
        {
            int randnum = dis(gen);
            outfile << randnum << " ";
            outfile1 << i + 1 << " ";
            outfile2 << 20 - i << " ";
        }

        outfile.close();
        outfile1.close();
        outfile2.close();
    }

    // ����1��200�������
    {
        uniform_int_distribution<int> dis(1, 200);
        ofstream outfile3("test_200_random.txt");
        ofstream outfile4("test_200_sorted.txt");
        ofstream outfile5("test_200_reverse.txt");

        if (!outfile3 || !outfile4 || !outfile5)
        {
            cerr << "�޷����ļ�!" << endl;
            return 1;
        }

        for (int i = 0; i < 200; i++)
        {
            int randnum = dis(gen);
            outfile3 << randnum << " ";
            outfile4 << i + 1 << " ";
            outfile5 << 200 - i << " ";
        }

        outfile3.close();
        outfile4.close();
        outfile5.close();
    }

    // ����1��2000�������
    {
        uniform_int_distribution<int> dis(1, 2000);
        ofstream outfile6("test_2000_random.txt");
        ofstream outfile7("test_2000_sorted.txt");
        ofstream outfile8("test_2000_reverse.txt");

        if (!outfile6 || !outfile7 || !outfile8)
        {
            cerr << "�޷����ļ�!" << endl;
            return 1;
        }

        for (int i = 0; i < 2000; i++)
        {
            int randnum = dis(gen);
            outfile6 << randnum << " ";
            outfile7 << i + 1 << " ";
            outfile8 << 2000 - i << " ";
        }

        outfile6.close();
        outfile7.close();
        outfile8.close();
    }

    return 0;
}