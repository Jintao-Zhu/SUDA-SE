#include <bits/stdc++.h>
using namespace std;
const int maxsize = 100000;

bool csearch(vector<int> lst, int k)
{
    for (int i = 0; i < lst.size(); i++)
    {
        if (lst[i] == k)
        {
            return true;
        }
    }
    return false;
}

bool rebsearch(vector<int> lst, int left, int right, int k)
{
    if (left > right)
        return false;
    int mid = (left + right) / 2;
    if (lst[mid] > k)
        return rebsearch(lst, left, mid - 1, k);
    else if (lst[mid] < k)
        return rebsearch(lst, mid + 1, right, k);
    else
        return true;
}

bool bsearch(vector<int> lst, int k)
{
    int left = 0, mid, right = lst.size();
    while (left <= right)
    {
        mid = (left + right) / 2;
        if (lst[mid] > k)
        {
            right = mid - 1;
        }
        else if (lst[mid] < k)
        {
            left = mid + 1;
        }
        else
        {
            return true;
        }
    }
    return false;
}

int main()
{
    int n;
    cin >> n;
    random_device rd;
    mt19937 gen(rd());
    vector<int> lst(maxsize, 0);
    for (int i = 0; i < n; i++)
    {
        int num;
        cin >> num;
        lst[i] = num;
    }

    sort(lst.begin(), lst.end());
    clock_t start_time = clock();
    for (int i = 0; i < 1000; i++)
    {
        uniform_int_distribution<int> dis(1, 9);
        int randnum = dis(gen);
        csearch(lst, randnum);
    }
    clock_t end_time = clock();
    cout << "The true csearch run time is: " << (double)(end_time - start_time) / CLOCKS_PER_SEC << "s" << endl;

    clock_t start_time1 = clock();
    for (int i = 0; i < 1000; i++)
    {

        uniform_int_distribution<int> dis(11, 20);
        int randnum = dis(gen);
        csearch(lst, randnum);
    }
    clock_t end_time1 = clock();
    cout << "The false csearch run time is: " << (double)(end_time1 - start_time1) / CLOCKS_PER_SEC << "s" << endl;
}

// �����������ϴ�ʱ��Ĳ���main����
//  int main()
//  {
//      int n;
//      cin >> n;
//      random_device rd;
//      mt19937 gen(rd());
//      vector<int> lst(maxsize, 0);
//      for (int i = 1; i <= n; i++)
//      {
//          lst[i] = 1;
//      }

//     clock_t start_time = clock();
//     for (int i = 0; i < 10000; i++)
//     {
//         uniform_int_distribution<int> dis(1, 9);
//         int randnum = dis(gen);
//         csearch(lst, randnum);
//     }
//     clock_t end_time = clock();
//     cout << "The true csearch run time is: " << (double)(end_time - start_time) / CLOCKS_PER_SEC << "s" << endl;

//     clock_t start_time2 = clock();
//     for (int i = 0; i < 1000; i++)
//     {
//         uniform_int_distribution<int> dis(1, 9);
//         int randnum = dis(gen);
//         rebsearch(lst, 0, n, randnum);
//     }
//     clock_t end_time2 = clock();
//     cout << "The true rebsearch run time is: " << (double)(end_time2 - start_time2) / CLOCKS_PER_SEC << "s" << endl;

//     clock_t start_time1 = clock();
//     for (int i = 0; i < 1000; i++)
//     {

//         uniform_int_distribution<int> dis(11, 20);
//         int randnum = dis(gen);
//         csearch(lst, randnum);
//     }
//     clock_t end_time1 = clock();
//     cout << "The false csearch run time is: " << (double)(end_time1 - start_time1) / CLOCKS_PER_SEC << "s" << endl;

//     clock_t start_time3 = clock();
//     for (int i = 0; i < 1000; i++)
//     {
//         uniform_int_distribution<int> dis(11, 20);
//         int randnum = dis(gen);
//         rebsearch(lst, 0, n, randnum);
//     }
//     clock_t end_time3 = clock();
//     cout << "The false rebsearch run time is: " << (double)(end_time3 - start_time3) / CLOCKS_PER_SEC << "s" << endl;
// }
