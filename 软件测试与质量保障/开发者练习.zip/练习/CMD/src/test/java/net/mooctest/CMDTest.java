package net.mooctest;

import static org.junit.Assert.*;

import org.junit.Test;

public class CMDTest {

	@Test
	public void test() {
		new CMD();
	}

}
