package net.mooctest;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.util.Random;
import java.util.concurrent.ThreadPoolExecutor;

import static org.junit.Assert.*;

// 9245 9249 9253 9257
// 9241 9245 9249

public class AlgorithmFactoryTest {

    @Test
    public void test() {
    }
}
