package net.mooctest;

public class AlgorithmNotFoundException extends RuntimeException {
    public AlgorithmNotFoundException(String message) {
        super(message);
    }
}
