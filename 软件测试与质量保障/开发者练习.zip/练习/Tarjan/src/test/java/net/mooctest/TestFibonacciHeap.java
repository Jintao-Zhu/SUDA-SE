package net.mooctest;

import net.mooctest.ChuLiuEdmonds;
import com.google.common.base.Optional;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import sun.security.krb5.internal.crypto.Des;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.*;

public class TestFibonacciHeap {
	@Test
	public void test() {

		
	}
}