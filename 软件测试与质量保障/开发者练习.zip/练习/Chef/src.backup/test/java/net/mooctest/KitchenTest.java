package net.mooctest;

import org.junit.Test;

public class KitchenTest {

  @Test(timeout = 4000)
  public void test(){
      Recipe recipe = new Recipe("");
  }
}
