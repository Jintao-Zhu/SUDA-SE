package net.mooctest;

import org.junit.Test;

import java.io.*;

public class KitchenTest {

    @Test
    public void test() throws Exception {

    }
}
