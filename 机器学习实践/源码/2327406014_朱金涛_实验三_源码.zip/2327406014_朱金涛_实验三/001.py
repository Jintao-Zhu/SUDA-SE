import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
import time
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import matplotlib.font_manager as fm
from mpl_toolkits.mplot3d import Axes3D

# 字体设置
def find_available_chinese_font(): 
    chinese_fonts = [
        "SimHei", "WenQuanYi Micro Hei", "Heiti TC",
        "Microsoft YaHei", "SimSun", "NSimSun",
        "STSong", "STHeiti", "Arial Unicode MS"
    ]
    try:
        installed_fonts = [f.name for f in fm.findSystemFonts(fontpaths=None, fontext='ttf')]
    except AttributeError:
        font_paths = fm.findSystemFonts(fontpaths=None, fontext='ttf')
        installed_fonts = []
        for path in font_paths:
            try:
                font = fm.FontProperties(fname=path)
                installed_fonts.append(font.get_name())
            except:
                continue
    for font in chinese_fonts:
        if font in installed_fonts:
            return font
    return None

chinese_font = find_available_chinese_font()
if chinese_font:
    plt.rcParams["font.family"] = chinese_font
else:
    print("警告：未找到中文字体，图表将使用英文标签")
plt.rcParams["axes.unicode_minus"] = False

class LogisticRegression:
    """手动实现的Logistic回归分类器"""
    
    def __init__(self, learning_rate=0.01, max_iterations=1000):
        self.learning_rate = learning_rate
        self.max_iterations = max_iterations
        self.weights = None
        self.bias = None
        self.cost_history = []
        
    def sigmoid(self, z):
        """Sigmoid激活函数，防止数值溢出"""
        # 限制z的范围避免溢出
        z = np.clip(z, -500, 500)
        return 1 / (1 + np.exp(-z))
    
    def compute_cost(self, y_true, y_pred):
        """计算logistic回归损失函数（交叉熵损失）"""
        # 防止log(0)的情况
        epsilon = 1e-15
        y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
        
        m = len(y_true)
        cost = -1/m * np.sum(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))
        return cost
    
    def fit(self, X, y, X_val=None, y_val=None, X_test=None, y_test=None):
        """训练模型并记录训练过程"""
        # 初始化参数
        m, n = X.shape
        self.weights = np.random.normal(0, 0.01, n)
        self.bias = 0
        
        # 记录损失历史
        self.train_costs = []
        self.val_costs = []
        self.test_costs = []
        
        for i in range(self.max_iterations):
            # 前向传播
            z = np.dot(X, self.weights) + self.bias
            y_pred = self.sigmoid(z)
            
            # 计算损失
            train_cost = self.compute_cost(y, y_pred)
            self.train_costs.append(train_cost)
            
            # 验证集损失
            if X_val is not None and y_val is not None:
                z_val = np.dot(X_val, self.weights) + self.bias
                y_pred_val = self.sigmoid(z_val)
                val_cost = self.compute_cost(y_val, y_pred_val)
                self.val_costs.append(val_cost)
            
            # 测试集损失
            if X_test is not None and y_test is not None:
                z_test = np.dot(X_test, self.weights) + self.bias
                y_pred_test = self.sigmoid(z_test)
                test_cost = self.compute_cost(y_test, y_pred_test)
                self.test_costs.append(test_cost)
            
            # 计算梯度
            dw = 1/m * np.dot(X.T, (y_pred - y))
            db = 1/m * np.sum(y_pred - y)
            
            # 更新参数
            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db
            
            # 记录历史（用于绘图）
            self.cost_history.append(train_cost)
    
    def predict_proba(self, X):
        """预测概率"""
        z = np.dot(X, self.weights) + self.bias
        return self.sigmoid(z)
    
    def predict(self, X, threshold=0.5):
        """预测类别"""
        return (self.predict_proba(X) >= threshold).astype(int)

class PyTorchLogisticRegression(nn.Module):
    """PyTorch实现的Logistic回归"""
    
    def __init__(self, input_size):
        super(PyTorchLogisticRegression, self).__init__()
        self.linear = nn.Linear(input_size, 1)
        
    def forward(self, x):
        return torch.sigmoid(self.linear(x))

def generate_dataset_with_ratio(n_samples=200, class_ratio=0.5, random_seed=42):
    """生成指定类别比例的数据集"""
    np.random.seed(random_seed)
    
    n_class0 = int(n_samples * (1 - class_ratio))
    n_class1 = n_samples - n_class0
    
    # 类别0数据
    mean_class0 = [1, 1]
    cov_class0 = [[1, 0.3], [0.3, 1]]
    x1_class0, x2_class0 = np.random.multivariate_normal(mean_class0, cov_class0, n_class0).T
    
    # 类别1数据
    mean_class1 = [4, 4]
    cov_class1 = [[1, 0.3], [0.3, 1]]
    x1_class1, x2_class1 = np.random.multivariate_normal(mean_class1, cov_class1, n_class1).T
    
    # 合并数据
    x1 = np.concatenate([x1_class0, x1_class1])
    x2 = np.concatenate([x2_class0, x2_class1])
    labels = np.concatenate([np.zeros(n_class0), np.ones(n_class1)])
    
    df = pd.DataFrame({'x1': x1, 'x2': x2, 'label': labels})
    return df.sample(frac=1, random_state=random_seed).reset_index(drop=True)

def compare_implementations(X_train, y_train, X_val, y_val, X_test, y_test):
    """对比手动实现和PyTorch实现的精度和速度"""
    print("=== 实现对比：手动 vs PyTorch ===")
    
    # 1. 手动实现
    print("1. 手动实现训练中...")
    start_time = time.time()
    manual_model = LogisticRegression(learning_rate=0.1, max_iterations=1000)
    manual_model.fit(X_train, y_train, X_val, y_val, X_test, y_test)
    manual_time = time.time() - start_time
    
    # 手动实现预测
    manual_pred_train = manual_model.predict(X_train)
    manual_pred_test = manual_model.predict(X_test)
    manual_train_acc = accuracy_score(y_train, manual_pred_train)
    manual_test_acc = accuracy_score(y_test, manual_pred_test)
    
    # 2. PyTorch实现
    print("2. PyTorch实现训练中...")
    start_time = time.time()
    
    # 转换为torch张量
    X_train_torch = torch.FloatTensor(X_train)
    y_train_torch = torch.FloatTensor(y_train).reshape(-1, 1)
    X_test_torch = torch.FloatTensor(X_test)
    y_test_torch = torch.FloatTensor(y_test).reshape(-1, 1)
    
    # 创建模型
    pytorch_model = PyTorchLogisticRegression(X_train.shape[1])
    criterion = nn.BCELoss()
    optimizer = optim.SGD(pytorch_model.parameters(), lr=0.1)
    
    # 训练
    pytorch_train_losses = []
    for epoch in range(1000):
        optimizer.zero_grad()
        outputs = pytorch_model(X_train_torch)
        loss = criterion(outputs, y_train_torch)
        loss.backward()
        optimizer.step()
        pytorch_train_losses.append(loss.item())
    
    pytorch_time = time.time() - start_time
    
    # PyTorch预测
    with torch.no_grad():
        pytorch_pred_train = (pytorch_model(X_train_torch) > 0.5).float().numpy().flatten()
        pytorch_pred_test = (pytorch_model(X_test_torch) > 0.5).float().numpy().flatten()
    
    pytorch_train_acc = accuracy_score(y_train, pytorch_pred_train)
    pytorch_test_acc = accuracy_score(y_test, pytorch_pred_test)
    
    # 3. 结果对比
    print(f"\n=== 结果对比 ===")
    print(f"手动实现:")
    print(f"  训练时间: {manual_time:.4f}s")
    print(f"  训练准确率: {manual_train_acc:.4f}")
    print(f"  测试准确率: {manual_test_acc:.4f}")
    print(f"  最终训练损失: {manual_model.train_costs[-1]:.6f}")
    
    print(f"\nPyTorch实现:")
    print(f"  训练时间: {pytorch_time:.4f}s")
    print(f"  训练准确率: {pytorch_train_acc:.4f}")
    print(f"  测试准确率: {pytorch_test_acc:.4f}")
    print(f"  最终训练损失: {pytorch_train_losses[-1]:.6f}")
    
    print(f"\n=== 差异分析 ===")
    print(f"训练时间差异: {abs(manual_time - pytorch_time):.4f}s")
    print(f"训练准确率差异: {abs(manual_train_acc - pytorch_train_acc):.6f}")
    print(f"测试准确率差异: {abs(manual_test_acc - pytorch_test_acc):.6f}")
    
    return manual_model, pytorch_model

def plot_loss_curves(model):
    """绘制训练过程中的损失变化曲线"""
    plt.figure(figsize=(12, 8))
    
    iterations = range(1, len(model.train_costs) + 1)
    
    plt.plot(iterations, model.train_costs, 'b-', label='训练集损失', linewidth=2)
    if model.val_costs:
        plt.plot(iterations, model.val_costs, 'g-', label='验证集损失', linewidth=2)
    if model.test_costs:
        plt.plot(iterations, model.test_costs, 'r-', label='测试集损失', linewidth=2)
    
    plt.xlabel('迭代次数')
    plt.ylabel('交叉熵损失')
    plt.title('Logistic回归训练过程中的损失变化曲线 (1000次迭代)')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()
    
    # 输出数值信息
    print(f"\n=== 损失变化统计 ===")
    print(f"初始训练损失: {model.train_costs[0]:.6f}")
    print(f"最终训练损失: {model.train_costs[-1]:.6f}")
    print(f"训练损失下降: {model.train_costs[0] - model.train_costs[-1]:.6f}")
    
    if model.val_costs:
        print(f"初始验证损失: {model.val_costs[0]:.6f}")
        print(f"最终验证损失: {model.val_costs[-1]:.6f}")
        print(f"验证损失下降: {model.val_costs[0] - model.val_costs[-1]:.6f}")
    
    if model.test_costs:
        print(f"初始测试损失: {model.test_costs[0]:.6f}")
        print(f"最终测试损失: {model.test_costs[-1]:.6f}")
        print(f"测试损失下降: {model.test_costs[0] - model.test_costs[-1]:.6f}")

def analyze_class_ratio_impact():
    """分析标签比例对测试集效果的影响"""
    print("\n" + "="*50)
    print("=== 标签比例影响分析实验 ===")
    print("="*50)
    
    # 测试不同的类别比例
    ratios = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    results = []
    
    for ratio in ratios:
        print(f"\n--- 测试类别1比例: {ratio:.1f} (类别0: {1-ratio:.1f}) ---")
        
        # 生成数据集
        df = generate_dataset_with_ratio(n_samples=1000, class_ratio=ratio, random_seed=42)
        
        # 划分数据集
        X = df[['x1', 'x2']].values
        y = df['label'].values
        
        X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
        X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.25, stratify=y_temp, random_state=42)
        
        # 训练模型
        model = LogisticRegression(learning_rate=0.1, max_iterations=500)
        model.fit(X_train, y_train, X_val, y_val, X_test, y_test)
        
        # 评估性能
        y_pred_test = model.predict(X_test)
        
        accuracy = accuracy_score(y_test, y_pred_test)
        precision = precision_score(y_test, y_pred_test, average='weighted')
        recall = recall_score(y_test, y_pred_test, average='weighted')
        f1 = f1_score(y_test, y_pred_test, average='weighted')
        
        results.append({
            'ratio': ratio,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'final_loss': model.test_costs[-1] if model.test_costs else None
        })
        
        print(f"  测试准确率: {accuracy:.4f}")
        print(f"  测试精确率: {precision:.4f}")
        print(f"  测试召回率: {recall:.4f}")
        print(f"  测试F1分数: {f1:.4f}")
        if model.test_costs:
            print(f"  最终测试损失: {model.test_costs[-1]:.6f}")
    
    # 可视化结果
    results_df = pd.DataFrame(results)
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('标签比例对模型性能的影响分析', fontsize=16)
    
    # 准确率
    axes[0,0].plot(results_df['ratio'], results_df['accuracy'], 'bo-', linewidth=2, markersize=8)
    axes[0,0].set_title('测试准确率 vs 类别1比例')
    axes[0,0].set_xlabel('类别1比例')
    axes[0,0].set_ylabel('准确率')
    axes[0,0].grid(True, alpha=0.3)
    
    # 精确率
    axes[0,1].plot(results_df['ratio'], results_df['precision'], 'go-', linewidth=2, markersize=8)
    axes[0,1].set_title('测试精确率 vs 类别1比例')
    axes[0,1].set_xlabel('类别1比例')
    axes[0,1].set_ylabel('精确率')
    axes[0,1].grid(True, alpha=0.3)
    
    # 召回率
    axes[1,0].plot(results_df['ratio'], results_df['recall'], 'ro-', linewidth=2, markersize=8)
    axes[1,0].set_title('测试召回率 vs 类别1比例')
    axes[1,0].set_xlabel('类别1比例')
    axes[1,0].set_ylabel('召回率')
    axes[1,0].grid(True, alpha=0.3)
    
    # F1分数
    axes[1,1].plot(results_df['ratio'], results_df['f1'], 'mo-', linewidth=2, markersize=8)
    axes[1,1].set_title('测试F1分数 vs 类别1比例')
    axes[1,1].set_xlabel('类别1比例')
    axes[1,1].set_ylabel('F1分数')
    axes[1,1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
    
    # 损失变化图
    if any(r['final_loss'] is not None for r in results):
        plt.figure(figsize=(10, 6))
        final_losses = [r['final_loss'] for r in results if r['final_loss'] is not None]
        ratios_with_loss = [r['ratio'] for r in results if r['final_loss'] is not None]
        plt.plot(ratios_with_loss, final_losses, 'co-', linewidth=2, markersize=8)
        plt.title('最终测试损失 vs 类别1比例')
        plt.xlabel('类别1比例')
        plt.ylabel('最终测试损失')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()
    
    # 输出统计结果
    print(f"\n=== 标签比例影响统计 ===")
    best_accuracy_idx = results_df['accuracy'].idxmax()
    worst_accuracy_idx = results_df['accuracy'].idxmin()
    
    print(f"最佳性能比例: {results_df.loc[best_accuracy_idx, 'ratio']:.1f} (准确率: {results_df.loc[best_accuracy_idx, 'accuracy']:.4f})")
    print(f"最差性能比例: {results_df.loc[worst_accuracy_idx, 'ratio']:.1f} (准确率: {results_df.loc[worst_accuracy_idx, 'accuracy']:.4f})")
    print(f"性能差异: {results_df.loc[best_accuracy_idx, 'accuracy'] - results_df.loc[worst_accuracy_idx, 'accuracy']:.4f}")
    
    return results_df

def main():
    """主函数"""
    print("=== Logistic回归分类任务完整实现 ===")
    
    # 1. 生成和划分数据集
    print("1. 生成和划分数据集...")
    df = generate_dataset_with_ratio(n_samples=500, class_ratio=0.5, random_seed=42)
    
    X = df[['x1', 'x2']].values
    y = df['label'].values
    
    # 7:2:1比例划分
    X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.1, stratify=y, random_state=42)
    X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.22, stratify=y_temp, random_state=42)
    
    print(f"数据集划分完成:")
    print(f"  训练集: {len(X_train)} 样本")
    print(f"  验证集: {len(X_val)} 样本")
    print(f"  测试集: {len(X_test)} 样本")
    
    # 2. 对比手动实现和PyTorch实现
    print(f"\n2. 对比手动实现和PyTorch实现...")
    manual_model, pytorch_model = compare_implementations(X_train, y_train, X_val, y_val, X_test, y_test)
    
    # 3. 绘制训练过程损失曲线
    print(f"\n3. 绘制训练过程损失曲线...")
    plot_loss_curves(manual_model)
    
    # 4. 分析标签比例对性能的影响
    print(f"\n4. 分析标签比例对性能的影响...")
    ratio_results = analyze_class_ratio_impact()
    
    print(f"\n=== 实验完成 ===")
    print("所有任务均已完成！")

if __name__ == "__main__":
    main()