import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import torch

# 设置中文字体支持和数学文本渲染
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['mathtext.default'] = 'regular'

print("=" * 60)
print("PyTorch二次多项式回归训练过程及Loss变化（修复版）")
print("=" * 60)

#-----造数据-----
print("\n1. 数据生成：")
# 自定义公式：y=0.2x²+x+3  
# 生成150个随机数
x = np.random.uniform(low=0, high=15, size=(150,1)).astype(np.float32)
# 根据自定义公式生成正确y值
y_true = 0.2*np.square(x) + x + 3
# 加噪声
noise = np.random.normal(loc=0, scale=1, size=(150,1)).astype(np.float32)
# 加入噪声后的y值（用于训练）
y = y_true + noise

print(f"数据集大小：{len(x)} 样本")
print(f"数据范围：x ∈ [{x.min():.2f}, {x.max():.2f}], y ∈ [{y.min():.2f}, {y.max():.2f}]")

#-----拆分训练集、验证集、测试集-----
print("\n2. 数据集拆分：")
# 拆分训练集和临时集（验证集+测试集）
x_train, x_temp, y_train, y_temp = train_test_split(x, y, test_size=0.3, random_state=42)
# 从临时集拆分出验证集和测试集
x_val, x_test, y_val, y_test = train_test_split(x_temp, y_temp, test_size=1/3, random_state=42)

# 数据标准化（重要的修复点1）
x_mean = x_train.mean()
x_std = x_train.std()
y_mean = y_train.mean()
y_std = y_train.std()

x_train_norm = (x_train - x_mean) / x_std
x_val_norm = (x_val - x_mean) / x_std
x_test_norm = (x_test - x_mean) / x_std
y_train_norm = (y_train - y_mean) / y_std
y_val_norm = (y_val - y_mean) / y_std
y_test_norm = (y_test - y_mean) / y_std

# 将所有数据转换为PyTorch张量
x_train_norm = torch.tensor(x_train_norm)
y_train_norm = torch.tensor(y_train_norm)
x_val_norm = torch.tensor(x_val_norm)
y_val_norm = torch.tensor(y_val_norm)
x_test_norm = torch.tensor(x_test_norm)
y_test_norm = torch.tensor(y_test_norm)

print(f"训练集：{len(x_train)} 样本")
print(f"验证集：{len(x_val)} 样本")
print(f"测试集：{len(x_test)} 样本")
print(f"数据已标准化：x_mean={x_mean:.2f}, x_std={x_std:.2f}")
print(f"            y_mean={y_mean:.2f}, y_std={y_std:.2f}")

#-----初始化模型参数-----
print("\n3. 模型初始化：")
# 二次多项式：y = w2*x² + w1*x + b
w2 = torch.tensor([0.01], requires_grad=True)  # 更小的初始值
w1 = torch.tensor([0.01], requires_grad=True)  # 更小的初始值
b = torch.tensor([0.01], requires_grad=True)   # 更小的初始值

print(f"初始参数：w2={w2.item():.4f}, w1={w1.item():.4f}, b={b.item():.4f}")

#学习率和训练轮次
learning_rate = 0.01  
epochs = 1000

# 用于记录loss的列表
train_losses = []
val_losses = []
test_losses = []

print(f"学习率：{learning_rate}")
print(f"训练轮数：{epochs}")

#-----训练循环-----
print("\n4. 开始训练：")
print("-" * 60)

def calculate_loss(x, y, w2, w1, b):
    """计算MSE损失"""
    y_pred = w2 * torch.square(x) + w1 * x + b
    loss = torch.mean((y - y_pred) ** 2)
    return loss

#！！！添加梯度裁剪防止梯度爆炸
max_grad_norm = 1.0

for epoch in range(epochs):
    # 前向传播
    y_pred_train = w2 * torch.square(x_train_norm) + w1 * x_train_norm + b
    train_loss = torch.mean((y_train_norm - y_pred_train) ** 2)
    
    # 反向传播
    if w2.grad is not None:
        w2.grad.zero_()
    if w1.grad is not None:
        w1.grad.zero_()
    if b.grad is not None:
        b.grad.zero_()
    
    train_loss.backward()
    
    # 梯度裁剪（修复点4）
    torch.nn.utils.clip_grad_norm_([w2, w1, b], max_grad_norm)
    
    # 参数更新
    with torch.no_grad():
        w2 -= learning_rate * w2.grad
        w1 -= learning_rate * w1.grad
        b -= learning_rate * b.grad
    
    # 计算验证集和测试集loss（不需要梯度）
    with torch.no_grad():
        val_loss = calculate_loss(x_val_norm, y_val_norm, w2, w1, b)
        test_loss = calculate_loss(x_test_norm, y_test_norm, w2, w1, b)
    
    # 记录loss
    train_losses.append(train_loss.item())
    val_losses.append(val_loss.item())
    test_losses.append(test_loss.item())
    
    # 每100轮打印一次进度
    if (epoch + 1) % 100 == 0:
        print(f"Epoch {epoch+1:4d}: Train Loss={train_loss.item():.6f}, "
              f"Val Loss={val_loss.item():.6f}, Test Loss={test_loss.item():.6f}")
        print(f"              参数：w2={w2.item():.6f}, w1={w1.item():.6f}, b={b.item():.6f}")

print("-" * 60)
print(f"\n5. 训练完成！")

# 反标准化参数以获得原始尺度的参数（修复点5）
# 原始模型：y = w2_orig*x² + w1_orig*x + b_orig
# 标准化后：(y-y_mean)/y_std = w2*(x-x_mean)²/x_std² + w1*(x-x_mean)/x_std + b
# 反推原始参数
w2_orig = w2.item() * y_std / (x_std ** 2)
w1_orig = (w1.item() * y_std / x_std) - (2 * w2.item() * y_std * x_mean / (x_std ** 2))
b_orig = (b.item() * y_std + y_mean) - (w1.item() * y_std * x_mean / x_std) + (w2.item() * y_std * x_mean ** 2 / (x_std ** 2))

print(f"标准化后参数：w2={w2.item():.4f}, w1={w1.item():.4f}, b={b.item():.4f}")
print(f"还原后参数：w2={w2_orig:.4f}, w1={w1_orig:.4f}, b={b_orig:.4f}")
print(f"目标参数：w2=0.2, w1=1, b=3")  # 显示真实目标参数用于对比
print(f"最终损失：Train={train_losses[-1]:.6f}, Val={val_losses[-1]:.6f}, Test={test_losses[-1]:.6f}")

#-----绘制数据可视化和拟合结果-----
plt.figure(figsize=(12, 10))

# 第一个子图：数据与拟合曲线
plt.subplot(2, 1, 1)

# 画带噪声的训练数据（蓝色散点）
plt.scatter(x_train, y_train, s=15, color="skyblue", 
           label="训练数据", alpha=0.7)

# 画验证集数据（橙色散点）
plt.scatter(x_val, y_val, s=15, color="orange", 
           label="验证数据", alpha=0.7)

# 画测试集数据（绿色散点）
plt.scatter(x_test, y_test, s=15, color="lightgreen", 
           label="测试数据", alpha=0.7)

# 为了画出平滑的曲线，创建一个有序的x数组
x_smooth = np.linspace(0, 15, 100)
y_smooth = 0.2 * np.square(x_smooth) + x_smooth + 3

# 画出真实的二次曲线（红色实线）
plt.plot(x_smooth, y_smooth, color="crimson", linewidth=2,
         label=r"真实二次曲线（$y=0.2x^2+x+3$）")

# 画出最终的二次拟合曲线（使用还原后的参数）
y_poly_final = w2_orig * np.square(x_smooth) + w1_orig * x_smooth + b_orig
plt.plot(x_smooth, y_poly_final, color="purple", linewidth=2, linestyle="--",
         label=f"拟合二次曲线（w2={w2_orig:.3f}, w1={w1_orig:.3f}, b={b_orig:.3f}）")

plt.xlabel("x")
plt.ylabel("y")
plt.title("数据集可视化与最终拟合结果")
plt.legend()
plt.grid(True, alpha=0.3)

# 第二个子图：Loss变化曲线
plt.subplot(2, 1, 2)

plt.plot(range(1, epochs+1), train_losses, color="blue", linewidth=1.5, label="训练Loss")
plt.plot(range(1, epochs+1), val_losses, color="orange", linewidth=1.5, label="验证Loss")
plt.plot(range(1, epochs+1), test_losses, color="green", linewidth=1.5, label="测试Loss")

plt.xlabel("训练轮次 (Epoch)")
plt.ylabel("损失值 (MSE)")
plt.title("训练过程中Loss变化曲线")
plt.legend()
plt.grid(True, alpha=0.3)
plt.yscale('log')  # 使用对数坐标更好地观察loss变化

plt.tight_layout()
plt.show()

#-----输出训练统计信息-----
print("\n6. 训练统计信息：")
print("-" * 40)
print(f"初始训练Loss：{train_losses[0]:.6f}")
print(f"最终训练Loss：{train_losses[-1]:.6f}")
print(f"Loss降低：{train_losses[0] - train_losses[-1]:.6f} "
      f"({((train_losses[0] - train_losses[-1]) / train_losses[0] * 100):.1f}%)")

print(f"\n最佳验证Loss：{min(val_losses):.6f} (Epoch {val_losses.index(min(val_losses)) + 1})")
print(f"最佳测试Loss：{min(test_losses):.6f} (Epoch {test_losses.index(min(test_losses)) + 1})")

# 检查是否过拟合
if val_losses[-1] > min(val_losses) * 1.1:  # 验证loss比最小值高10%以上
    print(f"\n⚠️  可能出现过拟合：验证Loss在最后阶段上升")
else:
    print(f"\n✓ 训练正常：验证Loss保持稳定")

# 参数准确性评估
w2_error = abs(w2_orig - 0.2) / 0.2 * 100
w1_error = abs(w1_orig - 1.0) / 1.0 * 100
b_error = abs(b_orig - 3.0) / 3.0 * 100

print(f"\n参数估计精度：")
print(f"w2误差：{w2_error:.1f}%")
print(f"w1误差：{w1_error:.1f}%") 
print(f"b误差：{b_error:.1f}%")

print("\n" + "=" * 60)
print("训练和可视化完成！")
print("=" * 60)