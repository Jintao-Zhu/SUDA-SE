import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import torch

# 设置中文字体支持和数学文本渲染
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['mathtext.default'] = 'regular'

print("=" * 60)
print("PyTorch线性回归训练过程Loss变化记录")
print("=" * 60)

#-----造数据-----
print("\n1. 数据生成：")
# 自定义公式：y=0.2x²+x+3  
# 生成150个随机数
x = np.random.uniform(low=0, high=15, size=(150,1)).astype(np.float32)
# 根据自定义公式生成正确y值
y_true = 0.2*np.square(x) + x + 3
# 加噪声
noise = np.random.normal(loc=0, scale=1, size=(150,1)).astype(np.float32)
# 加入噪声后的y值（用于训练）
y = y_true + noise

print(f"数据集大小：{len(x)} 样本")
print(f"数据范围：x ∈ [{x.min():.2f}, {x.max():.2f}], y ∈ [{y.min():.2f}, {y.max():.2f}]")

#-----拆分训练集、验证集、测试集-----
print("\n2. 数据集拆分：")
# 拆分训练集和临时集（验证集+测试集）
x_train, x_temp, y_train, y_temp = train_test_split(x, y, test_size=0.3, random_state=42)
# 从临时集拆分出验证集和测试集
x_val, x_test, y_val, y_test = train_test_split(x_temp, y_temp, test_size=1/3, random_state=42)

# 将所有数据转换为PyTorch张量
x_train = torch.tensor(x_train)
y_train = torch.tensor(y_train)
x_val = torch.tensor(x_val)
y_val = torch.tensor(y_val)
x_test = torch.tensor(x_test)
y_test = torch.tensor(y_test)

print(f"训练集：{len(x_train)} 样本")
print(f"验证集：{len(x_val)} 样本")
print(f"测试集：{len(x_test)} 样本")

#-----初始化模型参数-----
print("\n3. 模型初始化：")
# 初始化参数
w = torch.tensor([1.5], requires_grad=True)
b = torch.tensor([2.0], requires_grad=True)

print(f"初始参数：w={w.item():.4f}, b={b.item():.4f}")

# 设置训练参数
learning_rate = 0.01
epochs = 100

# 用于记录loss的列表
train_losses = []
val_losses = []
test_losses = []

print(f"学习率：{learning_rate}")
print(f"训练轮数：{epochs}")

#-----训练循环-----
print("\n4. 开始训练：")
print("-" * 60)

def calculate_loss(x, y, w, b):
    """计算MSE损失"""
    y_pred = w * x + b
    loss = torch.mean((y - y_pred) ** 2)
    return loss

for epoch in range(epochs):
    # 前向传播
    y_pred_train = w * x_train + b
    train_loss = torch.mean((y_train - y_pred_train) ** 2)
    
    # 反向传播
    if w.grad is not None:
        w.grad.zero_()
    if b.grad is not None:
        b.grad.zero_()
    
    train_loss.backward()
    
    # 参数更新
    with torch.no_grad():
        w -= learning_rate * w.grad
        b -= learning_rate * b.grad
    
    # 计算验证集和测试集loss（不需要梯度）
    with torch.no_grad():
        val_loss = calculate_loss(x_val, y_val, w, b)
        test_loss = calculate_loss(x_test, y_test, w, b)
    
    # 记录loss
    train_losses.append(train_loss.item())
    val_losses.append(val_loss.item())
    test_losses.append(test_loss.item())
    
    # 每10轮打印一次进度
    if (epoch + 1) % 10 == 0:
        print(f"Epoch {epoch+1:3d}: Train Loss={train_loss.item():.4f}, "
              f"Val Loss={val_loss.item():.4f}, Test Loss={test_loss.item():.4f}")

print("-" * 60)
print(f"\n5. 训练完成！")
print(f"最终参数：w={w.item():.4f}, b={b.item():.4f}")
print(f"最终损失：Train={train_losses[-1]:.4f}, Val={val_losses[-1]:.4f}, Test={test_losses[-1]:.4f}")

#-----绘制数据可视化和拟合结果-----
plt.figure(figsize=(10, 6))

# 画带噪声的训练数据（蓝色散点）
plt.scatter(x_train.numpy(), y_train.numpy(), s=15, color="skyblue", 
           label="训练数据", alpha=0.7)

# 画验证集数据（橙色散点）
plt.scatter(x_val.numpy(), y_val.numpy(), s=15, color="orange", 
           label="验证数据", alpha=0.7)

# 画测试集数据（绿色散点）
plt.scatter(x_test.numpy(), y_test.numpy(), s=15, color="lightgreen", 
           label="测试数据", alpha=0.7)

# 为了画出平滑的真实曲线，创建一个有序的x数组
x_smooth = np.linspace(0, 15, 100)
y_smooth = 0.2 * np.square(x_smooth) + x_smooth + 3

# 画出真实的二次曲线（红色实线）
plt.plot(x_smooth, y_smooth, color="crimson", linewidth=2,
         label=r"真实二次曲线（$y=0.2x^2+x+3$）")

# 画出最终的线性拟合线
y_line_final = w.item() * x_smooth + b.item()
plt.plot(x_smooth, y_line_final, color="purple", linewidth=2, linestyle="--",
         label=f"最终线性拟合（w={w.item():.3f}, b={b.item():.3f}）")

plt.xlabel("x")
plt.ylabel("y")
plt.title("数据集可视化与最终拟合结果")
plt.legend()
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

#-----绘制Loss变化曲线-----
plt.figure(figsize=(10, 6))

# 绘制训练集Loss曲线
plt.plot(range(1, epochs+1), train_losses, color="blue", linewidth=2, 
         label="训练集Loss")

# 绘制验证集Loss曲线
plt.plot(range(1, epochs+1), val_losses, color="orange", linewidth=2, 
         label="验证集Loss")

# 绘制测试集Loss曲线
plt.plot(range(1, epochs+1), test_losses, color="green", linewidth=2, 
         label="测试集Loss")

plt.xlabel("训练轮次 (Epoch)")
plt.ylabel("损失值 (Loss)")
plt.title("训练过程中各数据集的Loss变化曲线")
plt.legend()
plt.grid(True, alpha=0.3)

# 添加最佳验证Loss标记
best_val_epoch = val_losses.index(min(val_losses)) + 1
plt.scatter(best_val_epoch, min(val_losses), color="red", s=80, zorder=5,
           label=f"最佳验证Loss: {min(val_losses):.4f}")

plt.tight_layout()
plt.show()

#-----输出训练统计信息-----
print("\n6. 训练统计信息：")
print("-" * 40)
print(f"初始训练Loss：{train_losses[0]:.4f}")
print(f"最终训练Loss：{train_losses[-1]:.4f}")
print(f"Loss降低：{train_losses[0] - train_losses[-1]:.4f} "
      f"({((train_losses[0] - train_losses[-1]) / train_losses[0] * 100):.1f}%)")

print(f"\n最佳验证Loss：{min(val_losses):.4f} (Epoch {val_losses.index(min(val_losses)) + 1})")
print(f"最佳测试Loss：{min(test_losses):.4f} (Epoch {test_losses.index(min(test_losses)) + 1})")

# 检查是否过拟合
if val_losses[-1] > min(val_losses) * 1.1:  # 验证loss比最小值高10%以上
    print(f"\n⚠️  可能出现过拟合：验证Loss在最后阶段上升")
else:
    print(f"\n✓ 训练正常：验证Loss保持稳定")

print("\n" + "=" * 60)
print("训练和可视化完成！")
print("=" * 60)
