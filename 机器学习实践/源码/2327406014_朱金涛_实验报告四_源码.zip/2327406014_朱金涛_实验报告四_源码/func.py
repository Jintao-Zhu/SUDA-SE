import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, plot_tree

# ================= 字体设置 =================
mpl.rcParams['font.sans-serif'] = ['SimHei']
mpl.rcParams['axes.unicode_minus'] = False

# ================= 1. 读入数据 =================
df = pd.read_csv("D:\\课程资料\\机器学习实践\\机器学习综合实践课堂实验4\\Titanic-Dataset.csv")

# 特征选择
features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]
target = "Survived"
df = df[features + [target]]

# 缺失值处理
df["Age"].fillna(df["Age"].median(), inplace=True)
df["Embarked"].fillna(df["Embarked"].mode()[0], inplace=True)

# 类别特征编码
for col in ["Sex", "Embarked"]:
    df[col] = LabelEncoder().fit_transform(df[col])

X = df[features]
y = df[target]

# ================= 2. CART 未剪枝 =================
cart_clf = DecisionTreeClassifier(criterion="gini", random_state=42)
cart_scores = cross_val_score(cart_clf, X, y, cv=5, scoring="accuracy")
print(f"CART 交叉验证准确率 (未剪枝): {cart_scores.mean():.4f} (±{cart_scores.std():.4f})")

# 可视化 CART 未剪枝决策树
cart_clf.fit(X, y)
plt.figure(figsize=(14,8))
plot_tree(cart_clf, feature_names=features, class_names=["NotSurvived","Survived"], filled=True)
plt.title("CART 未剪枝的决策树")
plt.show()

# ================= 3. CART 剪枝 =================
X_train, X_valid, y_train, y_valid = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
cart_clf.fit(X_train, y_train)

path = cart_clf.cost_complexity_pruning_path(X_train, y_train)
ccp_alphas = path.ccp_alphas

best_alpha = None
best_acc = 0
acc_list = []

for alpha in ccp_alphas:
    pruned_clf = DecisionTreeClassifier(criterion="gini", random_state=42, ccp_alpha=alpha)
    pruned_clf.fit(X_train, y_train)
    acc = pruned_clf.score(X_valid, y_valid)
    acc_list.append((alpha, acc))
    if acc > best_acc:
        best_acc = acc
        best_alpha = alpha

print("CART 最佳剪枝参数 ccp_alpha:", best_alpha)
print("CART 验证集准确率 (剪枝后):", best_acc)

# 剪枝效果曲线
alphas, accs = zip(*acc_list)
plt.figure(figsize=(8,5))
plt.plot(alphas, accs, marker="o")
plt.xlabel("ccp_alpha")
plt.ylabel("验证集准确率")
plt.title("CART 剪枝效果 (ccp_alpha vs 准确率)")
plt.show()

# 可视化 CART 剪枝后决策树
final_cart = DecisionTreeClassifier(criterion="gini", random_state=42, ccp_alpha=best_alpha)
final_cart.fit(X, y)
plt.figure(figsize=(14,8))
plot_tree(final_cart, feature_names=features, class_names=["NotSurvived","Survived"], filled=True)
plt.title("CART 剪枝后的决策树")
plt.show()

# ================= 4. ID3 未剪枝 =================
id3_clf = DecisionTreeClassifier(criterion="entropy", random_state=42)
id3_scores = cross_val_score(id3_clf, X, y, cv=5, scoring="accuracy")
print(f"\nID3 交叉验证准确率 (未剪枝): {id3_scores.mean():.4f} (±{id3_scores.std():.4f})")

# 可视化 ID3 未剪枝决策树
id3_clf.fit(X, y)
plt.figure(figsize=(14,8))
plot_tree(id3_clf, feature_names=features, class_names=["NotSurvived","Survived"], filled=True)
plt.title("ID3 未剪枝的决策树")
plt.show()

# ================= 5. ID3 剪枝 =================
id3_clf.fit(X_train, y_train)

path = id3_clf.cost_complexity_pruning_path(X_train, y_train)
ccp_alphas = path.ccp_alphas

best_alpha = None
best_acc = 0
acc_list = []

for alpha in ccp_alphas:
    pruned_clf = DecisionTreeClassifier(criterion="entropy", random_state=42, ccp_alpha=alpha)
    pruned_clf.fit(X_train, y_train)
    acc = pruned_clf.score(X_valid, y_valid)
    acc_list.append((alpha, acc))
    if acc > best_acc:
        best_acc = acc
        best_alpha = alpha

print("ID3 最佳剪枝参数 ccp_alpha:", best_alpha)
print("ID3 验证集准确率 (剪枝后):", best_acc)

# 剪枝效果曲线
alphas, accs = zip(*acc_list)
plt.figure(figsize=(8,5))
plt.plot(alphas, accs, marker="o", color="orange")
plt.xlabel("ccp_alpha")
plt.ylabel("验证集准确率")
plt.title("ID3 剪枝效果 (ccp_alpha vs 准确率)")
plt.show()

# 可视化 ID3 剪枝后决策树
final_id3 = DecisionTreeClassifier(criterion="entropy", random_state=42, ccp_alpha=best_alpha)
final_id3.fit(X, y)
plt.figure(figsize=(14,8))
plot_tree(final_id3, feature_names=features, class_names=["NotSurvived","Survived"], filled=True)
plt.title("ID3 剪枝后的决策树")
plt.show()
