#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <time.h>

#define ROCK 0
#define SCISSORS 1 
#define PAPER 2
#define ROUNDS 100

// 共享内存结构
typedef struct {
    int player1_move;    // 选手1出招
    int player2_move;    // 选手2出招
    int result1;         // 选手1结果 (1胜 0平 -1负)
    int result2;         // 选手2结果
    int round;           // 当前回合
    int player1_score;   // 选手1总分
    int player2_score;   // 选手2总分
    int game_over;       // 游戏结束标志
} GameData;

// 信号量操作（对信号集中的第0个元素操作，执行P/V操作，默认模式）
struct sembuf sem_lock = {0, -1, 0};
struct sembuf sem_unlock = {0, 1, 0};

int semid;
GameData *game_data;

// 判断胜负: 石头>剪刀>布>石头
int judge_winner(int move1, int move2) {
    if (move1 == move2) return 0; // 平局
    if ((move1 == ROCK && move2 == SCISSORS) ||
        (move1 == SCISSORS && move2 == PAPER) ||
        (move1 == PAPER && move2 == ROCK)) {
        return 1; // move1胜
    }
    return -1; // move1负
}

// 选手进程
void player_process(int player_id) {
    srand(time(NULL) + player_id);
    
    while (!game_data->game_over) {
        semop(semid, &sem_lock, 1);
        
        if (game_data->game_over) {
            semop(semid, &sem_unlock, 1);
            break;
        }
        
        // 检查是否轮到当前回合且该选手尚未出招
        if (game_data->round > 0) {
            if (player_id == 1 && game_data->player1_move == -1) {
                // 随机出招
                game_data->player1_move = rand() % 3;
            } else if (player_id == 2 && game_data->player2_move == -1) {
                // 随机出招
                game_data->player2_move = rand() % 3;
            }
        }
        
        semop(semid, &sem_unlock, 1);
        usleep(10000); // 短暂等待
    }
}

// 裁判进程
void judge_process() {
    FILE *fp = fopen("game_results.txt", "w");
    char *moves[] = {"石头", "剪刀", "布"};
    
    for (int round = 1; round <= ROUNDS; round++) {
        semop(semid, &sem_lock, 1);
        
        game_data->round = round;
        game_data->player1_move = -1;
        game_data->player2_move = -1;
        
        semop(semid, &sem_unlock, 1);
        
        // 等待两个选手都出招
        while (1) {
            semop(semid, &sem_lock, 1);
            if (game_data->player1_move != -1 && game_data->player2_move != -1) {
                semop(semid, &sem_unlock, 1);
                break;
            }
            semop(semid, &sem_unlock, 1);
            usleep(1000);
        }
        
        semop(semid, &sem_lock, 1);
        
        // 判断胜负
        int result = judge_winner(game_data->player1_move, game_data->player2_move);
        game_data->result1 = result;
        game_data->result2 = -result;
        
        if (result == 1) {
            game_data->player1_score++;
            printf("第%d回合: %s vs %s - 选手1胜\n", round, 
                   moves[game_data->player1_move], moves[game_data->player2_move]);
            fprintf(fp, "第%d回合: %s vs %s - 选手1胜\n", round,
                    moves[game_data->player1_move], moves[game_data->player2_move]);
        } else if (result == -1) {
            game_data->player2_score++;
            printf("第%d回合: %s vs %s - 选手2胜\n", round,
                   moves[game_data->player1_move], moves[game_data->player2_move]);
            fprintf(fp, "第%d回合: %s vs %s - 选手2胜\n", round,
                    moves[game_data->player1_move], moves[game_data->player2_move]);
        } else {
            printf("第%d回合: %s vs %s - 平局\n", round,
                   moves[game_data->player1_move], moves[game_data->player2_move]);
            fprintf(fp, "第%d回合: %s vs %s - 平局\n", round,
                    moves[game_data->player1_move], moves[game_data->player2_move]);
        }
        
        semop(semid, &sem_unlock, 1);
        usleep(50000); // 回合间隔
    }
    
    // 宣布最终结果
    semop(semid, &sem_lock, 1);
    game_data->game_over = 1;
    
    printf("\n=== 比赛结果 ===\n");
    printf("选手1得分: %d\n", game_data->player1_score);
    printf("选手2得分: %d\n", game_data->player2_score);
    printf("平局数：%d\n", ROUNDS - game_data->player1_score - game_data->player2_score);

    fprintf(fp, "\n=== 比赛结果 ===\n");
    fprintf(fp, "选手1得分: %d\n", game_data->player1_score);
    fprintf(fp, "选手2得分: %d\n", game_data->player2_score);
    
    if (game_data->player1_score > game_data->player2_score) {
        printf("选手1获胜！\n");
        fprintf(fp, "选手1获胜！\n");
    } else if (game_data->player2_score > game_data->player1_score) {
        printf("选手2获胜！\n");
        fprintf(fp, "选手2获胜！\n");
    } else {
        printf("平局！\n");
        fprintf(fp, "平局！\n");
    }
    
    semop(semid, &sem_unlock, 1);
    fclose(fp);
}

int main() {
    key_t key = ftok(".", 1);
    
    // 创建共享内存
    int shmid = shmget(key, sizeof(GameData), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }
    
    // 创建信号量
    semid = semget(key, 1, IPC_CREAT | 0666);
    if (semid == -1) {
        perror("semget");
        exit(1);
    }
    
    // 初始化信号量
    semctl(semid, 0, SETVAL, 1);
    
    // 连接共享内存
    game_data = (GameData*)shmat(shmid, NULL, 0);
    if (game_data == (void*)-1) {
        perror("shmat");
        exit(1);
    }
    
    // 初始化游戏数据
    game_data->player1_score = 0;
    game_data->player2_score = 0;
    game_data->game_over = 0;
    game_data->round = 0;
    
    printf("石头剪刀布比赛开始！共%d回合\n", ROUNDS);
    
    // 创建三个进程
    pid_t pid1 = fork();
    if (pid1 == 0) {
        player_process(1); // 选手1
        exit(0);
    }
    
    pid_t pid2 = fork();
    if (pid2 == 0) {
        player_process(2); // 选手2
        exit(0);
    }
    
    // 裁判进程（主进程）
    judge_process();
    
    // 等待子进程结束
    wait(NULL);
    wait(NULL);
    
    // 清理资源
    shmdt(game_data);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);
    
    printf("游戏结束，结果已保存到 game_results.txt\n");
    return 0;
}