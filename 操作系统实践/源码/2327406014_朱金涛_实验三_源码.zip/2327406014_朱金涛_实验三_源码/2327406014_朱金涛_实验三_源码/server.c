// server.c - 石头剪刀布网络版服务器
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>

#define PORT 8888
#define MAX_CLIENTS 10
#define MAX_ROOMS 5
#define ROUNDS_PER_MATCH 10
#define BUFFER_SIZE 1024

// 游戏选择
#define ROCK 0
#define SCISSORS 1
#define PAPER 2

// 消息类型
#define MSG_JOIN 1
#define MSG_MOVE 2
#define MSG_RESULT 3
#define MSG_STATUS 4
#define MSG_ROOM_LIST 5
#define MSG_CREATE_ROOM 6
#define MSG_LEAVE_ROOM 7
#define MSG_CHAT 8

// 客户端状态
#define CLIENT_LOBBY 0
#define CLIENT_IN_ROOM 1
#define CLIENT_PLAYING 2

// 房间状态
#define ROOM_WAITING 0
#define ROOM_PLAYING 1
#define ROOM_FINISHED 2

// 消息结构
typedef struct {
    int type;
    int length;
    char data[BUFFER_SIZE];
} Message;

// 客户端信息
typedef struct {
    int socket_fd;
    int id;
    char name[32];
    int state;
    int room_id;
    int score;
    int current_move;
    pthread_t thread;
    struct sockaddr_in address;
} Client;

// 房间信息
typedef struct {
    int id;
    char name[64];
    int state;
    int player1_id;
    int player2_id;
    int current_round;
    int total_rounds;
    int player1_score;
    int player2_score;
    int player1_move;
    int player2_move;
    time_t created_time;
    pthread_mutex_t mutex;
} Room;

// 全局变量
Client clients[MAX_CLIENTS];
Room rooms[MAX_ROOMS];
int client_count = 0;
int room_count = 0;
pthread_mutex_t clients_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t rooms_mutex = PTHREAD_MUTEX_INITIALIZER;

// IPC层封装 - 消息发送接收
int send_message(int socket_fd, Message *msg) {
    int total_size = sizeof(int) * 2 + msg->length;
    char *buffer = malloc(total_size);
    
    memcpy(buffer, &msg->type, sizeof(int));
    memcpy(buffer + sizeof(int), &msg->length, sizeof(int));
    memcpy(buffer + sizeof(int) * 2, msg->data, msg->length);
    
    int sent = send(socket_fd, buffer, total_size, 0);
    free(buffer);
    
    return sent;
}

int receive_message(int socket_fd, Message *msg) {
    int received = recv(socket_fd, &msg->type, sizeof(int), 0);
    if (received <= 0) return received;
    
    received = recv(socket_fd, &msg->length, sizeof(int), 0);
    if (received <= 0) return received;
    
    if (msg->length > BUFFER_SIZE) return -1;
    
    received = recv(socket_fd, msg->data, msg->length, 0);
    return received;
}

// 广播消息给房间内的玩家
void broadcast_to_room(int room_id, Message *msg) {
    pthread_mutex_lock(&rooms_mutex);
    if (room_id >= 0 && room_id < MAX_ROOMS && rooms[room_id].id != -1) {
        pthread_mutex_lock(&clients_mutex);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].socket_fd != -1 && clients[i].room_id == room_id) {
                send_message(clients[i].socket_fd, msg);
            }
        }
        pthread_mutex_unlock(&clients_mutex);
    }
    pthread_mutex_unlock(&rooms_mutex);
}

// 查找客户端
Client* find_client(int socket_fd) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].socket_fd == socket_fd) {
            return &clients[i];
        }
    }
    return NULL;
}

// 查找房间
Room* find_room(int room_id) {
    if (room_id >= 0 && room_id < MAX_ROOMS && rooms[room_id].id != -1) {
        return &rooms[room_id];
    }
    return NULL;
}

// 判断胜负
int judge_winner(int move1, int move2) {
    if (move1 == move2) return 0;
    if ((move1 == ROCK && move2 == SCISSORS) ||
        (move1 == SCISSORS && move2 == PAPER) ||
        (move1 == PAPER && move2 == ROCK)) {
        return 1;
    }
    return -1;
}

// 发送房间列表
void send_room_list(int socket_fd) {
    Message msg;
    msg.type = MSG_ROOM_LIST;
    
    char room_list[BUFFER_SIZE] = "";
    pthread_mutex_lock(&rooms_mutex);
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (rooms[i].id != -1) {
            char room_info[128];
            int player_count = 0;
            if (rooms[i].player1_id != -1) player_count++;
            if (rooms[i].player2_id != -1) player_count++;
            
            sprintf(room_info, "房间%d: %s [%d/2] %s\n", 
                    rooms[i].id, rooms[i].name, player_count,
                    rooms[i].state == ROOM_WAITING ? "等待中" : "游戏中");
            strcat(room_list, room_info);
        }
    }
    pthread_mutex_unlock(&rooms_mutex);
    
    msg.length = strlen(room_list) + 1;
    strcpy(msg.data, room_list);
    send_message(socket_fd, &msg);
}

// 创建房间
int create_room(const char *room_name, int creator_id) {
    pthread_mutex_lock(&rooms_mutex);
    for (int i = 0; i < MAX_ROOMS; i++) {
        if (rooms[i].id == -1) {
            rooms[i].id = i;
            strcpy(rooms[i].name, room_name);
            rooms[i].state = ROOM_WAITING;
            rooms[i].player1_id = creator_id;
            rooms[i].player2_id = -1;
            rooms[i].current_round = 0;
            rooms[i].total_rounds = ROUNDS_PER_MATCH;
            rooms[i].player1_score = 0;
            rooms[i].player2_score = 0;
            rooms[i].player1_move = -1;
            rooms[i].player2_move = -1;
            rooms[i].created_time = time(NULL);
            pthread_mutex_init(&rooms[i].mutex, NULL);
            
            room_count++;
            pthread_mutex_unlock(&rooms_mutex);
            return i;
        }
    }
    pthread_mutex_unlock(&rooms_mutex);
    return -1;
}

// 加入房间
int join_room(int room_id, int player_id) {
    Room *room = find_room(room_id);
    if (!room) return -1;
    
    pthread_mutex_lock(&room->mutex);
    if (room->player2_id == -1 && room->player1_id != player_id) {
        room->player2_id = player_id;
        pthread_mutex_unlock(&room->mutex);
        return 0;
    }
    pthread_mutex_unlock(&room->mutex);
    return -1;
}

// 开始游戏回合
void start_game_round(Room *room) {
    pthread_mutex_lock(&room->mutex);
    
    if (room->state == ROOM_WAITING && room->player1_id != -1 && room->player2_id != -1) {
        room->state = ROOM_PLAYING;
    }
    
    if (room->state == ROOM_PLAYING) {
        room->current_round++;
        room->player1_move = -1;
        room->player2_move = -1;
        
        Message msg;
        msg.type = MSG_STATUS;
        sprintf(msg.data, "第%d回合开始！请出招：0=石头 1=剪刀 2=布", room->current_round);
        msg.length = strlen(msg.data) + 1;
        
        pthread_mutex_unlock(&room->mutex);
        broadcast_to_room(room->id, &msg);
    } else {
        pthread_mutex_unlock(&room->mutex);
    }
}

// 处理玩家出招
void handle_player_move(Room *room, int player_id, int move) {
    pthread_mutex_lock(&room->mutex);
    
    if (room->state != ROOM_PLAYING) {
        pthread_mutex_unlock(&room->mutex);
        return;
    }
    
    if (player_id == room->player1_id) {
        room->player1_move = move;
    } else if (player_id == room->player2_id) {
        room->player2_move = move;
    }
    
    // 检查是否双方都已出招
    if (room->player1_move != -1 && room->player2_move != -1) {
        // 判断胜负
        int result = judge_winner(room->player1_move, room->player2_move);
        char *moves[] = {"石头", "剪刀", "布"};
        
        Client *player1 = NULL, *player2 = NULL;
        pthread_mutex_lock(&clients_mutex);
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].id == room->player1_id) player1 = &clients[i];
            if (clients[i].id == room->player2_id) player2 = &clients[i];
        }
        pthread_mutex_unlock(&clients_mutex);
        
        Message msg;
        msg.type = MSG_RESULT;
        
        if (result == 1) {
            room->player1_score++;
            sprintf(msg.data, "第%d回合: %s(%s) vs %s(%s) - %s胜！", 
                    room->current_round,
                    player1 ? player1->name : "玩家1", moves[room->player1_move],
                    player2 ? player2->name : "玩家2", moves[room->player2_move],
                    player1 ? player1->name : "玩家1");
        } else if (result == -1) {
            room->player2_score++;
            sprintf(msg.data, "第%d回合: %s(%s) vs %s(%s) - %s胜！", 
                    room->current_round,
                    player1 ? player1->name : "玩家1", moves[room->player1_move],
                    player2 ? player2->name : "玩家2", moves[room->player2_move],
                    player2 ? player2->name : "玩家2");
        } else {
            sprintf(msg.data, "第%d回合: %s(%s) vs %s(%s) - 平局！", 
                    room->current_round,
                    player1 ? player1->name : "玩家1", moves[room->player1_move],
                    player2 ? player2->name : "玩家2", moves[room->player2_move]);
        }
        
        msg.length = strlen(msg.data) + 1;
        pthread_mutex_unlock(&room->mutex);
        broadcast_to_room(room->id, &msg);
        
        // 检查游戏是否结束
        if (room->current_round >= room->total_rounds) {
            pthread_mutex_lock(&room->mutex);
            room->state = ROOM_FINISHED;
            
            msg.type = MSG_STATUS;
            sprintf(msg.data, "\n=== 游戏结束 ===\n最终比分: %s %d - %d %s\n%s", 
                    player1 ? player1->name : "玩家1", room->player1_score,
                    room->player2_score, player2 ? player2->name : "玩家2",
                    room->player1_score > room->player2_score ? 
                    (player1 ? player1->name : "玩家1") : 
                    (room->player2_score > room->player1_score ? 
                     (player2 ? player2->name : "玩家2") : "平局") );
            strcat(msg.data, " 获胜！");
            msg.length = strlen(msg.data) + 1;
            
            pthread_mutex_unlock(&room->mutex);
            broadcast_to_room(room->id, &msg);
        } else {
            // 开始下一回合
            sleep(2);
            start_game_round(room);
        }
    } else {
        pthread_mutex_unlock(&room->mutex);
    }
}

// 客户端处理线程
void* handle_client(void *arg) {
    Client *client = (Client*)arg;
    Message msg;
    
    printf("客户端 %s 已连接 (IP: %s)\n", client->name, inet_ntoa(client->address.sin_addr));
    
    while (1) {
        int received = receive_message(client->socket_fd, &msg);
        if (received <= 0) {
            break;
        }
        
        switch (msg.type) {
            case MSG_ROOM_LIST:
                send_room_list(client->socket_fd);
                break;
                
            case MSG_CREATE_ROOM: {
                char room_name[64];
                strcpy(room_name, msg.data);
                int room_id = create_room(room_name, client->id);
                
                if (room_id != -1) {
                    client->room_id = room_id;
                    client->state = CLIENT_IN_ROOM;
                    
                    Message response;
                    response.type = MSG_STATUS;
                    sprintf(response.data, "成功创建房间 '%s'，等待其他玩家加入...", room_name);
                    response.length = strlen(response.data) + 1;
                    send_message(client->socket_fd, &response);
                } else {
                    Message response;
                    response.type = MSG_STATUS;
                    sprintf(response.data, "创建房间失败，服务器已满");
                    response.length = strlen(response.data) + 1;
                    send_message(client->socket_fd, &response);
                }
                break;
            }
            
            case MSG_JOIN: {
                int room_id = atoi(msg.data);
                if (join_room(room_id, client->id) == 0) {
                    client->room_id = room_id;
                    client->state = CLIENT_IN_ROOM;
                    
                    Message response;
                    response.type = MSG_STATUS;
                    sprintf(response.data, "成功加入房间%d，游戏即将开始！", room_id);
                    response.length = strlen(response.data) + 1;
                    send_message(client->socket_fd, &response);
                    
                    // 开始游戏
                    Room *room = find_room(room_id);
                    if (room) {
                        sleep(1);
                        start_game_round(room);
                    }
                } else {
                    Message response;
                    response.type = MSG_STATUS;
                    sprintf(response.data, "加入房间失败");
                    response.length = strlen(response.data) + 1;
                    send_message(client->socket_fd, &response);
                }
                break;
            }
            
            case MSG_MOVE: {
                int move = atoi(msg.data);
                if (move >= 0 && move <= 2) {
                    Room *room = find_room(client->room_id);
                    if (room) {
                        handle_player_move(room, client->id, move);
                    }
                }
                break;
            }
            
            case MSG_CHAT: {
                Message chat_msg;
                chat_msg.type = MSG_CHAT;
                sprintf(chat_msg.data, "%s: %s", client->name, msg.data);
                chat_msg.length = strlen(chat_msg.data) + 1;
                broadcast_to_room(client->room_id, &chat_msg);
                break;
            }
        }
    }
    
    // 客户端断开连接处理
    printf("客户端 %s 断开连接\n", client->name);
    
    pthread_mutex_lock(&clients_mutex);
    client->socket_fd = -1;
    client_count--;
    pthread_mutex_unlock(&clients_mutex);
    
    close(client->socket_fd);
    return NULL;
}

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    
    // 初始化
    for (int i = 0; i < MAX_CLIENTS; i++) {
        clients[i].socket_fd = -1;
        clients[i].id = -1;
    }
    
    for (int i = 0; i < MAX_ROOMS; i++) {
        rooms[i].id = -1;
    }
    
    // 创建服务器socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        perror("socket");
        exit(1);
    }
    
    // 设置socket选项
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    // 绑定地址
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    
    if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("bind");
        exit(1);
    }
    
    // 开始监听
    if (listen(server_fd, 5) == -1) {
        perror("listen");
        exit(1);
    }
    
    printf("🎮 石头剪刀布服务器启动成功！\n");
    printf("监听端口: %d\n", PORT);
    printf("最大客户端数: %d\n", MAX_CLIENTS);
    printf("最大房间数: %d\n\n", MAX_ROOMS);
    
    // 接受客户端连接
    while (1) {
        client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &client_len);
        if (client_fd == -1) {
            perror("accept");
            continue;
        }
        
        // 查找空闲客户端槽位
        pthread_mutex_lock(&clients_mutex);
        int client_index = -1;
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].socket_fd == -1) {
                client_index = i;
                break;
            }
        }
        
        if (client_index == -1) {
            pthread_mutex_unlock(&clients_mutex);
            printf("服务器已满，拒绝连接\n");
            close(client_fd);
            continue;
        }
        
        // 初始化客户端信息
        clients[client_index].socket_fd = client_fd;
        clients[client_index].id = client_index;
        sprintf(clients[client_index].name, "玩家%d", client_index + 1);
        clients[client_index].state = CLIENT_LOBBY;
        clients[client_index].room_id = -1;
        clients[client_index].score = 0;
        clients[client_index].current_move = -1;
        clients[client_index].address = client_addr;
        
        client_count++;
        pthread_mutex_unlock(&clients_mutex);
        
        // 创建客户端处理线程
        pthread_create(&clients[client_index].thread, NULL, handle_client, &clients[client_index]);
        pthread_detach(clients[client_index].thread);
        
        // 发送欢迎信息
        Message welcome_msg;
        welcome_msg.type = MSG_STATUS;
        sprintf(welcome_msg.data, "欢迎来到石头剪刀布服务器！你是 %s", clients[client_index].name);
        welcome_msg.length = strlen(welcome_msg.data) + 1;
        send_message(client_fd, &welcome_msg);
    }
    
    close(server_fd);
    return 0;
}