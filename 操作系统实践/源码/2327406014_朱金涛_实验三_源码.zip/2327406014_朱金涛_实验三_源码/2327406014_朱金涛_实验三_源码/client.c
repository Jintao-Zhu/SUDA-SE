// client.c - 石头剪刀布网络版客户端
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <signal.h>

#define PORT 8888
#define BUFFER_SIZE 1024

// 消息类型
#define MSG_JOIN 1
#define MSG_MOVE 2
#define MSG_RESULT 3
#define MSG_STATUS 4
#define MSG_ROOM_LIST 5
#define MSG_CREATE_ROOM 6
#define MSG_LEAVE_ROOM 7
#define MSG_CHAT 8

// 客户端状态
#define CLIENT_LOBBY 0
#define CLIENT_IN_ROOM 1
#define CLIENT_PLAYING 2

// 消息结构
typedef struct {
    int type;
    int length;
    char data[BUFFER_SIZE];
} Message;

int client_socket;
int client_state = CLIENT_LOBBY;
pthread_t receive_thread;
int game_running = 1;

// IPC层封装 - 消息发送接收
int send_message(int socket_fd, Message *msg) {
    int total_size = sizeof(int) * 2 + msg->length;
    char *buffer = malloc(total_size);
    
    memcpy(buffer, &msg->type, sizeof(int));
    memcpy(buffer + sizeof(int), &msg->length, sizeof(int));
    memcpy(buffer + sizeof(int) * 2, msg->data, msg->length);
    
    int sent = send(socket_fd, buffer, total_size, 0);
    free(buffer);
    
    return sent;
}

int receive_message(int socket_fd, Message *msg) {
    int received = recv(socket_fd, &msg->type, sizeof(int), 0);
    if (received <= 0) return received;
    
    received = recv(socket_fd, &msg->length, sizeof(int), 0);
    if (received <= 0) return received;
    
    if (msg->length > BUFFER_SIZE) return -1;
    
    received = recv(socket_fd, msg->data, msg->length, 0);
    return received;
}

// 接收消息线程
void* receive_messages(void* arg) {
    Message msg;
    
    while (game_running) {
        int received = receive_message(client_socket, &msg);
        if (received <= 0) {
            if (game_running) {
                printf("\n❌ 与服务器连接断开\n");
                game_running = 0;
            }
            break;
        }
        
        switch (msg.type) {
            case MSG_STATUS:
                printf("\n📢 %s\n", msg.data);
                if (strstr(msg.data, "请出招") != NULL) {
                    client_state = CLIENT_PLAYING;
                }
                break;
                
            case MSG_RESULT:
                printf("🎯 %s\n", msg.data);
                break;
                
            case MSG_ROOM_LIST:
                printf("\n🏠 当前房间列表：\n");
                printf("====================\n");
                if (strlen(msg.data) > 1) {
                    printf("%s", msg.data);
                } else {
                    printf("暂无房间\n");
                }
                printf("====================\n");
                break;
                
            case MSG_CHAT:
                printf("💬 %s\n", msg.data);
                break;
        }
        
        printf("👉 ");
        fflush(stdout);
    }
    
    return NULL;
}

// 显示主菜单
void show_main_menu() {
    printf("\n🎮 ===== 石头剪刀布网络版 =====\n");
    printf("1. 查看房间列表\n");
    printf("2. 创建房间\n");
    printf("3. 加入房间\n");
    printf("4. 帮助\n");
    printf("5. 退出\n");
    printf("================================\n");
    printf("请选择 (1-5): ");
}

// 显示游戏帮助
void show_help() {
    printf("\n📖 ===== 游戏帮助 =====\n");
    printf("• 石头剪刀布规则：\n");
    printf("  - 石头 胜 剪刀\n");
    printf("  - 剪刀 胜 布\n");
    printf("  - 布 胜 石头\n");
    printf("• 游戏操作：\n");
    printf("  - 0: 石头 🗿\n");
    printf("  - 1: 剪刀 ✂️\n");
    printf("  - 2: 布 📄\n");
    printf("• 每场比赛10回合\n");
    printf("• 得分多者获胜\n");
    printf("========================\n");
}

// 获取用户输入
void get_user_input() {
    char input[256];
    
    while (game_running) {
        printf("👉 ");
        fflush(stdout);
        
        if (fgets(input, sizeof(input), stdin) == NULL) {
            break;
        }
        
        // 去除换行符
        input[strcspn(input, "\n")] = 0;
        
        if (strlen(input) == 0) {
            continue;
        }
        
        Message msg;
        
        if (client_state == CLIENT_PLAYING) {
            // 游戏中，处理出招
            int move = atoi(input);
            if (move >= 0 && move <= 2) {
                msg.type = MSG_MOVE;
                sprintf(msg.data, "%d", move);
                msg.length = strlen(msg.data) + 1;
                send_message(client_socket, &msg);
                client_state = CLIENT_IN_ROOM; // 等待结果
            } else {
                printf("❌ 无效选择！请输入 0(石头) 1(剪刀) 2(布)\n");
            }
        } else if (client_state == CLIENT_LOBBY) {
            // 大厅中，处理菜单选择
            int choice = atoi(input);
            
            switch (choice) {
                case 1:
                    // 查看房间列表
                    msg.type = MSG_ROOM_LIST;
                    msg.length = 0;
                    send_message(client_socket, &msg);
                    break;
                    
                case 2: {
                    // 创建房间
                    printf("请输入房间名称: ");
                    char room_name[64];
                    if (fgets(room_name, sizeof(room_name), stdin)) {
                        room_name[strcspn(room_name, "\n")] = 0;
                        if (strlen(room_name) > 0) {
                            msg.type = MSG_CREATE_ROOM;
                            strcpy(msg.data, room_name);
                            msg.length = strlen(msg.data) + 1;
                            send_message(client_socket, &msg);
                            client_state = CLIENT_IN_ROOM;
                        }
                    }
                    break;
                }
                
                case 3: {
                    // 加入房间
                    printf("请输入房间号: ");
                    char room_id_str[16];
                    if (fgets(room_id_str, sizeof(room_id_str), stdin)) {
                        room_id_str[strcspn(room_id_str, "\n")] = 0;
                        int room_id = atoi(room_id_str);
                        if (room_id >= 0) {
                            msg.type = MSG_JOIN;
                            sprintf(msg.data, "%d", room_id);
                            msg.length = strlen(msg.data) + 1;
                            send_message(client_socket, &msg);
                            client_state = CLIENT_IN_ROOM;
                        }
                    }
                    break;
                }
                
                case 4:
                    show_help();
                    break;
                    
                case 5:
                    printf("👋 再见！\n");
                    game_running = 0;
                    return;
                    
                default:
                    show_main_menu();
                    break;
            }
        } else {
            // 房间中，可以聊天或等待
            if (strncmp(input, "/", 1) == 0) {
                // 命令处理
                if (strcmp(input, "/help") == 0) {
                    show_help();
                } else if (strcmp(input, "/leave") == 0) {
                    client_state = CLIENT_LOBBY;
                    printf("📤 已离开房间\n");
                    show_main_menu();
                }
            } else {
                // 聊天消息
                msg.type = MSG_CHAT;
                strcpy(msg.data, input);
                msg.length = strlen(msg.data) + 1;
                send_message(client_socket, &msg);
            }
        }
    }
}

// 信号处理函数
void signal_handler(int sig) {
    if (sig == SIGINT) {
        printf("\n\n👋 正在断开连接...\n");
        game_running = 0;
        close(client_socket);
        exit(0);
    }
}

int main(int argc, char *argv[]) {
    struct sockaddr_in server_addr;
    char server_ip[16] = "127.0.0.1";
    
    // 注册信号处理
    signal(SIGINT, signal_handler);
    
    // 解析命令行参数
    if (argc > 1) {
        strcpy(server_ip, argv[1]);
    }
    
    printf("🚀 正在连接服务器 %s:%d...\n", server_ip, PORT);
    
    // 创建socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1) {
        perror("socket");
        exit(1);
    }
    
    // 设置服务器地址
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);
    
    // 连接服务器
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        perror("❌ 连接失败");
        printf("请确保服务器正在运行并且地址正确\n");
        close(client_socket);
        exit(1);
    }
    
    printf("✅ 成功连接到服务器！\n");
    
    // 创建接收消息线程
    pthread_create(&receive_thread, NULL, receive_messages, NULL);
    
    // 等待欢迎消息
    sleep(1);
    
    printf("\n💡 提示：\n");
    printf("• 在房间中可以聊天\n");
    printf("• 输入 /help 查看帮助\n");
    printf("• 输入 /leave 离开房间\n");
    printf("• 按 Ctrl+C 退出程序\n");
    
    show_main_menu();
    
    // 处理用户输入
    get_user_input();
    
    // 清理
    game_running = 0;
    pthread_cancel(receive_thread);
    close(client_socket);
    
    printf("👋 感谢游戏！\n");
    return 0;
}