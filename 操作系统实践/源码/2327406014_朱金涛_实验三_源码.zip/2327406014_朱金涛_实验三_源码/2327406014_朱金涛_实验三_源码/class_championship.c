#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <time.h>
#include <string.h>

#define ROCK 0
#define SCISSORS 1 
#define PAPER 2
#define ROUNDS_PER_MATCH 20  // 每场比赛回合数
#define MAX_PLAYERS 10       // 每班最大选手数
#define TOP_PLAYERS 3        // 前三甲

// 选手信息
typedef struct {
    int id;
    char name[32];
    int score;
    int matches_played;
    int matches_won;
    double win_rate;
} Player;

// 比赛状态
typedef struct {
    int player1_id;
    int player2_id;
    int player1_move;
    int player2_move;
    int result1;
    int result2;
    int round;
    int match_finished;
    int current_match;
    int total_matches;
} MatchData;

// 共享内存结构
typedef struct {
    Player class1_players[MAX_PLAYERS];
    Player class2_players[MAX_PLAYERS];
    Player class1_top3[TOP_PLAYERS];
    Player class2_top3[TOP_PLAYERS];
    MatchData current_match;
    int class1_size;
    int class2_size;
    int tournament_stage; // 0=班级赛, 1=年级赛
    int game_over;
    char log_message[256];
} GameData;

struct sembuf sem_lock = {0, -1, 0};
struct sembuf sem_unlock = {0, 1, 0};

int semid;
GameData *game_data;

// 判断胜负
int judge_winner(int move1, int move2) {
    if (move1 == move2) return 0;
    if ((move1 == ROCK && move2 == SCISSORS) ||
        (move1 == SCISSORS && move2 == PAPER) ||
        (move1 == PAPER && move2 == ROCK)) {
        return 1;
    }
    return -1;
}

// 选手进程
void player_process(int player_id, int class_id) {
    srand(time(NULL) + player_id + class_id * 100);
    
    while (!game_data->game_over) {
        semop(semid, &sem_lock, 1);
        
        if (game_data->game_over) {
            semop(semid, &sem_unlock, 1);
            break;
        }
        
        // 检查是否是当前比赛的选手
        if (game_data->current_match.player1_id == player_id) {
            if (game_data->current_match.player1_move == -1 && 
                game_data->current_match.round > 0) {
                game_data->current_match.player1_move = rand() % 3;
            }
        } else if (game_data->current_match.player2_id == player_id) {
            if (game_data->current_match.player2_move == -1 && 
                game_data->current_match.round > 0) {
                game_data->current_match.player2_move = rand() % 3;
            }
        }
        
        semop(semid, &sem_unlock, 1);
        usleep(10000);
    }
}

// 初始化选手
void init_players() {
    printf("初始化一班选手...\n");
    game_data->class1_size = 6;
    for (int i = 0; i < game_data->class1_size; i++) {
        game_data->class1_players[i].id = i + 1;
        sprintf(game_data->class1_players[i].name, "一班选手%d", i + 1);
        game_data->class1_players[i].score = 0;
        game_data->class1_players[i].matches_played = 0;
        game_data->class1_players[i].matches_won = 0;
        game_data->class1_players[i].win_rate = 0.0;
    }
    
    printf("初始化二班选手...\n");
    game_data->class2_size = 6;
    for (int i = 0; i < game_data->class2_size; i++) {
        game_data->class2_players[i].id = i + 11;
        sprintf(game_data->class2_players[i].name, "二班选手%d", i + 1);
        game_data->class2_players[i].score = 0;
        game_data->class2_players[i].matches_played = 0;
        game_data->class2_players[i].matches_won = 0;
        game_data->class2_players[i].win_rate = 0.0;
    }
}

// 进行单场比赛
void conduct_match(int player1_id, int player2_id, FILE *fp) {
    char *moves[] = {"石头", "剪刀", "布"};
    int player1_score = 0, player2_score = 0;
    
    printf("\n=== %s VS %s ===\n", 
           (player1_id <= 10) ? game_data->class1_players[player1_id-1].name : 
                                game_data->class2_players[player1_id-11].name,
           (player2_id <= 10) ? game_data->class1_players[player2_id-1].name : 
                                game_data->class2_players[player2_id-11].name);
    
    game_data->current_match.player1_id = player1_id;
    game_data->current_match.player2_id = player2_id;
    game_data->current_match.match_finished = 0;
    
    for (int round = 1; round <= ROUNDS_PER_MATCH; round++) {
        semop(semid, &sem_lock, 1);
        game_data->current_match.round = round;
        game_data->current_match.player1_move = -1;
        game_data->current_match.player2_move = -1;
        semop(semid, &sem_unlock, 1);
        
        // 等待双方出招
        while (1) {
            semop(semid, &sem_lock, 1);
            if (game_data->current_match.player1_move != -1 && 
                game_data->current_match.player2_move != -1) {
                semop(semid, &sem_unlock, 1);
                break;
            }
            semop(semid, &sem_unlock, 1);
            usleep(1000);
        }
        
        semop(semid, &sem_lock, 1);
        int result = judge_winner(game_data->current_match.player1_move, 
                                  game_data->current_match.player2_move);
        
        if (result == 1) {
            player1_score++;
            printf("第%d回合: %s vs %s - %s胜\n", round,
                   moves[game_data->current_match.player1_move],
                   moves[game_data->current_match.player2_move],
                   (player1_id <= 10) ? game_data->class1_players[player1_id-1].name : 
                                        game_data->class2_players[player1_id-11].name);
        } else if (result == -1) {
            player2_score++;
            printf("第%d回合: %s vs %s - %s胜\n", round,
                   moves[game_data->current_match.player1_move],
                   moves[game_data->current_match.player2_move],
                   (player2_id <= 10) ? game_data->class1_players[player2_id-1].name : 
                                        game_data->class2_players[player2_id-11].name);
        } else {
            printf("第%d回合: %s vs %s - 平局\n", round,
                   moves[game_data->current_match.player1_move],
                   moves[game_data->current_match.player2_move]);
        }
        semop(semid, &sem_unlock, 1);
        usleep(20000);
    }
    
    // 更新选手数据
    if (player1_id <= 10) {
        game_data->class1_players[player1_id-1].score += player1_score;
        game_data->class1_players[player1_id-1].matches_played++;
        if (player1_score > player2_score) 
            game_data->class1_players[player1_id-1].matches_won++;
    } else {
        game_data->class2_players[player1_id-11].score += player1_score;
        game_data->class2_players[player1_id-11].matches_played++;
        if (player1_score > player2_score) 
            game_data->class2_players[player1_id-11].matches_won++;
    }
    
    if (player2_id <= 10) {
        game_data->class1_players[player2_id-1].score += player2_score;
        game_data->class1_players[player2_id-1].matches_played++;
        if (player2_score > player1_score) 
            game_data->class1_players[player2_id-1].matches_won++;
    } else {
        game_data->class2_players[player2_id-11].score += player2_score;
        game_data->class2_players[player2_id-11].matches_played++;
        if (player2_score > player1_score) 
            game_data->class2_players[player2_id-11].matches_won++;
    }
    
    printf("比赛结果: %d - %d\n", player1_score, player2_score);
    if (fp) {
        fprintf(fp, "%s VS %s: %d - %d\n",
                (player1_id <= 10) ? game_data->class1_players[player1_id-1].name : 
                                     game_data->class2_players[player1_id-11].name,
                (player2_id <= 10) ? game_data->class1_players[player2_id-1].name : 
                                     game_data->class2_players[player2_id-11].name,
                player1_score, player2_score);
    }
    
    game_data->current_match.match_finished = 1;
}

// 班级内循环赛
void class_tournament(Player *players, int size, const char *class_name, FILE *fp) {
    printf("\n=== %s内部循环赛 ===\n", class_name);
    fprintf(fp, "\n=== %s内部循环赛 ===\n", class_name);
    
    // 每个选手与其他选手比赛
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            conduct_match(players[i].id, players[j].id, fp);
        }
    }
    
    // 计算胜率
    for (int i = 0; i < size; i++) {
        if (players[i].matches_played > 0) {
            players[i].win_rate = (double)players[i].matches_won / players[i].matches_played;
        }
    }
    
    // 排序选出前三甲
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - 1 - i; j++) {
            if (players[j].score < players[j+1].score || 
                (players[j].score == players[j+1].score && players[j].win_rate < players[j+1].win_rate)) {
                Player temp = players[j];
                players[j] = players[j+1];
                players[j+1] = temp;
            }
        }
    }
    
    printf("\n%s排名:\n", class_name);
    fprintf(fp, "\n%s排名:\n", class_name);
    for (int i = 0; i < size; i++) {
        printf("%d. %s - 总分:%d 胜率:%.2f\n", i+1, players[i].name, 
               players[i].score, players[i].win_rate);
        fprintf(fp, "%d. %s - 总分:%d 胜率:%.2f\n", i+1, players[i].name, 
                players[i].score, players[i].win_rate);
    }
}

// 年级冠军赛
void grade_championship(FILE *fp) {
    printf("\n=== 年级冠军赛 ===\n");
    fprintf(fp, "\n=== 年级冠军赛 ===\n");
    
    // 复制前三甲到专门数组
    for (int i = 0; i < TOP_PLAYERS; i++) {
        game_data->class1_top3[i] = game_data->class1_players[i];
        game_data->class2_top3[i] = game_data->class2_players[i];
        // 重置比赛数据
        game_data->class1_top3[i].score = 0;
        game_data->class1_top3[i].matches_played = 0;
        game_data->class1_top3[i].matches_won = 0;
        game_data->class2_top3[i].score = 0;
        game_data->class2_top3[i].matches_played = 0;
        game_data->class2_top3[i].matches_won = 0;
    }
    
    game_data->tournament_stage = 1;
    
    // 两班前三甲交叉比赛
    for (int i = 0; i < TOP_PLAYERS; i++) {
        for (int j = 0; j < TOP_PLAYERS; j++) {
            conduct_match(game_data->class1_top3[i].id, 
                         game_data->class2_top3[j].id, fp);
        }
    }
    
    // 更新前三甲数据并排序
    Player all_top6[6];
    for (int i = 0; i < TOP_PLAYERS; i++) {
        // 找到对应的选手并更新数据
        for (int k = 0; k < game_data->class1_size; k++) {
            if (game_data->class1_players[k].id == game_data->class1_top3[i].id) {
                all_top6[i] = game_data->class1_players[k];
                break;
            }
        }
        for (int k = 0; k < game_data->class2_size; k++) {
            if (game_data->class2_players[k].id == game_data->class2_top3[i].id) {
                all_top6[i + TOP_PLAYERS] = game_data->class2_players[k];
                break;
            }
        }
    }
    
    // 计算最终胜率
    for (int i = 0; i < 6; i++) {
        if (all_top6[i].matches_played > 0) {
            all_top6[i].win_rate = (double)all_top6[i].matches_won / all_top6[i].matches_played;
        }
    }
    
    // 最终排序
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5 - i; j++) {
            if (all_top6[j].score < all_top6[j+1].score || 
                (all_top6[j].score == all_top6[j+1].score && all_top6[j].win_rate < all_top6[j+1].win_rate)) {
                Player temp = all_top6[j];
                all_top6[j] = all_top6[j+1];
                all_top6[j+1] = temp;
            }
        }
    }
    
    printf("\n=== 年级总排名 ===\n");
    fprintf(fp, "\n=== 年级总排名 ===\n");
    for (int i = 0; i < 6; i++) {
        printf("%d. %s - 总分:%d 胜率:%.2f", i+1, all_top6[i].name, 
               all_top6[i].score, all_top6[i].win_rate);
        fprintf(fp, "%d. %s - 总分:%d 胜率:%.2f", i+1, all_top6[i].name, 
                all_top6[i].score, all_top6[i].win_rate);
        if (i == 0) {
            printf(" 🏆年级冠军🏆\n");
            fprintf(fp, " 年级冠军\n");
        } else if (i == 1) {
            printf(" 🥈年级亚军🥈\n");
            fprintf(fp, " 年级亚军\n");
        } else if (i == 2) {
            printf(" 🥉年级季军🥉\n");
            fprintf(fp, " 年级季军\n");
        } else {
            printf("\n");
            fprintf(fp, "\n");
        }
    }
}

// 主裁判进程
void main_judge() {
    FILE *fp = fopen("championship_results.txt", "w");
    
    // 初始化选手
    init_players();
    
    // 一班内部比赛
    class_tournament(game_data->class1_players, game_data->class1_size, "一班", fp);
    
    // 二班内部比赛  
    class_tournament(game_data->class2_players, game_data->class2_size, "二班", fp);
    
    // 年级冠军赛
    grade_championship(fp);
    
    game_data->game_over = 1;
    fclose(fp);
}

int main() {
    key_t key = ftok(".", 1);
    
    // 创建共享内存
    int shmid = shmget(key, sizeof(GameData), IPC_CREAT | 0666);
    if (shmid == -1) {
        perror("shmget");
        exit(1);
    }
    
    // 创建信号量
    semid = semget(key, 1, IPC_CREAT | 0666);
    if (semid == -1) {
        perror("semget");
        exit(1);
    }
    
    semctl(semid, 0, SETVAL, 1);
    
    game_data = (GameData*)shmat(shmid, NULL, 0);
    if (game_data == (void*)-1) {
        perror("shmat");
        exit(1);
    }
    
    // 初始化
    memset(game_data, 0, sizeof(GameData));
    game_data->tournament_stage = 0;
    
    printf("🎮 石头剪刀布班级冠军赛开始！🎮\n");
    printf("一班6名选手 VS 二班6名选手\n");
    printf("先进行班级内循环赛，选出各班前三甲\n");
    printf("然后前三甲交叉比赛，决出年级冠军！\n\n");
    
    // 创建所有选手进程
    pid_t pids[12];
    
    // 一班选手进程
    for (int i = 0; i < 6; i++) {
        pids[i] = fork();
        if (pids[i] == 0) {
            player_process(i + 1, 1);
            exit(0);
        }
    }
    
    // 二班选手进程
    for (int i = 0; i < 6; i++) {
        pids[i + 6] = fork();
        if (pids[i + 6] == 0) {
            player_process(i + 11, 2);
            exit(0);
        }
    }
    
    // 主裁判进程
    main_judge();
    
    // 等待所有子进程结束
    for (int i = 0; i < 12; i++) {
        wait(NULL);
    }
    
    // 清理资源
    shmdt(game_data);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);
    
    printf("\n🎉 比赛圆满结束！详细结果已保存到 championship_results.txt\n");
    return 0;
}