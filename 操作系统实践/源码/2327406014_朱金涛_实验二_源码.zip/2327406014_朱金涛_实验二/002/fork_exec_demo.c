#include <stdio.h>    // 输入输出函数（printf、perror）
#include <stdlib.h>   // exit()函数
#include <unistd.h>   // fork()、execl()、getpid()系统调用
#include <sys/wait.h> // wait()系统调用（等待子进程退出）

int main() {
    pid_t pid;         // 存储fork()返回值（进程ID类型）
    int child_status;  // 存储子进程退出状态

    // 1. 调用fork()创建子进程
    pid = fork();

    // 情况1：fork创建子进程失败
    if (pid < 0) {
        perror("fork failed");  // 输出错误原因（如系统资源不足）
        exit(1);                // 父进程异常退出，返回值1表示错误
    }

    // 情况2：当前进程是子进程（fork返回0）
    else if (pid == 0) {
        printf("=== 子进程（PID：%d）运行中 ===\n", getpid());
        printf("子进程：准备调用exec函数执行helloworld...\n");

        // 调用execl()执行helloworld可执行文件
        // execl()参数说明：
        // 第1个参数：helloworld可执行文件的路径（当前目录下为./helloworld）
        // 第2个参数：传给helloworld的argv[0]（通常与文件名一致，可自定义）
        // 后续参数：传给helloworld的命令行参数（无则省略）
        // 最后一个参数：必须以NULL结尾，标识参数列表结束
        execl("/home/anders/OS_Operation/op002/ts002/helloworld", "helloworld", NULL);

        // 注意：若execl()执行成功，子进程的代码会被helloworld替换，以下代码不会执行
        // 只有execl()失败时，才会执行下面的错误处理
        perror("execl failed");  // 输出exec失败原因（如文件不存在、权限不足）
        exit(2);                // 子进程异常退出，返回值2表示exec失败
    }

    // 情况3：当前进程是父进程（fork返回子进程PID）
    else {
        printf("=== 父进程（PID：%d）运行中 ===\n", getpid());
        printf("父进程：已创建子进程，子进程PID为：%d\n", pid);
        printf("父进程：等待子进程执行完毕...\n");

        // 等待子进程退出（阻塞父进程，避免僵尸进程）
        wait(&child_status);

        // 解析子进程退出状态，判断exec是否成功
        if (WIFEXITED(child_status)) {
            int exit_code = WEXITSTATUS(child_status);
            if (exit_code == 0) {
                printf("父进程：子进程正常退出，helloworld执行成功！\n");
            } else {
                printf("父进程：子进程异常退出（exec执行失败），退出码：%d\n", exit_code);
            }
        } else {
            printf("父进程：子进程被信号终止（非正常退出）\n");
        }

        printf("父进程：所有操作完成，即将退出\n");
        exit(0);  // 父进程正常退出
    }

    return 0;  // 理论上不会执行（上述代码已包含exit()）
}
    