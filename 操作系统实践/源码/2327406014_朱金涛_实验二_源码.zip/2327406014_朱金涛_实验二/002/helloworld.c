#include <stdio.h>
#include <unistd.h>  // 新增：包含getpid()函数的声明

int main() {
    printf("------------------------\n");
    printf("Hello World! (来自exec执行的程序)\n");
    printf("当前执行进程PID：%d\n", getpid());  // 现在编译器能识别getpid()
    printf("------------------------\n");
    return 0;
}
    