#include <stdio.h>    // 用于输入输出函数（printf、scanf）
#include <stdlib.h>   // 用于exit()函数
#include <unistd.h>   // 用于fork()、getpid()、getppid()系统调用
#include <sys/wait.h> // 用于wait()系统调用（等待子进程退出）

int main() {
    pid_t pid;         // 存储fork()返回值（pid_t是进程ID的专用类型）
    int child_status;  // 存储子进程退出状态（供wait()使用）
    int child_return;  // 存储子进程的返回值（由用户输入指定）

    // 调用fork()创建子进程，返回值分三种情况：
    // 1. 负数：fork失败
    // 2. 0：当前进程是子进程
    // 3. 正数：当前进程是父进程，返回值为子进程PID
    pid = fork();

    // 情况1：fork创建子进程失败
    if (pid < 0) {
        perror("fork failed");  // 输出错误原因（如资源不足）
        exit(1);                // 父进程异常退出，返回值1表示错误
    }

    // 情况2：当前进程是子进程（fork返回0）
    else if (pid == 0) {
        printf("=== 子进程运行中 ===\n");
        printf("子进程提示：我是新创建的子进程\n");
        printf("子进程PID：%d\n", getpid());          // getpid()获取当前进程PID
        printf("子进程的父进程PID：%d\n", getppid()); // getppid()获取父进程PID

        // 提示用户输入子进程返回值（范围0-255，exit()仅识别低8位）
        printf("请输入子进程的返回值（0-255）：");
        scanf("%d", &child_return);

        // 确保返回值在有效范围（超出则取低8位，这里做简单提示）
        if (child_return < 0 || child_return > 255) {
            printf("警告：返回值超出0-255范围，将自动取模256\n");
            child_return = child_return % 256;
        }

        printf("子进程退出提示：子进程即将退出，返回值为%d\n", child_return);
        exit(child_return); // 子进程退出，将用户输入的值作为返回值
    }

    // 情况3：当前进程是父进程（fork返回子进程PID）
    else {
        printf("=== 父进程运行中 ===\n");
        printf("父进程提示：我是创建子进程的父进程\n");
        printf("父进程PID：%d\n", getpid());          // 获取父进程自身PID
        printf("父进程创建的子进程PID：%d\n", pid);   // fork返回值即子进程PID

        // 等待子进程退出（阻塞父进程，直到子进程结束）
        // wait(&child_status)：获取子进程退出状态，存储到child_status
        wait(&child_status);

        // 判断子进程是否正常退出（WIFEXITED是宏，用于检查退出状态）
        if (WIFEXITED(child_status)) {
            // WEXITSTATUS：从退出状态中提取子进程的返回值（仅当正常退出时有效）
            int child_exit_val = WEXITSTATUS(child_status);
            printf("父进程提示：已获取子进程退出返回值：%d\n", child_exit_val);
        } else {
            printf("父进程提示：子进程异常退出（如被信号终止）\n");
        }

        printf("父进程退出提示：父进程完成所有操作，即将退出\n");
        exit(0); // 父进程正常退出，返回值0表示成功
    }

    return 0; // 理论上不会执行到这里（因上述代码已包含exit()）
}
    