#include <stdio.h>    // 用于printf()输入输出
#include <unistd.h>   // 用于fork()、getppid()、getpid()
#include <sys/wait.h> // 用于wait()
#include <stdlib.h>   // 用于exit()

int main()
{
    int rtn = 0;
    int i;
    for (i = 0; i < 2; i++)
    {
        if (fork() == 0)
        {
            // 子进程：输出父进程PID和自身PID
            printf("Child: the parent pid is: %d, the current pid is: %d\n", getppid(), getpid());
        }
        else
        {
            // 父进程：输出自身PID，并等待当前子进程退出
            printf("Parent: the process pid is: %d\n", getpid());
        }
    }
    exit(0);
}
    