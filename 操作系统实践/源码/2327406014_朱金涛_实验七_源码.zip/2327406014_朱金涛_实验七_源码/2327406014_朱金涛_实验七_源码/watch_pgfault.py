import time
import sys
import re

def get_pgfault_count():
    """
    打开 /proc/vmstat 文件，读取并解析 'pgfault' 的值。
    """
    try:
        # 打开 /proc/vmstat 文件
        with open('/proc/vmstat', 'r') as f:
            lines = f.readlines()
        
        # 遍历文件的每一行
        for line in lines:
            # 寻找以 'pgfault ' (注意有个空格) 开头的行
            if line.startswith('pgfault '):
                # 按空格分割，获取第二个值（即数字）
                parts = line.split()
                if len(parts) >= 2:
                    return int(parts[1])
                    
        # 如果循环结束了都没找到
        print("错误：未能在 /proc/vmstat 中找到 'pgfault' 字段。")
        return None

    except FileNotFoundError:
        print("错误：/proc/vmstat 文件不存在。请确保在 Linux 系统上运行。")
        return None
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
        return None

# --- 主程序开始 ---

# 默认统计 5 秒钟
DEFAULT_SECONDS = 5
interval_seconds = DEFAULT_SECONDS

if len(sys.argv) > 1:
    try:
        interval_seconds = int(sys.argv[1])
    except ValueError:
        print(f"无效的时间间隔, 将使用默认的 {DEFAULT_SECONDS} 秒。")

print(f"--- 缺页次数统计 (方法二：读取 /proc/vmstat) ---")
print(f"将在 {interval_seconds} 秒后统计结果...\n")

# 1. 获取初始值 (V1)
start_faults = get_pgfault_count()

if start_faults is not None:
    print(f"T1: 当前系统总缺页次数 = {start_faults}")
    
    
    # 2. 定时等待
    time.sleep(interval_seconds)
    
    # 3. 获取结束值 (V2)
    end_faults = get_pgfault_count()
    
    if end_faults is not None:
        print(f"T2: 结束时系统总缺页次数 = {end_faults}")
        print("-------------------------------------------------")
        
        # 4. 计算差值 (V2 - V1)
        delta_faults = end_faults - start_faults
        
        print(f"在 {interval_seconds} 秒内, 系统共产生了 {delta_faults} 次缺页。")
        print("-------------------------------------------------")