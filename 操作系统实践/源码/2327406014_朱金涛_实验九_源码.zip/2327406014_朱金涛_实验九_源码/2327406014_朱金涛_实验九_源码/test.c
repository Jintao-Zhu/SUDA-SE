#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define DEVICE_FILE "/dev/chardev"

int main()
{
    int fd;
    char read_buf[100];
    char write_buf[] = "This is a NEW message from User!";
    int ret;

    // --- 第一步：测试默认读取 ---
    printf("1. 打开设备读取默认消息...\n");
    fd = open(DEVICE_FILE, O_RDWR);
    if (fd < 0)
    {
        perror("打开失败");
        return -1;
    }

    ret = read(fd, read_buf, sizeof(read_buf) - 1);
    if (ret > 0)
    {
        read_buf[ret] = '\0';
        printf("-> [Read Default]: %s", read_buf);
    }
    close(fd); // 关闭设备

    // --- 第二步：测试写入功能 ---
    printf("\n2. 打开设备并写入新消息...\n");
    fd = open(DEVICE_FILE, O_RDWR);
    if (fd < 0)
    {
        perror("打开失败");
        return -1;
    }

    printf("-> 正在写入: \"%s\"\n", write_buf);
    ret = write(fd, write_buf, strlen(write_buf));
    if (ret < 0)
    {
        perror("写入失败");
    }
    else
    {
        printf("-> 写入成功! 写入了 %d 字节\n", ret);
    }
    close(fd);

    // --- 第三步：验证写入结果 ---
    printf("\n3. 再次打开设备验证写入内容...\n");
    fd = open(DEVICE_FILE, O_RDWR);
    if (fd < 0)
    {
        perror("打开失败");
        return -1;
    }

    memset(read_buf, 0, sizeof(read_buf));
    ret = read(fd, read_buf, sizeof(read_buf) - 1);
    if (ret > 0)
    {
        read_buf[ret] = '\0';
        printf("-> [Read New]: %s\n", read_buf);
    }
    close(fd);

    return 0;
}