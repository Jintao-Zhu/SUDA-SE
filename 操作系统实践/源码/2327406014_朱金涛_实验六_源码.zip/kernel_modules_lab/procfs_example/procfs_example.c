#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/jiffies.h>
#include <linux/fs.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Procfs example module (safe version using single_open)");
MODULE_VERSION("1.0");

// 全局保存 /proc/procfs_example 目录指针
static struct proc_dir_entry *proc_dir;

// ---------- 1. 文件内容输出函数 ----------

// 输出 foo
static int foo_show(struct seq_file *m, void *v)
{
    seq_printf(m, "foo\n");
    return 0;
}

// 输出 bar
static int bar_show(struct seq_file *m, void *v)
{
    seq_printf(m, "bar\n");
    return 0;
}

// 输出 jiffies（系统启动以来的时间节拍数）
static int jiffies_show(struct seq_file *m, void *v)
{
    seq_printf(m, "jiffies: %lu\n", jiffies);
    return 0;
}

// ---------- 2. 打开函数，使用 single_open 简化 ----------

static int foo_open(struct inode *inode, struct file *file)
{
    return single_open(file, foo_show, NULL);
}

static int bar_open(struct inode *inode, struct file *file)
{
    return single_open(file, bar_show, NULL);
}

static int jiffies_open(struct inode *inode, struct file *file)
{
    return single_open(file, jiffies_show, NULL);
}

// ---------- 3. 定义文件操作结构体（proc_ops） ----------

static const struct proc_ops foo_ops = {
    .proc_open = foo_open,
    .proc_read_iter = seq_read_iter,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

static const struct proc_ops bar_ops = {
    .proc_open = bar_open,
    .proc_read_iter = seq_read_iter,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

static const struct proc_ops jiffies_ops = {
    .proc_open = jiffies_open,
    .proc_read_iter = seq_read_iter,
    .proc_lseek = seq_lseek,
    .proc_release = single_release,
};

// ---------- 4. 模块加载函数 ----------

static int __init procfs_example_init(void)
{
    // 创建 /proc/procfs_example 目录
    proc_dir = proc_mkdir("procfs_example", NULL);
    if (!proc_dir)
    {
        printk(KERN_ALERT "Failed to create /proc/procfs_example directory\n");
        return -ENOMEM;
    }

    // 创建 foo 文件
    if (!proc_create("foo", 0444, proc_dir, &foo_ops))
        goto err;
    // 创建 bar 文件
    if (!proc_create("bar", 0444, proc_dir, &bar_ops))
        goto err;
    // 创建 jiffies 文件
    if (!proc_create("jiffies", 0444, proc_dir, &jiffies_ops))
        goto err;
    // 创建符号链接 jiffies_too -> jiffies
    if (!proc_symlink("jiffies_too", proc_dir, "jiffies"))
        goto err;

    printk(KERN_INFO "[procfs_example] Module loaded successfully\n");
    return 0;

err:
    // 若创建失败则清理已创建的文件
    remove_proc_entry("jiffies_too", proc_dir);
    remove_proc_entry("jiffies", proc_dir);
    remove_proc_entry("bar", proc_dir);
    remove_proc_entry("foo", proc_dir);
    remove_proc_entry("procfs_example", NULL);
    printk(KERN_ALERT "[procfs_example] Module load failed, cleaned up.\n");
    return -ENOMEM;
}

// ---------- 5. 模块卸载函数 ----------

static void __exit procfs_example_exit(void)
{
    if (proc_dir)
    {
        remove_proc_entry("jiffies_too", proc_dir);
        remove_proc_entry("jiffies", proc_dir);
        remove_proc_entry("bar", proc_dir);
        remove_proc_entry("foo", proc_dir);
        remove_proc_entry("procfs_example", NULL);
        proc_dir = NULL;
    }
    printk(KERN_INFO "[procfs_example] Module unloaded.\n");
}

module_init(procfs_example_init);
module_exit(procfs_example_exit);
