#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

MODULE_LICENSE("GPL");                                    // 模块许可
MODULE_DESCRIPTION("A simple hello world kernel module"); // 模块功能描述
MODULE_AUTHOR("Jintao");                                  // 作者信息（可选）
MODULE_VERSION("1.0");                                    // 版本号（可选）

// 初始化函数
static int __init hello_init(void)
{
    printk("<1>Hello, World!\n"); // 打印日志
    return 0;                     // 成功加载
}

// 清理函数
static void __exit hello_exit(void)
{
    printk("<1>Goodbye, World!\n"); // 打印退出信息
}

module_init(hello_init); // 注册初始化函数
module_exit(hello_exit); // 注册清理函数
